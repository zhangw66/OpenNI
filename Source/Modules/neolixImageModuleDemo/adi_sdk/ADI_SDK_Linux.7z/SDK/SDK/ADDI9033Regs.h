/* ADDI9033Regs.h */
#pragma once

#include "types.h"

#define TOF_ABORT_DELAY             1000
#define TOF_VDHD_DELAY_ADJ          8
#define TOF_SENSOR_MN34906BL        0
#define OUTPUT_MIPI_ENA             1
#define OUTPUT_DEPTH_ENA            2
#define OUTPUT_IR_ENA               4
#define OUTPUT_IR_INTR_MODE         8



#define TOF_DUMMY                   0x0000
#define TOF_CONTROL                 0xc300
#define TOF_ALIGN0                  0xc301
#define TOF_ALIGN1                  0xc302
#define TOF_ALIGN2                  0xc303
#define TOF_ALIGN3                  0xc304
#define TOF_ALIGN4                  0xc305
#define TOF_ALIGN5                  0xc306
#define TOF_ALIGN6                  0xc307
#define TOF_ALIGN7                  0xc308
#define TOF_ALIGN8                  0xc309
#define TOF_ALIGN9                  0xc30a
#define TOF_ALIGN10                 0xc30b
#define TOF_CHKR_UPPRTH             0xc30c
#define TOF_CHKR_LWRTH              0xc30d
#define TOF_CHKR_START_V            0xc30e
#define TOF_CHKR_START_H            0xc30f
#define TOF_CHKR_SIZE_H             0xc310
#define TOF_CHKR_UPPRERR_H          0xc311
#define TOF_CHKR_UPPRERR_V          0xc312
#define TOF_CHKR_LWRERR_H           0xc313
#define TOF_CHKR_LWRERR_V           0xc314
#define TOF_CHKR_DET_ENA            0xc315
#define TOF_DFCT0                   0xc316
#define TOF_DFCT1                   0xc317
#define TOF_DFCT_PIX_TH_TBL         0xc318
#define TOF_DFCT_PIX_TH_TBL_SIZE    12
#define TOF_RATE_ADJUST0            0xc324
#define TOF_RATE_ADJUST1            0xc325
#define TOF_RATE_ADJUST2            0xc326
#define TOF_GRID0                   0xc327
#define TOF_GRID1                   0xc328
#define TOF_GRID2                   0xc329
#define TOF_GRID3                   0xc32a
#define TOF_RAWNR_BK_TBL_START      0xc32b
#define TOF_RAWNR_BK_TBL_SIZE       13
#define TOF_RAWNR_BL_TBL_START      0xc338
#define TOF_RAWNR_BL_TBL_SIZE       13
#define TOF_RAWNR_MED               0xc345
#define TOF_RAWNR_SAT_TH            0xc346
#define TOF_RAWNR_XPWR_1            0xc347
#define TOF_RAWNR_XPWR_5            0xc348
#define TOF_RAWNR_XPWR_9            0xc349
#define TOF_RAWNR_XPWR_SIZE         3
#define TOF_COR0                    0xc34a
#define TOF_COR1                    0xc34b
#define TOF_COR2                    0xc34c
#define TOF_CORB0                   0xc34d
#define TOF_CORB1                   0xc34e
#define TOF_CORB2                   0xc34f
#define TOF_CORF0                   0xc350
#define TOF_CORF1                   0xc351
#define TOF_CORF2                   0xc352
#define TOF_IR1                     0xc371
#define TOF_GMM_TBL                 0xc372
#define TOF_GMM_TBL_ENTRIES         9
#define TOF_GMM_TBL_SIZE            3
#define TOF_GMM_Y_START             0xc375
#define TOF_GMM_Y_SIZE              9
#define TOF_DEPTH0                  0xc37e
#define TOF_DEPTH1                  0xc37f
#define TOF_DEPTH2                  0xc380
#define TOF_DEPTH3                  0xc381
#define TOF_LNR_OFST_START          0xc382
#define TOF_LNR_OFST_SIZE           49
#define TOF_LNR_X0                  0xc3b3
#define TOF_LNR_XPWR_START          0xc3b4
#define TOF_LNR_XPWR_ENTRIES        48
#define TOF_LNR_XPWR_SIZE           (TOF_LNR_XPWR_ENTRIES >> 2)
#define TOF_SHD                     0xc3c0
#define TOF_SHD_X0                  0xc3c1
#define TOF_SHD_XPWR_START          0xc3c2
#define TOF_SHD_XPWR_ENTRIES        16
#define TOF_SHD_XPWR_SIZE           4
#define TOF_SHD_Y0                  0xc3c6
#define TOF_SHD_YPWR_START          0xc3c7
#define TOF_SHD_YPWR_ENTRIES        12
#define TOF_SHD_YPWR_SIZE           3
#define TOF_READ_SIZE0              0xc3ca
#define TOF_READ_SIZE1              0xc3cb
#define TOF_READ_SIZE2              0xc3cc
#define TOF_READ_SIZE3              0xc3cd
#define TOF_READ_SIZE4              0xc3ce
#define TOF_READ_SIZE5              0xc3cf
#define TOF_READ_SIZE6              0xc3d0
#define TOF_READ_SIZE7              0xc3d1
#define TOF_ROI0                    0xc3d2
#define TOF_ROI1                    0xc3d3
#define TOF_ROI2                    0xc3d4
#define TOF_ROI3                    0xc3d5
#define TOF_ROI4                    0xc3d6
#define TOF_ROI5                    0xc3d7
#define TOF_ROI6                    0xc3d8
#define TOF_ROI7                    0xc3d9
#define TOF_OUTPUT                  0xc3da
#define TOF_OUTPUT_SEL              0xc3db
#define TOF_VC                      0xc3dc
#define TOF_ABORT                   0xc3dd
#define TOF_BYPASS                  0xc3de
#define TOF_TESTRAMP                0xc3df
#define TOF_FIELD_INDEX             0xc08f
#define TOF_FIELD_INDEX_MUX         0xc087


typedef struct {
    uint16 tof_enable       : 1;
    uint16 m3w_sel          : 2;
    uint16 gridvga_sel      : 1;
    uint16 sensor_type      : 2;
    uint16 chan_swap        : 1;
    uint16 reserved0        : 1;
    uint16 vdhd_delay_adj   : 4;
    uint16 reserved1        : 4;
} tof_control_t;

typedef struct {
    uint16 map_a0           : 3;
    uint16 map_a1           : 3;
    uint16 map_a2           : 3;
    uint16 reserved         : 7;
} tof_align_map_t;

typedef struct {
    uint16 rgb_raw_map_e    : 3;
    uint16 reserved0        : 3;
    uint16 rgb_raw_map_o    : 3;
    uint16 reserved1        : 7;
} tof_align_rgb_raw_map_t;

typedef struct {
    uint16 tof_afe_el_offset    : 5;
    uint16 tof_afe_ol_offset    : 5;
    uint16 tof_pixel_offset     : 5;
    uint16 reserved             : 1;
} tof_align_afe_t;

typedef struct {
    uint16 chkr_size_h      : 6;
    uint16 reserved         : 2;
    uint16 chkr_startofst_h : 7;
} tof_chkr_size_t;

typedef struct {
    uint16 dfct_pix_enbl_sel    : 1;
    uint16 dfct_med_ref_sel     : 1;
    uint16 dfct_det_bsln_sel    : 1;
    uint16 reserved             : 13;
} tof_dfct1_t;

typedef struct {
    uint16 vgashrt_xofst    : 12;
    uint16 vgashrt_xpwr     : 4;
} tof_grid0_t;

typedef struct {
    uint16 vgalng_sat_th    : 12;
    uint16 wdr_bitsft       : 2;
    uint16 reserved         : 2;
} tof_grid1_t;

typedef struct {
    uint16 rawnr_med_en         : 1;
    uint16 rawnr_med_sel        : 1;
    uint16 rawnr_medsel_gain    : 10;
    uint16 reserved             : 4;
} tof_rawnr_med_t;

typedef struct {
    uint16 pwr1                 : 4;
    uint16 pwr2                 : 4;
    uint16 pwr3                 : 4;
    uint16 pwr4                 : 4;
} tof_pwr_t;

typedef struct {
    uint16 s0s1_corth           : 14;
    uint16 reserved             : 1;
    uint16 sm_sig_rmv_en        : 1;
} tof_cor0_t;

typedef struct {
    uint16 ir_dgain             : 12;
    uint16 ir_img_sel           : 1;
    uint16 reserved             : 3;
} tof_ir1_t;

typedef struct {
    uint16 mipi_enable          : 1;
    uint16 output_depth         : 1;
    uint16 output_ir            : 1;
    uint16 output_ir_interleave : 1;
    uint16 gray_code_output     : 1;
    uint16 reserved             : 11;
} tof_output_t;

typedef struct {
    uint16 output_bg_sel        : 1;
    uint16 output_intrlv_sel    : 1;
    uint16 reserved             : 14;
} tof_output_sel_t;

typedef struct {
    uint16 vc_depth             : 2;
    uint16 vc_ir                : 2;
    uint16 vc_bg                : 2;
    uint16 vc_irbg              : 2;
    uint16 vc_rgb               : 2;
    uint16 vc_raw               : 2;
    uint16 reserved             : 4;
} tof_vc_t;

typedef struct {
    uint16 bypass_depth         : 1;
    uint16 bypass_ir            : 2;
    uint16 bypass_align         : 1;
    uint16 bypass_defect        : 1;
    uint16 bypass_rate_adjust   : 1;
    uint16 bypass_grid          : 1;
    uint16 bypass_grid_sel      : 1;
    uint16 bypass_cdc           : 1;
    uint16 bypass_filter        : 1;
    uint16 bypass_gauss         : 1;
    uint16 bypass_prodsum       : 1;
    uint16 bypass_depth_ir      : 1;
    uint16 lnr_bypass           : 1;
    uint16 bypass_output        : 1;
    uint16 reserved             : 1;
} tof_bypass_t;

typedef struct {
    uint16 testramp_align        : 1;
    uint16 testramp_defect       : 1;
    uint16 testramp_rate_adjust  : 1;
    uint16 testramp_grid         : 1;
    uint16 testramp_filter       : 1;
    uint16 testramp_depth_ir     : 1;
    uint16 testramp_output       : 1;
    uint16 reserved              : 9;
} tof_testramp_t;

template <class T>
class CodeEntry {
public:
    uint16 addr;
    T data;

    CodeEntry() { this->addr = 0; }

    CodeEntry(uint16 addr, T data) {
        this->addr = addr; this->data = data;
    }

    void set(uint16 addr, T data) { this->addr = addr; this->data = data; }

    void setAddr(uint16 addr) { this->addr = addr; }

    void setData(T data) { this->data = data; }

 };

typedef struct {
    // ToF disable
//    CodeEntry<uint16> abort;
//    CodeEntry<uint16> dummy[TOF_ABORT_DELAY];
    CodeEntry<tof_control_t> control_disable;

    // Align
    CodeEntry<tof_align_map_t> align_a_even;
    CodeEntry<tof_align_map_t> align_a_odd;
    CodeEntry<tof_align_map_t> align_b_even;
    CodeEntry<tof_align_map_t> align_b_odd;
    CodeEntry<tof_align_map_t> align_c_even;
    CodeEntry<tof_align_map_t> align_c_odd;
    CodeEntry<tof_align_rgb_raw_map_t> align_rgb_raw;
    CodeEntry<tof_align_afe_t> align_afe1_offset;
    CodeEntry<tof_align_afe_t> align_afe2_offset;
    CodeEntry<tof_align_afe_t> align_rgb_afe1_offset;
    CodeEntry<tof_align_afe_t> align_rgb_afe2_offset;

    // Checker board
    CodeEntry<uint16> chkr_upprth;
    CodeEntry<uint16> chkr_lwrth;
    CodeEntry<uint16> chkr_start_h;
    CodeEntry<uint16> chkr_start_v;
    CodeEntry<tof_chkr_size_t> chkr_size;
    CodeEntry<uint16> chkr_upprerr_h;
    CodeEntry<uint16> chkr_upprerr_v;
    CodeEntry<uint16> chkr_lwerr_h;
    CodeEntry<uint16> chkr_lwerr_v;
    CodeEntry<uint16> chkr_det_ena;

    // Defect pixel correction
    CodeEntry<uint16> dfct_pix_sat_th;
    CodeEntry<tof_dfct1_t> dfct_pix_sel;
    CodeEntry<uint16> dfct_pix_th_tbl[TOF_DFCT_PIX_TH_TBL_SIZE];

    // Rate adjust
    CodeEntry<uint16> rate_adj_hd_period;
    CodeEntry<uint16> rate_adj_img_height;
    CodeEntry<uint16> rate_adj_img_width;

    // Grid conversion
    CodeEntry<tof_grid0_t> grid0;
    CodeEntry<tof_grid1_t> grid1;
    CodeEntry<uint16> grid_ks_vga_sht2lng;
    CodeEntry<uint16> grid_obclmplev;

    // Noise reduction filter
    CodeEntry<uint16> rawnr_bk_tbl[TOF_RAWNR_BK_TBL_SIZE];
    CodeEntry<uint16> rawnr_bl_tbl[TOF_RAWNR_BL_TBL_SIZE];
    CodeEntry<tof_rawnr_med_t> rawnr_med;
    CodeEntry<uint16> rawnr_sat_th;
    CodeEntry<tof_pwr_t> rawnr_xpwr[TOF_RAWNR_XPWR_SIZE];

    // Coring threshold
    CodeEntry<tof_cor0_t> cor0;
    CodeEntry<uint16> corth_sft_dec_ofst;
    CodeEntry<uint16> corth_sft_inc_ofst;
    CodeEntry<uint16> corth_det_gainb;
    CodeEntry<uint16> corth_sft_gainb;
    CodeEntry<uint16> corth_det_cntb;
    CodeEntry<uint16> corth_det_gainf;
    CodeEntry<uint16> corth_sft_gainf;
    CodeEntry<uint16> corth_det_cntf;

    // IR 
    CodeEntry<tof_ir1_t> ir1;
    CodeEntry<tof_pwr_t> ir_gmm[TOF_GMM_TBL_SIZE];
    CodeEntry<uint16> ir_gmm_y[TOF_GMM_Y_SIZE];
    
    // Depth calc
    CodeEntry<uint16> depth_zerocorre;
    CodeEntry<uint16> depth_addvlu;
    CodeEntry<uint16> depth_ofstvlu;
    CodeEntry<uint16> depth_slope_gain;

    // Non-linear correction
    CodeEntry<uint16> lnr_ofst[TOF_LNR_OFST_SIZE];
    CodeEntry<uint16> lnr_x0;
    CodeEntry<tof_pwr_t> lnr_xpwr[TOF_LNR_XPWR_SIZE];

    // Shading correction
    CodeEntry<uint16> shd;
    CodeEntry<uint16> shd_x0;
    CodeEntry<tof_pwr_t> shd_xpwr[TOF_SHD_XPWR_SIZE];
    CodeEntry<uint16> shd_y0;
    CodeEntry<tof_pwr_t> shd_ypwr[TOF_SHD_YPWR_SIZE];

    // Read Size
    CodeEntry<uint16> tof_raw_height_hdcnt;
    CodeEntry<uint16> rgb_height_hdcnt;
    CodeEntry<uint16> tof_raw_start_hdcnt;
    CodeEntry<uint16> rgb_start_hdcnt;
    CodeEntry<uint16> tof_raw_width_pixcnt;
    CodeEntry<uint16> tof_raw_start_pixcnt;
    CodeEntry<uint16> rgb_width_pixcnt;
    CodeEntry<uint16> rgb_start_pixcnt;

    // Region of interest
    CodeEntry<uint16> tof_raw_roi_height;
    CodeEntry<uint16> tof_raw_roi_hstart;
    CodeEntry<uint16> tof_raw_roi_vstart;
    CodeEntry<uint16> tof_raw_roi_width;
    CodeEntry<uint16> rgb_roi_height;
    CodeEntry<uint16> rgb_roi_hstart;
    CodeEntry<uint16> rgb_roi_vstart;
    CodeEntry<uint16> rgb_roi_width;

    // Output / test
    CodeEntry<tof_output_t> output;
    CodeEntry<tof_output_sel_t> output_sel;
    CodeEntry<tof_vc_t> vc;
    CodeEntry<tof_bypass_t> bypass;
    CodeEntry<tof_testramp_t> testramp;

    // Field index for depth/IR or raw mode
    CodeEntry<uint16> field_index;
    CodeEntry<uint16> field_index_mux;

    CodeEntry<tof_control_t> control_enable;

} tof_ip_regs_t;

