/********************************************************************************/
/*																				*/
/* @file	ConfidenceFilter.h												    */
/*																				*/
/* @brief	Post Process Filter to remove pixels having low confidence value	*/
/*																				*/
/* @author	Dhruvesh Gajaria													*/
/*																				*/
/* @date	July 08, 2016														*/
/*																				*/
/* Copyright(c) Analog Devices, Inc.											*/
/*																				*/
/********************************************************************************/


#include "types.h"


class ConfidenceFilter
{
	uint16 unHeight;
	uint16 unWidth;
	uint16 confidencePercent;
	uint16 *punDepth;
	uint16 *punIR;
	uint16 *punConfidenceMap;
public:
	uint16 enable;
	ConfidenceFilter(){
		enable=0;
		punDepth=NULL;
		punIR = NULL;
		punConfidenceMap = NULL;
		confidencePercent=97;
		unHeight=0;
		unWidth=0;
	}
	void setDimensions(uint16 unHeight, uint16 unWidth) { this->unHeight = unHeight; this->unWidth = unWidth; };
	void setInPtr(uint16 *punDepth, uint16 *punIR) { this->punDepth = punDepth; this->punIR = punIR; };
	void setOutPtr(uint16 *punConfidenceMap) { this->punConfidenceMap = punConfidenceMap;};
	void setConfidencePercent(uint16 confidencePercent) { this->confidencePercent=(confidencePercent<100?confidencePercent:100); };
	void confidenceFilter();
};