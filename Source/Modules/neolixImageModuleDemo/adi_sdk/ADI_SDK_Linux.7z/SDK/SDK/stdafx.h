// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//
#pragma once

#define ADI_SDK

// Windows Header Files:
#ifndef Linux
#define WIN32_LEAN_AND_MEAN             // Exclude rarely-used stuff from Windows headers
#define CRTDBG_MAP_ALLOC
#include "targetver.h"
#include <windows.h>
#endif

// Disables method 3W feature as implemented for the ADDI9033
#define NOT_M3W_MODE

// Enables the Noise Reduction Filter as implemented for the ADDI9033
#define NRFILTER_FULL

// Enables an optimized verison of the ADDI9033 noise reduction filter
#define NRFILTER_FOR_TOF_EVAL

// Enables a post depth motion compensated temporal filter/spatial filter
#define NRFILTER3D
