/********************************************************************************/
/*																				*/
/* @file	ConfidenceFilter.cpp												*/
/*																				*/
/* @brief	Post Process Filter to remove pixels having low confidence value	*/
/*			Pixel having low confidence value are set to depth value 5000 (far)	*/																			
/*																				*/
/* @author	Dhruvesh Gajaria													*/
/*																				*/
/* @date	July 08, 2016														*/
/*																				*/
/* Copyright(c) Analog Devices, Inc.											*/
/*																				*/
/********************************************************************************/

#include <stdafx.h>
#include "ConfidenceFilter.h"
#include<math.h>


void ConfidenceFilter::confidenceFilter()
{
	uint16 deviation = 80;
	for (int v = 2; v < unHeight-2; ++v)
		for (int u = 2; u < unWidth-2; ++u)
		{
			uint16 z;

			z=punDepth[u+(v*unWidth)];
    
			uint16 count=0;
			
			for(int a=u-2;a<=u+2;a++)
				for(int b=v-2;b<=v+2;b++)
				{
					float diff=abs(z - punDepth[a+(b*unWidth)]);
						
					if(diff<deviation)
					{
						count++;
					}
				}	
			if((count*4)<confidencePercent)
			{		
				punDepth[u+(v*unWidth)]=5000;
			}
			punConfidenceMap[u+(v*unWidth)] = count * 8;
		} 
}