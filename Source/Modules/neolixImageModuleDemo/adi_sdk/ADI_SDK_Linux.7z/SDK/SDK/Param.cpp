/********************************************************************************/
/*                                                                              */
/* @file        Param.cpp                                                       */
/*                                                                              */
/* @brief       Imports and stores parameters from a .ini file.                 */
/*                                                                              */
/* @author      Rick Haltmaier                                                  */
/*                                                                              */
/* @date        September 1, 2015                                               */
/*                                                                              */
/* Copyright(c) Analog Devices, Inc.                                            */
/*                                                                              */
/********************************************************************************/
#include <stdafx.h>
#include <cstdlib>
#include "types.h"
#include "Param.h"

using namespace std;

Param::Param(char *filename)
{
	/* Set all parameters to some default value */
	this->eImgSensorType = (img_sensor_e)3;
    this->eAfePart = AFE_ADDI9030;
    this->ucRawMode = 0;
	this->ucDepthMode = 0;
	this->eDepthRange = DEPTH_RANGE_MID;
	this->unLDPulseCnt = 4000;
#ifndef TT666
	this->uiInWidth = 642;
	this->uiInHeight = 723;
	this->uiProcWidth = 642;
	this->uiProcHeight = 482;
#else
	this->uiInWidth = 1000;
	this->uiInHeight = 1000;
	this->uiProcWidth = 1000;
	this->uiProcHeight = 1000;
#endif
	this->uiOutWidth = 640;
    this->uiOutHStart = 0;
	this->uiOutHeight = 480;
    this->uiOutVStart = 0;

    this->unLaserEnaReg = LD_REG_INIT_VAL;

    // Debug output
	this->OutputSeparateDataSw = 0;
	this->OutputMedianDataSw = 0;
	this->OutputTransDataSw = 0;
	this->OutputMixTransDataSw = 0;
	this->OutputRawNrDataSw = 0;
	this->OutputCoringDataSw = 0;
	this->OutputDepthDataSw = 0;
	this->OutputDepthRelateDataSw = 0;
	this->OutputDepthOutDataSw = 0;
	this->OutputIrOutDataSw = 0;
	this->cOutputPath[0] = '\0';

	// Test image inject
	this->InjPostReorderSw = 0;
	this->InjPostReorderA0[0] = '\0';
	this->InjPostReorderA1[0] = '\0';
	this->InjPostReorderA2[0] = '\0';
	this->InjPostGridSw = 0;
	this->InjPostGridA0[0] = '\0';
	this->InjPostGridA1[0] = '\0';
	this->InjPostGridA2[0] = '\0';

	// Reorder
	this->ucM3WSel = 0;
	this->ucGridVGASel = 0;
	this->ToFStartHDCnt = 0;
	this->ToFStartPixCnt = 0;
        this->DebugReorderBuffers = 0;

	// Defect pixel correction
	this->DfctPixEna = 0;
	this->DfctPixSatTh = 0;
	this->DfctMedRefSel = 0;
	this->DfctDetBslnSel = 0;
	this->DfctPixSatTh = 0x0F80;
	//memset(this->DfctThrTbl, 0xFFF, DFCT_TH_TBL_SIZE*sizeof(uint16));
	for (int i = 0; i < DFCT_TH_TBL_SIZE; i++) {
		this->DfctThrTbl[i] = 0xFFF;
	}

	// Grid conversion
	this->OBClmpLev = 0;
	this->VGAShrtXOfst = 0;
	this->VGAShrtXPwr = 0;
	this->VGALngSatTh = 0xfff;
	this->KsVGAShrt2Lng = 0x400;
	this->WDRBitSft = 0;

	// NR Filter
	uint16 unCoefs[10][7] = {{400, 314, 193, 93, 35, 10, 0},
							{ 300, 236, 145, 70, 26,  8, 0 },
							{ 225, 177, 108, 52, 20,  6, 0 },
							{ 120,  94,  58, 28, 10,  3, 0 },
							{  90,  71,  43, 21,  8,  2, 0 },
							{  36,  28,  17,  8,  3,  1, 0 },
							{  20,  16,  10,  5,  2,  1, 0 },
							{  15,  12,   7,  3,  1,  0, 0 },
							{   6,   5,   3,  1,  1,  0, 0 },
							{   1,   1,   0,  0,  0,  0, 0 } };

	this->RawNREna = 0;
	this->RawNRMed4Bl1Sel = 3;
	this->RawNRMed4Bl1Gain = 256;
	this->RawNRSatTh = 0x3E00;
	uint8 xpwr[RAWNR_XPWR_TBL_SIZE] = { 7, 7, 7, 7, 8, 8, 8, 8, 9, 10, 10, 11 };
	this->RawNRXVal[0] = 0;
	for (int i = 0; i < RAWNR_XPWR_TBL_SIZE; i++) {
		this->RawNRXPwr[i] = xpwr[i];
		this->RawNRXVal[i + 1] = (1 << this->RawNRXPwr[i]) + this->RawNRXVal[i];
	}
	uint16 yval[RAWNR_YVAL_TBL_SIZE] = { 3, 4, 5, 5, 6, 8, 9, 10, 11, 13, 16, 18, 20 };
	memcpy(this->RawNRBlTbl, yval, RAWNR_YVAL_TBL_SIZE*sizeof(uint16));
	memcpy(this->RawNRBkTbl, yval, RAWNR_YVAL_TBL_SIZE*sizeof(uint16));

	uint8 ucCoefIdx[49] =
		{ 9, 8, 7, 6, 7, 8, 9,
		8, 5, 4, 3, 4, 5, 8,
		7, 4, 2, 1, 2, 4, 7,
		6, 3, 1, 0, 1, 3, 6,
		7, 4, 2, 1, 2, 4, 7,
		8, 5, 4, 3, 4, 5, 8,
		9, 8, 7, 6, 7, 8, 9 };

	for (int i = 0; i<49; i++) {
		memcpy(&this->unCoefTbl[i][0], &unCoefs[ucCoefIdx[i]], 7 * sizeof(uint16));
	}

	// Small signal removal/Coring
	this->ucSmSigRmvEna = 0;
	this->S0S1CorTh = 0xA0;
	this->CorThDetGainF = 256;
	this->CorThDetCntF = 15;
	this->CorThSftGainF = 0;
	this->CorThSftIncOfst = 0;
	this->CorThSftDecOfst = 0;
	this->CorThDetGainB = 256;
	this->CorThDetCntB = 15;
	this->CorThSftGainB = 0;

	// Depth
	this->DepthCalcAddVLU = 0x2000;
	//memset(this->LnrOfst, 0, LNR_OFFSET_VAL_TBL_SIZE * sizeof(int16));
	for (int i = 0; i < LNR_OFFSET_VAL_TBL_SIZE; i++) {
		this->LnrOfst[i] = 0;
	}

	for (int i = 0; i < INTRINSIC_TBL_SIZE; i++) {
		this->fIntrinsic[i] = 0;
	}

	for (int i = 0; i < DISTORTION_TBL_SIZE; i++) {
		this->dDistortionCoeff[i] = 0;
	}

	this->LnrX0 = 0;
	//memset(this->LnrXPwr, 7, LNR_OFFSET_XPWR_TBL_SIZE * sizeof(uint8));
	for (int i = 0; i < LNR_OFFSET_XPWR_TBL_SIZE; i++) {
		this->LnrXPwr[i] = 7;
	}

	this->DepthZeroCorre = 0;
	this->ucShdOfstEna = 0;
	this->Shd_X0 = 0;
	this->Shd_Y0 = 0;
	//memset(this->ShdXPwr, 7, SHADING_XPWR_TBL_SIZE * sizeof(uint8));
	for (int i = 0; i < SHADING_XPWR_TBL_SIZE; i++) {
		this->ShdXPwr[i] = 7;
	}
	//memset(this->ShdYPwr, 7, SHADING_YPWR_TBL_SIZE * sizeof(uint8));
	for (int i = 0; i < SHADING_YPWR_TBL_SIZE; i++) {
		this->ShdYPwr[i] = 7;
	}
	//memset(this->ShdOfst, 0, SHADING_OFFSET_TBL_SIZE * sizeof(uint16));
	for (int i = 0; i < SHADING_OFFSET_TBL_SIZE; i++) {
		this->ShdOfst[i] = 0;
	}
	this->DepthSlopeGain = 0x0400;
	this->DepthOfstVLU = 0;
	this->DepthMax = 0xfff;

    this->DepthCnvGain = 1.0;

	// IR
	this->IRDGain = 256;
	this->IRImgSel = 0;
	this->IRGmmX[0] = 0;
	this->IRGmmY[0] = 0;
        this->__iniFileIRGmmY[0] = 0;
	uint8 gpwr[IR_GAMMA_PWR_TBL_SIZE - 1] = { 9, 9, 9, 9, 9, 9, 9, 8, 8 };
	for (int i = 0; i < IR_GAMMA_PWR_TBL_SIZE - 1; i++) {
		this->IRGmmPwr[i] = gpwr[i];
		this->IRGmmX[i + 1] = (1 << this->IRGmmPwr[i]) + this->IRGmmX[i];
		this->IRGmmY[i + 1] = this->IRGmmX[i + 1] >> 2;
        this->__iniFileIRGmmY[i + 1] = 0;
	}

    // Output
    OutputBGSel = 0;
    OutputIntrlvSel = 0;

    OutputEnable = (OUTPUT_MIPI_ENA | OUTPUT_DEPTH_ENA | OUTPUT_IR_ENA);
    RateAdjHdPeriod = 928;

	// Checker ??
    this->ChkrDetEna = 0;
	this->ChkrStartH = 0;
	this->ChkrStartV = 0;
	this->ChkrSizeH = 32;
	this->ChkrUpprTh = 0x0FFF;
	this->ChkrLwrTh = 0x0000;
	this->ChkrUpprErrH = 0;
	this->ChkrLwrErrH = 0;
	this->ChkrUpprErrV = 0;
	this->ChkrLwrErrV = 0;

	this->xferType=1;
	if (filename != NULL) {
		ParamInit(filename);
	}
}

Param::~Param()
{
}

errcode_t Param::ParamInit(char *filename)
{
	int i;
	char psEntry[MAX_LINE_SIZE];
	FILE *fp = NULL;
	errcode_t ec = EC_OK;

	if (!filename)
	{
		return EC_BAD_ARG;
		
	}
	else {
        fp = fopen(filename, "r");
        if (!fp) {
            printf("Param Init : Failed to open parameter file: %s\n", filename);
			return EC_FAIL;
		}
	}

	/* Extract the various parameters from the supplied file */
	if (FindEntry(psEntry, "ImgSensorType", fp) == 0) {
        sscanf(psEntry, "%d", (int*) &this->eImgSensorType );
	}

	if (FindEntry(psEntry, "AFEPart", fp) == 0) {
        sscanf(psEntry, "%d", (int*) &this->eAfePart );
	}

	if (FindEntry(psEntry, "RawMode", fp) == 0) {
        sscanf(psEntry, "%hhu", (int*) &this->ucRawMode );
	}

	if (FindEntry(psEntry, "DepthMode", fp) == 0) {
        sscanf(psEntry, "%hhu", &this->ucDepthMode );
	}

	if (FindEntry(psEntry, "DepthRange", fp) == 0) {
        if (!strncmp("NEAR", psEntry, MAX_LINE_SIZE)) {
			this->eDepthRange = DEPTH_RANGE_NEAR;
		}
        if (!strncmp("XNEAR", psEntry, MAX_LINE_SIZE)) {
			this->eDepthRange = DEPTH_RANGE_XNEAR;
		}
        else if (!strncmp("MID", psEntry, MAX_LINE_SIZE)) {
			this->eDepthRange = DEPTH_RANGE_MID;
		}
        else if (!strncmp("FAR", psEntry, MAX_LINE_SIZE)) {
			this->eDepthRange = DEPTH_RANGE_FAR;
		}
        else if (!strncmp("XFAR", psEntry, MAX_LINE_SIZE)) {
			this->eDepthRange = DEPTH_RANGE_XFAR;
		}
	}

	if (FindEntry(psEntry, "LDPulseCnt", fp) == 0) {
        sscanf(psEntry, "%hu", &this->unLDPulseCnt );
	}

	if (FindEntry(psEntry, "LDEnable", fp) == 0) {
		sscanf(psEntry, "%hu", &this->unLaserEnaReg);
	}
	
	if (FindEntry(psEntry, "InWidth", fp) == 0) {
                sscanf(psEntry, "%u", &this->uiInWidth );
		// if (this->eImgSensorType >= SXGA_V1) {
		// 	this->uiProcWidth = this->uiInWidth >> 1;
		// }
		// else {
		// 	this->uiProcWidth = this->uiInWidth;
		// }
                SetProcWidth();
	}

	if (FindEntry(psEntry, "InHeight", fp) == 0) {
                sscanf(psEntry, "%u", &this->uiInHeight );
		// if (this->eImgSensorType >= SXGA_V1) {
		// 	this->uiProcHeight = (this->uiInHeight / 3) << 2;
		// }
		// else {
		// 	this->uiProcHeight = (this->uiInHeight / 3) << 1;
		// }
                SetProcHeight();
	}

    // ROI Paramters (Not implemented for ADDI9030, just ADDI9033 only)
	if (FindEntry(psEntry, "OutWidth", fp) == 0) {
             sscanf(psEntry, "%u", &this->uiOutWidth );
	}

	if (FindEntry(psEntry, "OutHStart", fp) == 0) {
             sscanf(psEntry, "%u", &this->uiOutHStart );
	}

    if (FindEntry(psEntry, "OutHeight", fp) == 0) {
             sscanf(psEntry, "%u", &this->uiOutHeight );
	}

	if (FindEntry(psEntry, "OutVStart", fp) == 0) {
             sscanf(psEntry, "%u", &this->uiOutVStart );
	}



	if (FindEntry(psEntry, "OutputPath", fp) == 0) {
             strncpy(this->cOutputPath, psEntry, MAX_LINE_SIZE );
	}

	if (FindEntry(psEntry, "OutputSeparateDataSw", fp) == 0) {
             sscanf(psEntry, "%hhu", &this->OutputSeparateDataSw );
	}

	if (FindEntry(psEntry, "OutputMedianDataSw", fp) == 0) {
             sscanf(psEntry, "%hhu", &this->OutputMedianDataSw );
	}

	if (FindEntry(psEntry, "OutputTransDataSw", fp) == 0) {
             sscanf(psEntry, "%hhu", &this->OutputTransDataSw );
	}

	if (FindEntry(psEntry, "OutputMixTransDataSw", fp) == 0) {
             sscanf(psEntry, "%hhu", &this->OutputMixTransDataSw );
	}

	if (FindEntry(psEntry, "OutputRawNrDataSw", fp) == 0) {
             sscanf(psEntry, "%hhu", &this->OutputRawNrDataSw );
	}

	if (FindEntry(psEntry, "OutputCoringDataSw", fp) == 0) {
             sscanf(psEntry, "%hhu", &this->OutputCoringDataSw );
	}

	if (FindEntry(psEntry, "OutputDepthDataSw", fp) == 0) {
             sscanf(psEntry, "%hhu", &this->OutputDepthDataSw );
	}

	if (FindEntry(psEntry, "OutputDepthRelateDataSw", fp) == 0) {
             sscanf(psEntry, "%hhu", &this->OutputDepthRelateDataSw );
	}

	if (FindEntry(psEntry, "OutputDepthOutDataSw", fp) == 0) {
             sscanf(psEntry, "%hhu", &this->OutputDepthOutDataSw );
	}

	if (FindEntry(psEntry, "OutputIrOutDataSw", fp) == 0) {
             sscanf(psEntry, "%hhu", &this->OutputIrOutDataSw );
	}

	if (FindEntry(psEntry, "InjPostReorderSw", fp) == 0) {
             sscanf(psEntry, "%hhu", &this->InjPostReorderSw );
	}

	if (FindEntry(psEntry, "InjPostReorderA0", fp) == 0) {
             strncpy(this->InjPostReorderA0, psEntry, MAX_LINE_SIZE);
	}

	if (FindEntry(psEntry, "InjPostReorderA1", fp) == 0) {
             strncpy(this->InjPostReorderA1, psEntry, MAX_LINE_SIZE);
	}

	if (FindEntry(psEntry, "InjPostReorderA2", fp) == 0) {
             strncpy(this->InjPostReorderA2, psEntry, MAX_LINE_SIZE);
	}

	if (FindEntry(psEntry, "InjPostGridSw", fp) == 0) {
             sscanf(psEntry, "%hhu", &this->InjPostGridSw );
	}

	if (FindEntry(psEntry, "InjPostGridA0", fp) == 0) {
             strncpy(this->InjPostGridA0, psEntry, MAX_LINE_SIZE );
	}

	if (FindEntry(psEntry, "InjPostGridA1", fp) == 0) {
             strncpy(this->InjPostGridA1, psEntry, MAX_LINE_SIZE );
	}

	if (FindEntry(psEntry, "InjPostGridA2", fp) == 0) {
             strncpy(this->InjPostGridA2, psEntry, MAX_LINE_SIZE);
	}

	if (FindEntry(psEntry, "M3W_SEL", fp) == 0) {
             sscanf(psEntry, "%hhu", &this->ucM3WSel );
	}

	if (FindEntry(psEntry, "GRIDVGA_SEL", fp) == 0) {
             sscanf(psEntry, "%hhu", &this->ucGridVGASel );
	}
	
	if (FindEntry(psEntry, "TOFSTART_HDCNT", fp) == 0) {
        sscanf(psEntry, "%hu", &this->ToFStartHDCnt );
        // The ProcHeight depends on this parameter so we must call that function here
        SetProcHeight();
	}

	if (FindEntry(psEntry, "TOFSTART_PIXCNT", fp) == 0) {
        sscanf(psEntry, "%hu", &this->ToFStartPixCnt );
        // The ProcWidth depends on this parameter so we must call that function here
        SetProcWidth();
	}

	if (FindEntry(psEntry, "DFCT_PIX_ENBL", fp) == 0) {
             sscanf(psEntry, "%hhu", &this->DfctPixEna );
	}

	if (FindEntry(psEntry, "DFCT_MED_REF_SEL", fp) == 0) {
             sscanf(psEntry, "%hhu", &this->DfctMedRefSel );
	}

	if (FindEntry(psEntry, "DFCT_DET_BSLN_SEL", fp) == 0) {
             sscanf(psEntry, "%hhu", &this->DfctDetBslnSel );
	}

	if (FindEntry(psEntry, "DFCT_PIX_SAT_TH", fp) == 0) {
             sscanf(psEntry, "%hx", &this->DfctPixSatTh );
	}

	if (FindEntry(psEntry, "DFCT_PIX_TH_TBL", fp) == 0) {
		for (i = 0; i<DFCT_TH_TBL_SIZE; i++) {
                   fscanf(fp, "%hx", (unsigned short *) &this->DfctThrTbl[i]);
		}
	}

	if (FindEntry(psEntry, "OBCLMPLEV", fp) == 0) {
             sscanf(psEntry, "%hu", &this->OBClmpLev );
	}

	if (FindEntry(psEntry, "VGASHRT_XOFST", fp) == 0) {
             sscanf(psEntry, "%hu", &this->VGAShrtXOfst );
	}

	if (FindEntry(psEntry, "VGASHRT_XPWR", fp) == 0) {
             sscanf(psEntry, "%hhu", &this->VGAShrtXPwr );
	}

	if (FindEntry(psEntry, "VGALNG_SAT_TH", fp) == 0) {
             sscanf(psEntry, "%hx", &this->VGALngSatTh );
	}

	if (FindEntry(psEntry, "KS_VGA_SHRT2LNG", fp) == 0) {
             sscanf(psEntry, "%hx", &this->KsVGAShrt2Lng );
	}

	if (FindEntry(psEntry, "WDR_BITSFT", fp) == 0) {
             sscanf(psEntry, "%hhu", &this->WDRBitSft );
	}

	if (FindEntry(psEntry, "RawNREna", fp) == 0) {
             sscanf(psEntry, "%hhu", &this->RawNREna );
	}

	if (FindEntry(psEntry, "RAWNR_MED4BL1_SEL", fp) == 0) {
             sscanf(psEntry, "%hhu", &this->RawNRMed4Bl1Sel );
	}

	if (FindEntry(psEntry, "RAWNR_MED4BL1_GAIN", fp) == 0) {
             sscanf(psEntry, "%hu", &this->RawNRMed4Bl1Gain );
	}

	if (FindEntry(psEntry, "RAWNR_SAT_TH", fp) == 0) {
             sscanf(psEntry, "%hx", &this->RawNRSatTh );
	}

	if (FindEntry(psEntry, "RAWNR_XPWR", fp) == 0) {
		this->RawNRXVal[0] = 0;
		for (i = 0; i<RAWNR_XPWR_TBL_SIZE; i++) {
                        fscanf(fp, "%hhu", &this->RawNRXPwr[i]);
			this->RawNRXVal[i + 1] = (1 << this->RawNRXPwr[i]) + this->RawNRXVal[i];
		}
	}

	if (FindEntry(psEntry, "RAWNR_BL_TBL", fp) == 0) {
		for (i = 0; i<RAWNR_YVAL_TBL_SIZE; i++) {
                     fscanf(fp, "%hu", &this->RawNRBlTbl[i] );
		}
	}

	if (FindEntry(psEntry, "RAWNR_BK_TBL", fp) == 0) {
		for (i = 0; i<RAWNR_YVAL_TBL_SIZE; i++) {
                     fscanf(fp, "%hu", &this->RawNRBkTbl[i] );
		}
	}


	if (FindEntry(psEntry, "CoefTbl", fp) == 0) {
		for (i = 0; i<NR_FLT_COEF_TBL_SIZE; i++) {
                     fscanf(fp, "%hu", &this->unCoefIn[i] );
		}


		// Distribute 7x7 coefficients
		// Pixel postion array
		uint8 ucCoefIdx[49] =
		{ 9, 8, 7, 6, 7, 8, 9,
		8, 5, 4, 3, 4, 5, 8,
		7, 4, 2, 1, 2, 4, 7,
		6, 3, 1, 0, 1, 3, 6,
		7, 4, 2, 1, 2, 4, 7,
		8, 5, 4, 3, 4, 5, 8,
		9, 8, 7, 6, 7, 8, 9 };

		for (i = 0; i<49; i++) {
			memcpy(&this->unCoefTbl[i][0], &this->unCoefIn[ucCoefIdx[i] * 7], 7 * sizeof(uint16));
		}
	}

	if (FindEntry(psEntry, "SmSigRmvEna", fp) == 0) {
             sscanf(psEntry, "%hhu", &this->ucSmSigRmvEna);
	}

	if (FindEntry(psEntry, "S0S1_CORTH", fp) == 0) {
             sscanf(psEntry, "%hx", &this->S0S1CorTh);
	}

	if (FindEntry(psEntry, "CORTH_DET_GAINF", fp) == 0) {
             sscanf(psEntry, "%hu", &this->CorThDetGainF );
	}

	if (FindEntry(psEntry, "CORTH_DET_CNTF", fp) == 0) {
             sscanf(psEntry, "%hhu", &this->CorThDetCntF );
	}

	if (FindEntry(psEntry, "CORTH_SFT_GAINF", fp) == 0) {
             sscanf(psEntry, "%hu", &this->CorThSftGainF );
	}

	if (FindEntry(psEntry, "CORTH_SFT_INC_OFST", fp) == 0) {
             sscanf(psEntry, "%hd", &this->CorThSftIncOfst );
	}

	if (FindEntry(psEntry, "CORTH_SFT_DEC_OFST", fp) == 0) {
             sscanf(psEntry, "%hd", &this->CorThSftDecOfst );
	}

	if (FindEntry(psEntry, "CORTH_DET_GAINB", fp) == 0) {
             sscanf(psEntry, "%hu", &this->CorThDetGainB );
	}

	if (FindEntry(psEntry, "CORTH_DET_CNTB", fp) == 0) {
             sscanf(psEntry, "%hhu", &this->CorThDetCntB );
	}

	if (FindEntry(psEntry, "CORTH_SFT_GAINB", fp) == 0) {
             sscanf(psEntry, "%hu", &this->CorThSftGainB );
	}

	if (FindEntry(psEntry, "DEPTHCALC_ADDVLU", fp) == 0) {
             sscanf(psEntry, "%hx", &this->DepthCalcAddVLU );
	}

	if (FindEntry(psEntry, "LNR_OFST", fp) == 0) {
		for (i = 0; i<LNR_OFFSET_VAL_TBL_SIZE; i++) {
                    fscanf(fp, "%hd", &this->LnrOfst[i] );
		}
	}

	if (FindEntry(psEntry, "LNR_X0", fp) == 0) {
             sscanf(psEntry, "%hd", &this->LnrX0 );
	}

	if (FindEntry(psEntry, "LNR_XPWR", fp) == 0) {
		for (i = 0; i<LNR_OFFSET_XPWR_TBL_SIZE; i++) {
            fscanf(fp, "%hhu", &this->LnrXPwr[i] );
		}
	}

	if (FindEntry(psEntry, "INTRINSIC", fp) == 0) {
		for (i = 0; i<INTRINSIC_TBL_SIZE; i++) {
			fscanf(fp, "%f", &this->fIntrinsic[i]);
		}
	}

	if (FindEntry(psEntry, "DISTORTION_COEFF", fp) == 0) {
		for (i = 0; i<DISTORTION_TBL_SIZE; i++) {
			fscanf(fp, "%lf", &this->dDistortionCoeff[i]);
		}
	}

	if (FindEntry(psEntry, "DEPTH_ZEROCORRE", fp) == 0) {
             sscanf(psEntry, "%hd", &this->DepthZeroCorre );
	}

	if (FindEntry(psEntry, "SHD_OFST_ENBL", fp) == 0) {
             sscanf(psEntry, "%hhu", &this->ucShdOfstEna );
	}

	if (FindEntry(psEntry, "SHD_X0", fp) == 0) {
             sscanf(psEntry, "%hd", &this->Shd_X0 );
	}

	if (FindEntry(psEntry, "SHD_Y0", fp) == 0) {
             sscanf(psEntry, "%hd", &this->Shd_Y0 );
	}

	if (FindEntry(psEntry, "SHD_XPWR", fp) == 0) {
		for (i = 0; i<SHADING_XPWR_TBL_SIZE; i++) {
                    fscanf(fp, "%hhu", &this->ShdXPwr[i] );
		}
	}

	if (FindEntry(psEntry, "SHD_YPWR", fp) == 0) {
		for (i = 0; i<SHADING_YPWR_TBL_SIZE; i++) {
                    fscanf(fp, "%hhu", &this->ShdYPwr[i] );
		}
	}

	if (FindEntry(psEntry, "SHD_OFST,", fp) == 0) {
		for (i = 0; i<SHADING_OFFSET_TBL_SIZE; i++) {
			int16 offset;
                        fscanf(fp, "%hd", &offset );
			this->ShdOfst[i] = 2 * offset;
		}
	}

	if (FindEntry(psEntry, "DEPTH_SLOPE_GAIN", fp) == 0) {
             sscanf(psEntry, "%hx", &this->DepthSlopeGain );
	}

	if (FindEntry(psEntry, "DEPTH_OFSTVLU", fp) == 0) {
             sscanf(psEntry, "%hd", &this->DepthOfstVLU );
	}

	if (FindEntry(psEntry, "DEPTH_MAX", fp) == 0) {
             sscanf(psEntry, "%hx", &this->DepthMax );
	}

	if (FindEntry(psEntry, "DEPTH_CNV_GAIN", fp) == 0) {
             sscanf(psEntry, "%f", &this->DepthCnvGain );
	}

	if (FindEntry(psEntry, "IR_DGAIN", fp) == 0) {
             sscanf(psEntry, "%hu", &this->IRDGain );
	}

	if (FindEntry(psEntry, "IRIMG_SEL", fp) == 0) {
             sscanf(psEntry, "%hhu", &this->IRImgSel );
	}

	if (FindEntry(psEntry, "IR_GMM_PWR", fp) == 0) {
		for (i = 0; i<IR_GAMMA_PWR_TBL_SIZE - 1; i++) {
                        fscanf(fp, "%hhu", &this->IRGmmPwr[i] );
			this->IRGmmX[i + 1] = (1 << this->IRGmmPwr[i]) + this->IRGmmX[i];
		}
	}

	if (FindEntry(psEntry, "IR_GMM_Y", fp) == 0) {
		uint16 unDeltaY;
		for (i = 1; i<IR_GAMMA_PWR_TBL_SIZE; i++) {
            fscanf(fp, "%hx", &unDeltaY );
            this->__iniFileIRGmmY[i - 1] = unDeltaY;
            this->IRGmmY[i] = this->IRGmmY[i - 1] + unDeltaY;
		}
	}

    if (FindEntry(psEntry, "OUTPUT_BG_SEL", fp) == 0) {
        sscanf(psEntry, "%hhu", &this->OutputBGSel);
    }

    if (FindEntry(psEntry, "OUTPUT_INTRLV_SEL", fp) == 0) {
        sscanf(psEntry, "%hhu", &this->OutputIntrlvSel);
    }

    if (FindEntry(psEntry, "CHKR_DET_ENA", fp) == 0) {
             sscanf(psEntry, "%hhu", &this->ChkrDetEna );
	}

	if (FindEntry(psEntry, "CHKR_DET_TYPE_SEL", fp) == 0) {
             sscanf(psEntry, "%hhu", &this->ChkrDetTypeSel );
	}
	
	if (FindEntry(psEntry, "CHKR_START_H", fp) == 0) {
             sscanf(psEntry, "%hu", &this->ChkrStartH );
	}

	if (FindEntry(psEntry, "CHKR_START_V", fp) == 0) {
             sscanf(psEntry, "%hu", &this->ChkrStartV );
	}

	if (FindEntry(psEntry, "CHKR_SIZE_H", fp) == 0) {
             sscanf(psEntry, "%hhu", &this->ChkrSizeH );
	}

	if (FindEntry(psEntry, "CHKR_UPPRTH", fp) == 0) {
             sscanf(psEntry, "%hx", &this->ChkrUpprTh );
	}

	if (FindEntry(psEntry, "CHKR_LWRTH", fp) == 0) {
             sscanf(psEntry, "%hx", &this->ChkrLwrTh );
	}

	if (FindEntry(psEntry, "CHKR_UPPRERR_H", fp) == 0) {
             sscanf(psEntry, "%hhu", &this->ChkrUpprErrH );
	}

	if (FindEntry(psEntry, "CHKR_LWRERR_H", fp) == 0) {
             sscanf(psEntry, "%hhu", &this->ChkrLwrErrH );
	}

	if (FindEntry(psEntry, "CHKR_UPPRERR_V", fp) == 0) {
             sscanf(psEntry, "%hhu", &this->ChkrUpprErrV );
	}

	if (FindEntry(psEntry, "CHKR_LWRERR_V", fp) == 0) {
             sscanf(psEntry, "%hhu", &this->ChkrLwrErrV );
	}

	if (FindEntry(psEntry, "CHKR_STARTOFST_H", fp) == 0) {
          // djs (Fix): Changed to match hex input string.
          //            sscanf(psEntry, "%hhu", &this->ChkrStrtOfstH );
          sscanf(psEntry, "%hhu", &this->ChkrStrtOfstH );
	}

	if (FindEntry(psEntry, "SPI_TYPE", fp) == 0) {
          // djs (Fix): Changed to match hex input string.
          //            sscanf(psEntry, "%hhu", &this->ChkrStrtOfstH );
          sscanf(psEntry, "%hhu", &this->xferType );
	}
	

	if (fp) {
		fclose(fp);
	}
	return ec;
}

int Param::FindEntry(char *pcEntry, char *pcKeyword, FILE *fp)
{
	char cBuf[MAX_LINE_SIZE];
	char *pBuf = cBuf;
	int iKwSize = strlen(pcKeyword);
	bool bKeywordFound = false;

	/* Verify all input */
	if (pcEntry == NULL || pcKeyword == NULL || fp == NULL) {
		return -1;
	}

	/* Go to the beginning of the file */
	rewind(fp);

	/* Search for keyword one line at a time */
    while (NULL != fgets(cBuf, MAX_LINE_SIZE, fp)) {
		if (strncmp(pBuf, pcKeyword, iKwSize) == 0) {
			bKeywordFound = true;
			break;
		}
	}

	/* If the keyword is found, return with a pointer to the matching parameter */
	if (bKeywordFound) {
		pBuf += iKwSize + 1;
                sscanf(pBuf, "%s", pcEntry);
		return 0;
	}

	return -1;
}

// Create a member function callable from outside the class, so that when uiInWidth
//   is set, uiProcWidth is set as well.
void Param::SetProcWidth(void)
{
    // The width needs to be reduced by the start location amount since InWidth
    // is the total width of the data coming in but the valid data doesn't start
    // until after teh start location
    if (this->eImgSensorType >= SXGA_V1) {
        this->uiProcWidth = this->uiInWidth >> 1 - this->ToFStartPixCnt;
    }
    else {
        this->uiProcWidth = this->uiInWidth - this->ToFStartPixCnt;
    }
}

// Create a member function callable from outside the class, so that when uiInHeight
//   is set, uiProcHeight is set as well.
void Param::SetProcHeight(void)
{
    // The height needs to be reduced by the start location amount since InHeight
    // is the total height of the data coming in but the valid data doesn't start
    // until after teh start location
    if (this->eImgSensorType >= SXGA_V1) {
        this->uiProcHeight = ((this->uiInHeight - this->ToFStartHDCnt) / 3) << 2;
    }
    else {
        this->uiProcHeight = ((this->uiInHeight - this->ToFStartHDCnt) / 3) << 1;
    }
}

// Write an A-Model Parameter file to the passed in filename.
errcode_t Param::AmodelParamWrite(char *filename)
{

        int i;
        char psEntry[MAX_LINE_SIZE];
        FILE *fp = NULL;
        errcode_t ec = EC_OK;

        if (!filename)
        {
	        return EC_BAD_ARG;
                
        }
        else {
            fp = fopen( filename, "w");
            if (!fp) {
                    printf("Failed to open parameter output file: %s\n", filename);
                    return EC_FAIL;
            }
        }

        /* Write the various parameters from the supplied file */
        // if (FindEntry(psEntry, "ImgSensorType", fp) == 0) {
        //      sscanf(psEntry, "%d", &this->eImgSensorType, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%d", this->eImgSensorType);
        AddSingleValueEntry(psEntry, "ImgSensorType", fp);
        
        
        // if (FindEntry(psEntry, "DepthMode", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ucDepthMode, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->ucDepthMode);
        AddSingleValueEntry(psEntry, "DepthMode", fp);

        // if (FindEntry(psEntry, "InWidth", fp) == 0) {
        //      sscanf(psEntry, "%u", &this->uiInWidth );
        // }
        sprintf(psEntry, "%u", this->uiInWidth);
        AddSingleValueEntry(psEntry, "InWidth", fp);

        //if (FindEntry(psEntry, "InHeight", fp) == 0) {
        //      sscanf(psEntry, "%u", &this->uiInHeight );
        // }
        sprintf(psEntry, "%u", this->uiInHeight);
        AddSingleValueEntry(psEntry, "InHeight", fp);

        // if (FindEntry(psEntry, "OutWidth", fp) == 0) {
        //      sscanf(psEntry, "%u", &this->uiOutWidth );
        // }
        sprintf(psEntry, "%u", this->uiOutWidth);
        AddSingleValueEntry(psEntry, "OutWidth", fp);

        // if (FindEntry(psEntry, "OutHeight", fp) == 0) {
        //      sscanf(psEntry, "%u", &this->uiOutHeight );
        // }
        sprintf(psEntry, "%u", this->uiOutHeight);
        AddSingleValueEntry(psEntry, "OutHeight", fp);

        // if (FindEntry(psEntry, "OutputPath", fp) == 0) {
        //       strncpy(this->cOutputPath, psEntry, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%s", this->cOutputPath);
        AddSingleValueEntry(psEntry, "OutputPath", fp);
        

        // if (FindEntry(psEntry, "OutputSeparateDataSw", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->OutputSeparateDataSw );
        // }
        sprintf(psEntry, "%hhu", this->OutputSeparateDataSw);
        AddSingleValueEntry(psEntry, "OutputSeparateDataSw", fp);

        // if (FindEntry(psEntry, "OutputMedianDataSw", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->OutputMedianDataSw );
        // }
        sprintf(psEntry, "%hhu", this->OutputMedianDataSw);
        AddSingleValueEntry(psEntry, "OutputMedianDataSw", fp);

        // if (FindEntry(psEntry, "OutputTransDataSw", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->OutputTransDataSw );
        // }
        sprintf(psEntry, "%hhu", this->OutputTransDataSw);
        AddSingleValueEntry(psEntry, "OutputTransDataSw", fp);

        // if (FindEntry(psEntry, "OutputMixTransDataSw", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->OutputMixTransDataSw );
        // }
        sprintf(psEntry, "%hhu", this->OutputMixTransDataSw);
        AddSingleValueEntry(psEntry, "OutputMixTransDataSw", fp);

        // if (FindEntry(psEntry, "OutputRawNrDataSw", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->OutputRawNrDataSw );
        // }
        sprintf(psEntry, "%hhu", this->OutputRawNrDataSw);
        AddSingleValueEntry(psEntry, "OutputRawNrDataSw", fp);

        // if (FindEntry(psEntry, "OutputCoringDataSw", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->OutputCoringDataSw );
        // }
        sprintf(psEntry, "%hhu", this->OutputCoringDataSw);
        AddSingleValueEntry(psEntry, "OutputCoringDataSw", fp);

        // if (FindEntry(psEntry, "OutputDepthDataSw", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->OutputDepthDataSw );
        // }
        sprintf(psEntry, "%hhu", this->OutputDepthDataSw);
        AddSingleValueEntry(psEntry, "OutputDepthDataSw", fp);

        // if (FindEntry(psEntry, "OutputDepthRelateDataSw", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->OutputDepthRelateDataSw );
        // }
        sprintf(psEntry, "%hhu", this->OutputDepthRelateDataSw);
        AddSingleValueEntry(psEntry, "OutputDepthRelateDataSw", fp);

        // if (FindEntry(psEntry, "OutputDepthOutDataSw", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->OutputDepthOutDataSw );
        // }
        sprintf(psEntry, "%hhu", this->OutputDepthOutDataSw);
        AddSingleValueEntry(psEntry, "OutputDepthOutDataSw", fp);

        // if (FindEntry(psEntry, "OutputIrOutDataSw", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->OutputIrOutDataSw );
        // }
        sprintf(psEntry, "%hhu", this->OutputIrOutDataSw);
        AddSingleValueEntry(psEntry, "OutputIrOutDataSw", fp);

        // if (FindEntry(psEntry, "InjPostReorderSw", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->InjPostReorderSw );
        // }
        sprintf(psEntry, "%hhu", this->InjPostReorderSw);
        AddSingleValueEntry(psEntry, "InjPostReorderSw", fp);

        // if (FindEntry(psEntry, "InjPostReorderA0", fp) == 0) {
        //       strncpy(this->InjPostReorderA0, psEntry );
        // }
        sprintf(psEntry, "%s", this->InjPostReorderA0);
        AddSingleValueEntry(psEntry, "InjPostReorderA0", fp);

        // if (FindEntry(psEntry, "InjPostReorderA1", fp) == 0) {
        //       strncpy(this->InjPostReorderA1, psEntry, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%s", this->InjPostReorderA1);
        AddSingleValueEntry(psEntry, "InjPostReorderA1", fp);

        // if (FindEntry(psEntry, "InjPostReorderA2", fp) == 0) {
        //       strncpy(this->InjPostReorderA2, psEntry, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%s", this->InjPostReorderA2);
        AddSingleValueEntry(psEntry, "InjPostReorderA2", fp);

        // if (FindEntry(psEntry, "InjPostGridSw", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->InjPostGridSw, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->InjPostGridSw);
        AddSingleValueEntry(psEntry, "InjPostGridSw", fp);

        // if (FindEntry(psEntry, "InjPostGridA0", fp) == 0) {
        //       strncpy(this->InjPostGridA0, psEntry, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%s", this->InjPostGridA0);
        AddSingleValueEntry(psEntry, "InjPostGridA0", fp);

        // if (FindEntry(psEntry, "InjPostGridA1", fp) == 0) {
        //       strncpy(this->InjPostGridA1, psEntry, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%s", this->InjPostGridA1);
        AddSingleValueEntry(psEntry, "InjPostGridA1", fp);

        // if (FindEntry(psEntry, "InjPostGridA2", fp) == 0) {
        //       strncpy(this->InjPostGridA2, psEntry, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%s", this->InjPostGridA2);
        AddSingleValueEntry(psEntry, "InjPostGridA2", fp);

        // if (FindEntry(psEntry, "M3W_SEL", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ucM3WSel, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->ucM3WSel);
        AddSingleValueEntry(psEntry, "M3W_SEL", fp);

        // if (FindEntry(psEntry, "GRIDVGA_SEL", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ucGridVGASel, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->ucGridVGASel);
        AddSingleValueEntry(psEntry, "GRIDVGA_SEL", fp);
        
        // if (FindEntry(psEntry, "TOFSTART_HDCNT", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->ToFStartHDCnt, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hu", this->ToFStartHDCnt);
        AddSingleValueEntry(psEntry, "TOFSTART_HDCNT", fp);

        // if (FindEntry(psEntry, "TOFSTART_PIXCNT", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->ToFStartPixCnt, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hu", this->ToFStartPixCnt);
        AddSingleValueEntry(psEntry, "TOFSTART_PIXCNT", fp);

        // if (FindEntry(psEntry, "DFCT_PIX_ENBL", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->DfctPixEna, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->DfctPixEna);
        AddSingleValueEntry(psEntry, "DFCT_PIX_ENBL", fp);

        // if (FindEntry(psEntry, "DFCT_MED_REF_SEL", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->DfctMedRefSel, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->DfctMedRefSel);
        AddSingleValueEntry(psEntry, "DFCT_MED_REF_SEL", fp);

        // if (FindEntry(psEntry, "DFCT_DET_BSLN_SEL", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->DfctDetBslnSel, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->DfctDetBslnSel);
        AddSingleValueEntry(psEntry, "DFCT_DET_BSLN_SEL", fp);

        // if (FindEntry(psEntry, "DFCT_PIX_SAT_TH", fp) == 0) {
        //      sscanf(psEntry, "%hx", &this->DfctPixSatTh, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "0x%04hX", this->DfctPixSatTh);
        AddSingleValueEntry(psEntry, "DFCT_PIX_SAT_TH", fp);

        /*
        if (FindEntry(psEntry, "DFCT_PIX_TH_TBL", fp) == 0) {
                for (i = 0; i<DFCT_TH_TBL_SIZE; i++) {
                        fscanf_s(fp, "%hx", &this->DfctThrTbl[i], MAX_LINE_SIZE);
                }
        }
        */
        for (i = 0; i<DFCT_TH_TBL_SIZE; i++) {
          sprintf(arrayStr1D[i], "0x%03hX", this->DfctThrTbl[i]);
        }
        AddOneDimensionalArrayAmodelEntry(arrayStr1D, DFCT_TH_TBL_SIZE, "DFCT_PIX_TH_TBL", fp);

        // if (FindEntry(psEntry, "OBCLMPLEV", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->OBClmpLev, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hu", this->OBClmpLev);
        AddSingleValueEntry(psEntry, "OBCLMPLEV", fp);

        // if (FindEntry(psEntry, "VGASHRT_XOFST", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->VGAShrtXOfst, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hu", this->VGAShrtXOfst);
        AddSingleValueEntry(psEntry, "VGASHRT_XOFST", fp);

        // if (FindEntry(psEntry, "VGASHRT_XPWR", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->VGAShrtXPwr, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->VGAShrtXPwr);
        AddSingleValueEntry(psEntry, "VGASHRT_XPWR", fp);

        // if (FindEntry(psEntry, "VGALNG_SAT_TH", fp) == 0) {
        //      sscanf(psEntry, "%hx", &this->VGALngSatTh, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "0x%04hX", this->VGALngSatTh);
        AddSingleValueEntry(psEntry, "VGALNG_SAT_TH", fp);

        // if (FindEntry(psEntry, "KS_VGA_SHRT2LNG", fp) == 0) {
        //      sscanf(psEntry, "%hx", &this->KsVGAShrt2Lng, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "0x%04hX", this->KsVGAShrt2Lng);
        AddSingleValueEntry(psEntry, "KS_VGA_SHRT2LNG", fp);

        // if (FindEntry(psEntry, "WDR_BITSFT", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->WDRBitSft, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->WDRBitSft);
        AddSingleValueEntry(psEntry, "WDR_BITSFT", fp);

        // if (FindEntry(psEntry, "RawNREna", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->RawNREna, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->RawNREna);
        AddSingleValueEntry(psEntry, "RawNREna", fp);

        // if (FindEntry(psEntry, "RAWNR_MED4BL1_SEL", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->RawNRMed4Bl1Sel, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->RawNRMed4Bl1Sel);
        AddSingleValueEntry(psEntry, "RAWNR_MED4BL1_SEL", fp);

        // if (FindEntry(psEntry, "RAWNR_MED4BL1_GAIN", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->RawNRMed4Bl1Gain, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hu", this->RawNRMed4Bl1Gain);
        AddSingleValueEntry(psEntry, "RAWNR_MED4BL1_GAIN", fp);

        // if (FindEntry(psEntry, "RAWNR_SAT_TH", fp) == 0) {
        //      sscanf(psEntry, "%hx", &this->RawNRSatTh, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "0x%04hX", this->RawNRSatTh);
        AddSingleValueEntry(psEntry, "RAWNR_SAT_TH", fp);

        /*
        if (FindEntry(psEntry, "RAWNR_XPWR", fp) == 0) {
                this->RawNRXVal[0] = 0;
                for (i = 0; i<RAWNR_XPWR_TBL_SIZE; i++) {
                        fscanf_s(fp, "%hhu", &this->RawNRXPwr[i], MAX_LINE_SIZE);
                        this->RawNRXVal[i + 1] = (1 << this->RawNRXPwr[i]) + this->RawNRXVal[i];
                }
        }
        */
        for (i = 0; i<RAWNR_XPWR_TBL_SIZE; i++) {
          sprintf(arrayStr1D[i], "%hu", this->RawNRXPwr[i]);
        }
        AddOneDimensionalArrayAmodelEntry(arrayStr1D, RAWNR_XPWR_TBL_SIZE, "RAWNR_XPWR", fp);

        /*
        if (FindEntry(psEntry, "RAWNR_BL_TBL", fp) == 0) {
                for (i = 0; i<RAWNR_YVAL_TBL_SIZE; i++) {
                        fscanf_s(fp, "%hu", &this->RawNRBlTbl[i], MAX_LINE_SIZE);
                }
        }
        */
        for (i = 0; i<RAWNR_YVAL_TBL_SIZE; i++) {
          //sprintf(arrayStr1D[i], "0x%03hX", this->RawNRBlTbl[i]);
          sprintf(arrayStr1D[i], "%hu", this->RawNRBlTbl[i]);
        }
        AddOneDimensionalArrayAmodelEntry(arrayStr1D, RAWNR_YVAL_TBL_SIZE, "RAWNR_BL_TBL", fp);

        /*
        if (FindEntry(psEntry, "RAWNR_BK_TBL", fp) == 0) {
                for (i = 0; i<RAWNR_YVAL_TBL_SIZE; i++) {
                        fscanf_s(fp, "%hu", &this->RawNRBkTbl[i], MAX_LINE_SIZE);
                }
        }
        */
        for (i = 0; i<RAWNR_YVAL_TBL_SIZE; i++) {
          sprintf(arrayStr1D[i], "%hu", this->RawNRBkTbl[i]);
        }
        AddOneDimensionalArrayAmodelEntry(arrayStr1D, RAWNR_YVAL_TBL_SIZE, "RAWNR_BK_TBL", fp);

        /*
        if (FindEntry(psEntry, "CoefTbl", fp) == 0) {
                for (i = 0; i<NR_FLT_COEF_TBL_SIZE; i++) {
                        fscanf_s(fp, "%hu", &unCoefIn[i], MAX_LINE_SIZE);
                }
        }
        */
        for (i = 0; i<NR_FLT_COEF_TBL_SIZE; i++) {
          sprintf(arrayStr1D[i], "%hu", this->unCoefIn[i]);
        }
        AddOneDimensionalArrayAmodelEntry(arrayStr1D, NR_FLT_COEF_TBL_SIZE, "CoefTbl", fp);

        /*
        // Distribute 7x7 coefficients
        // Pixel postion array
        uint8 ucCoefIdx[49] =
        { 9, 8, 7, 6, 7, 8, 9,
        8, 5, 4, 3, 4, 5, 8,
        7, 4, 2, 1, 2, 4, 7,
        6, 3, 1, 0, 1, 3, 6,
        7, 4, 2, 1, 2, 4, 7,
        8, 5, 4, 3, 4, 5, 8,
        9, 8, 7, 6, 7, 8, 9 };

        for (i = 0; i<49; i++) {
                memcpy(&this->unCoefTbl[i][0], &unCoefIn[ucCoefIdx[i] * 7], 7 * sizeof(uint16));
        }
        */

        // if (FindEntry(psEntry, "SmSigRmvEna", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ucSmSigRmvEna, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->ucSmSigRmvEna);
        AddSingleValueEntry(psEntry, "SmSigRmvEna", fp);

        // if (FindEntry(psEntry, "S0S1_CORTH", fp) == 0) {
        //      sscanf(psEntry, "%hx", &this->S0S1CorTh, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "0x%02hX", this->S0S1CorTh);
        AddSingleValueEntry(psEntry, "S0S1_CORTH", fp);

        // if (FindEntry(psEntry, "CORTH_DET_GAINF", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->CorThDetGainF, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hu", this->CorThDetGainF);
        AddSingleValueEntry(psEntry, "CORTH_DET_GAINF", fp);

        // if (FindEntry(psEntry, "CORTH_DET_CNTF", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->CorThDetCntF, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->CorThDetCntF);
        AddSingleValueEntry(psEntry, "CORTH_DET_CNTF", fp);

        // if (FindEntry(psEntry, "CORTH_SFT_GAINF", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->CorThSftGainF, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hu", this->CorThSftGainF);
        AddSingleValueEntry(psEntry, "CORTH_SFT_GAINF", fp);

        // if (FindEntry(psEntry, "CORTH_SFT_INC_OFST", fp) == 0) {
        //      sscanf(psEntry, "%hd", &this->CorThSftIncOfst, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hd", this->CorThSftIncOfst);
        AddSingleValueEntry(psEntry, "CORTH_SFT_INC_OFST", fp);

        // if (FindEntry(psEntry, "CORTH_SFT_DEC_OFST", fp) == 0) {
        //      sscanf(psEntry, "%hd", &this->CorThSftDecOfst, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hd", this->CorThSftDecOfst);
        AddSingleValueEntry(psEntry, "CORTH_SFT_DEC_OFST", fp);

        // if (FindEntry(psEntry, "CORTH_DET_GAINB", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->CorThDetGainB, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hu", this->CorThDetGainB);
        AddSingleValueEntry(psEntry, "CORTH_DET_GAINB", fp);

        // if (FindEntry(psEntry, "CORTH_DET_CNTB", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->CorThDetCntB, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->CorThDetCntB);
        AddSingleValueEntry(psEntry, "CORTH_DET_CNTB", fp);

        // if (FindEntry(psEntry, "CORTH_SFT_GAINB", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->CorThSftGainB, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hu", this->CorThSftGainB);
        AddSingleValueEntry(psEntry, "CORTH_SFT_GAINB", fp);

        // if (FindEntry(psEntry, "DEPTHCALC_ADDVLU", fp) == 0) {
        //      sscanf(psEntry, "%hx", &this->DepthCalcAddVLU, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "0x%04hX", this->DepthCalcAddVLU);
        AddSingleValueEntry(psEntry, "DEPTHCALC_ADDVLU", fp);

        /*
        if (FindEntry(psEntry, "LNR_OFST", fp) == 0) {
                for (i = 0; i<LNR_OFFSET_VAL_TBL_SIZE; i++) {
                        fscanf_s(fp, "%hd", &this->LnrOfst[i], MAX_LINE_SIZE);
                }
        }
        */
        for (i = 0; i<LNR_OFFSET_VAL_TBL_SIZE; i++) {
          sprintf(arrayStr1D[i], "%hd", this->LnrOfst[i]);
        }
        AddOneDimensionalArrayAmodelEntry(arrayStr1D, LNR_OFFSET_VAL_TBL_SIZE, "LNR_OFST", fp);
        
        // if (FindEntry(psEntry, "LNR_X0", fp) == 0) {
        //      sscanf(psEntry, "%hd", &this->LnrX0, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hd", this->LnrX0);
        AddSingleValueEntry(psEntry, "LNR_X0", fp);

        /*
        if (FindEntry(psEntry, "LNR_XPWR", fp) == 0) {
                for (i = 0; i<LNR_OFFSET_XPWR_TBL_SIZE; i++) {
                        fscanf_s(fp, "%hhu", &this->LnrXPwr[i], MAX_LINE_SIZE);
                }
        }
        */
        for (i = 0; i<LNR_OFFSET_XPWR_TBL_SIZE; i++) {
          sprintf(arrayStr1D[i], "%hu", this->LnrXPwr[i]);
        }
        AddOneDimensionalArrayAmodelEntry(arrayStr1D, LNR_OFFSET_XPWR_TBL_SIZE, "LNR_XPWR", fp);
        
        // if (FindEntry(psEntry, "DEPTH_ZEROCORRE", fp) == 0) {
        //      sscanf(psEntry, "%hd", &this->DepthZeroCorre, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hd", this->DepthZeroCorre);
        AddSingleValueEntry(psEntry, "DEPTH_ZEROCORRE", fp);

        // if (FindEntry(psEntry, "SHD_OFST_ENBL", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ucShdOfstEna, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->ucShdOfstEna);
        AddSingleValueEntry(psEntry, "SHD_OFST_ENBL", fp);

        // if (FindEntry(psEntry, "SHD_X0", fp) == 0) {
        //      sscanf(psEntry, "%hd", &this->Shd_X0, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hd", this->Shd_X0);
        AddSingleValueEntry(psEntry, "SHD_X0", fp);

        // if (FindEntry(psEntry, "SHD_Y0", fp) == 0) {
        //      sscanf(psEntry, "%hd", &this->Shd_Y0, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hd", this->Shd_Y0);
        AddSingleValueEntry(psEntry, "SHD_Y0", fp);

        /*
        if (FindEntry(psEntry, "SHD_XPWR", fp) == 0) {
                for (i = 0; i<SHADING_XPWR_TBL_SIZE; i++) {
                        fscanf_s(fp, "%hhu", &this->ShdXPwr[i], MAX_LINE_SIZE);
                }
        }
        */
        for (i = 0; i<SHADING_XPWR_TBL_SIZE; i++) {
          sprintf(arrayStr1D[i], "%hhu", this->ShdXPwr[i]);
        }
        AddOneDimensionalArrayAmodelEntry(arrayStr1D, SHADING_XPWR_TBL_SIZE, "SHD_XPWR", fp);
                
        /*
        if (FindEntry(psEntry, "SHD_YPWR", fp) == 0) {
                for (i = 0; i<SHADING_YPWR_TBL_SIZE; i++) {
                        fscanf_s(fp, "%hhu", &this->ShdYPwr[i], MAX_LINE_SIZE);
                }
        }
        */
        for (i = 0; i<SHADING_YPWR_TBL_SIZE; i++) {
          sprintf(arrayStr1D[i], "%hhu", this->ShdYPwr[i]);
        }
        AddOneDimensionalArrayAmodelEntry(arrayStr1D, SHADING_YPWR_TBL_SIZE, "SHD_YPWR", fp);
        
        /*
        if (FindEntry(psEntry, "SHD_OFST,", fp) == 0) {
                for (i = 0; i<SHADING_OFFSET_TBL_SIZE; i++) {
                        int16 offset;
                        fscanf_s(fp, "%hd", &offset, MAX_LINE_SIZE);
                        this->ShdOfst[i] = 2 * offset;
                }
        }
        */
        for (i = 0; i<SHADING_OFFSET_TBL_SIZE; i++) {
          sprintf(arrayStr1D[i], "%hd", this->ShdOfst[i]/2); // Account for post-read-in computation
        }
        AddOneDimensionalArrayAmodelEntry(arrayStr1D, SHADING_OFFSET_TBL_SIZE, "SHD_OFST", fp);
        
        // if (FindEntry(psEntry, "DEPTH_SLOPE_GAIN", fp) == 0) {
        //      sscanf(psEntry, "%hx", &this->DepthSlopeGain, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "0x%03hX", this->DepthSlopeGain);
        AddSingleValueEntry(psEntry, "DEPTH_SLOPE_GAIN", fp);

        // if (FindEntry(psEntry, "DEPTH_OFSTVLU", fp) == 0) {
        //      sscanf(psEntry, "%hd", &this->DepthOfstVLU, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hd", this->DepthOfstVLU);
        AddSingleValueEntry(psEntry, "DEPTH_OFSTVLU", fp);

        // if (FindEntry(psEntry, "IR_DGAIN", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->IRDGain, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hu", this->IRDGain);
        AddSingleValueEntry(psEntry, "IR_DGAIN", fp);

        // if (FindEntry(psEntry, "IRIMG_SEL", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->IRImgSel, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->IRImgSel);
        AddSingleValueEntry(psEntry, "IRIMG_SEL", fp);

        /*
        if (FindEntry(psEntry, "IR_GMM_PWR", fp) == 0) {
                for (i = 0; i<IR_GAMMA_PWR_TBL_SIZE - 1; i++) {
                        fscanf_s(fp, "%hhu", &this->IRGmmPwr[i], MAX_LINE_SIZE);
                        this->IRGmmX[i + 1] = (1 << this->IRGmmPwr[i]) + this->IRGmmX[i];
                }
        }
        */
        for (i = 0; i<IR_GAMMA_PWR_TBL_SIZE; i++) {
          sprintf(arrayStr1D[i], "%hhu", this->IRGmmPwr[i]);
        }
        AddOneDimensionalArrayAmodelEntry(arrayStr1D, IR_GAMMA_PWR_TBL_SIZE, "IR_GMM_PWR", fp);
        
        /*
        if (FindEntry(psEntry, "IR_GMM_Y", fp) == 0) {
                uint16 unDeltaY;
                for (i = 1; i<IR_GAMMA_PWR_TBL_SIZE; i++) {
                        fscanf_s(fp, "%hx", &unDeltaY, MAX_LINE_SIZE);
                        this->IRGmmY[i] = this->IRGmmY[i - 1] + unDeltaY;
                }
        }
        */
        for (i = 0; i<IR_GAMMA_PWR_TBL_SIZE; i++) {
          sprintf(arrayStr1D[i], "0x%04hx", this->__iniFileIRGmmY[i]); // the "__iniFile..." variable captures the original value
        }
        AddOneDimensionalArrayAmodelEntry(arrayStr1D, IR_GAMMA_PWR_TBL_SIZE, "IR_GMM_Y", fp);
        
        // if (FindEntry(psEntry, "OUTPUT_BG_SEL", fp) == 0) {
        //     sscanf(psEntry, "%hhu", &this->OutputBGSel);
        // }
        sprintf(psEntry, "%hhu", this->OutputBGSel);
        AddSingleValueEntry(psEntry, "OUTPUT_BG_SEL", fp);

        // if (FindEntry(psEntry, "OUTPUT_INTRLV_SEL", fp) == 0) {
        //     sscanf(psEntry, "%hhu", &this->OutputIntrlvSel);
        // }
        sprintf(psEntry, "%hhu", this->OutputIntrlvSel);
        AddSingleValueEntry(psEntry, "OUTPUT_INTRLV_SEL", fp);

        // if (FindEntry(psEntry, "CHKR_DET_ENA", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ChkrDetEna, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->ChkrDetEna);
        AddSingleValueEntry(psEntry, "CHKR_DET_ENA", fp);

        // if (FindEntry(psEntry, "CHKR_DET_TYPE_SEL", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ChkrDetTypeSel, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->ChkrDetTypeSel);
        AddSingleValueEntry(psEntry, "CHKR_DET_TYPE_SEL", fp);
        
        // if (FindEntry(psEntry, "CHKR_START_H", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->ChkrStartH, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hu", this->ChkrStartH);
        AddSingleValueEntry(psEntry, "CHKR_START_H", fp);

        // if (FindEntry(psEntry, "CHKR_START_V", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->ChkrStartV, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hu", this->ChkrStartV);
        AddSingleValueEntry(psEntry, "CHKR_START_V", fp);

        // if (FindEntry(psEntry, "CHKR_SIZE_H", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ChkrSizeH, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->ChkrSizeH);
        AddSingleValueEntry(psEntry, "CHKR_SIZE_H", fp);

        // if (FindEntry(psEntry, "CHKR_UPPRTH", fp) == 0) {
        //      sscanf(psEntry, "%hx", &this->ChkrUpprTh, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "0x%04hX", this->ChkrUpprTh);
        AddSingleValueEntry(psEntry, "CHKR_UPPRTH", fp);

        // if (FindEntry(psEntry, "CHKR_LWRTH", fp) == 0) {
        //      sscanf(psEntry, "%hx", &this->ChkrLwrTh, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "0x%04hX", this->ChkrLwrTh);
        AddSingleValueEntry(psEntry, "CHKR_LWRTH", fp);

        // if (FindEntry(psEntry, "CHKR_UPPRERR_H", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ChkrUpprErrH, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->ChkrUpprErrH);
        AddSingleValueEntry(psEntry, "CHKR_UPPRERR_H", fp);

        // if (FindEntry(psEntry, "CHKR_LWRERR_H", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ChkrLwrErrH, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->ChkrLwrErrH);
        AddSingleValueEntry(psEntry, "CHKR_LWRERR_H", fp);

        // if (FindEntry(psEntry, "CHKR_UPPRERR_V", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ChkrUpprErrV, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->ChkrUpprErrV);
        AddSingleValueEntry(psEntry, "CHKR_UPPRERR_V", fp);

        // if (FindEntry(psEntry, "CHKR_LWRERR_V", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ChkrLwrErrV, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->ChkrLwrErrV);
        AddSingleValueEntry(psEntry, "CHKR_LWRERR_V", fp);

        // if (FindEntry(psEntry, "CHKR_STARTOFST_H", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ChkrStrtOfstH, MAX_LINE_SIZE);
        // }
        // djs (Fix): Changed to match hex input string.
        //sprintf(psEntry, "%hhu", this->ChkrStrtOfstH);
        sprintf(psEntry, "0x%02hX", this->ChkrStrtOfstH);
        AddSingleValueEntry(psEntry, "CHKR_STARTOFST_H", fp);
        
        if (fp) {
                fclose(fp);
        }
        return ec;
}

// Adds a single-value entry to the parameter file, with the keyword
//   and the value separated by a comma.
int Param::AddSingleValueEntry(char *pcEntry, char *pcKeyword, FILE *fp)
{
        int ret_code = 0;
        
        /* Verify all input */
        if (pcEntry == NULL || pcKeyword == NULL || fp == NULL) {
                return -1;
        }

        ret_code = fprintf(fp, "%s,%s\n", pcKeyword, pcEntry);

        return ret_code;
}

// Adds a one dimensional array entry to the A-Model parameter file, with the keyword
//   and the single-line array separated by a comma and a newline.
int Param::AddOneDimensionalArrayAmodelEntry(array_str_t *arrayStr1D, unsigned int arrayLength, char *pcKeyword, FILE *fp)
{
        int ret_code = 0;
        
        /* Verify all input */
        if (arrayStr1D == NULL || pcKeyword == NULL || fp == NULL) {
                return -1;
        }

        ret_code = fprintf(fp, "%s,\n", pcKeyword);

        for (unsigned int i = 0; i < (arrayLength - 1); i++) {
          ret_code = fprintf(fp, "%s ", (char *) arrayStr1D++);
        }

        ret_code = fprintf(fp, "%s\n", (char *) arrayStr1D++);

        return ret_code;
}

// Write a P-Model Parameter file to the passed in filename.
// NOTE: This output is governed by the analysis done in the spreadsheet
//       stored in Models/trunk/tests/INI_File_Translation.xlsx and refined
//       with Trac Tickets
errcode_t Param::PmodelParamWrite(char *filename)
{

        int i;
        char psEntry[MAX_LINE_SIZE];
        FILE *fp = NULL;
        FILE *fpDepthShadingOffsetFile = NULL;
        errcode_t ec = EC_OK;

        if (!filename)
        {
	       return EC_BAD_ARG;
                
        }
        else {
            fp = fopen(filename, "w");
            if (!fp) {
                    printf("Failed to open parameter output file: %s\n", filename);
                    return EC_FAIL;
            }
        }

        // djs (Note): Currently only VGA sensors are supported by the P-Model
        /* Write the various parameters from the supplied file */
        // if (FindEntry(psEntry, "ImgSensorType", fp) == 0) {
        //      sscanf(psEntry, "%d", &this->eImgSensorType, MAX_LINE_SIZE);
        // }
        /*
        sprintf(psEntry, "%d", this->eImgSensorType);
        AddSingleValueEntry(psEntry, "ImgSensorType", fp);
        */

        // djs (Note): DepthMode is always 0 for the P_Model
        /*
        // if (FindEntry(psEntry, "DepthMode", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ucDepthMode, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->ucDepthMode);
        AddSingleValueEntry(psEntry, "DepthMode", fp);
        */

        // if (FindEntry(psEntry, "InWidth", fp) == 0) {
        //      sscanf(psEntry, "%u", &this->uiInWidth, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%u", this->uiInWidth);
        // AddSingleValueEntry(psEntry, "InWidth", fp);
        AddSingleValueEntry(psEntry, "ReadRaw_SizeH", fp);

        //if (FindEntry(psEntry, "InHeight", fp) == 0) {
        //      sscanf(psEntry, "%u", &this->uiInHeight, MAX_LINE_SIZE);
        //}
        sprintf(psEntry, "%u", this->uiInHeight);
        // AddSingleValueEntry(psEntry, "InHeight", fp);
        AddSingleValueEntry(psEntry, "ReadRaw_SizeV", fp);

        // if (FindEntry(psEntry, "OutWidth", fp) == 0) {
        //      sscanf(psEntry, "%u", &this->uiOutWidth, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%u", this->uiOutWidth);
        // AddSingleValueEntry(psEntry, "OutWidth", fp);
        AddSingleValueEntry(psEntry, "Depth_SizeH", fp);
        AddSingleValueEntry(psEntry, "DepthOut_EndPosH", fp);

        // if (FindEntry(psEntry, "OutHeight", fp) == 0) {
        //      sscanf(psEntry, "%u", &this->uiOutHeight, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%u", this->uiOutHeight);
        // AddSingleValueEntry(psEntry, "OutHeight", fp);
        AddSingleValueEntry(psEntry, "Depth_SizeV", fp);
        AddSingleValueEntry(psEntry, "DepthOut_EndPosV", fp);

        // if (FindEntry(psEntry, "OutputPath", fp) == 0) {
        //       strncpy(this->cOutputPath, psEntry, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%s", this->cOutputPath);
        // AddSingleValueEntry(psEntry, "OutputPath", fp);
        AddSingleValueEntry(psEntry, "OutputFolder", fp);
        

        // if (FindEntry(psEntry, "OutputSeparateDataSw", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->OutputSeparateDataSw, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->OutputSeparateDataSw);
        AddSingleValueEntry(psEntry, "OutputSeparateDataSw", fp);

        // if (FindEntry(psEntry, "OutputMedianDataSw", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->OutputMedianDataSw, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->OutputMedianDataSw);
        AddSingleValueEntry(psEntry, "OutputMedianDataSw", fp);

        // if (FindEntry(psEntry, "OutputTransDataSw", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->OutputTransDataSw, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->OutputTransDataSw);
        AddSingleValueEntry(psEntry, "OutputTransDataSw", fp);

        // if (FindEntry(psEntry, "OutputMixTransDataSw", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->OutputMixTransDataSw, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->OutputMixTransDataSw);
        AddSingleValueEntry(psEntry, "OutputMixTransDataSw", fp);

        // if (FindEntry(psEntry, "OutputRawNrDataSw", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->OutputRawNrDataSw, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->OutputRawNrDataSw);
        AddSingleValueEntry(psEntry, "OutputRawNrDataSw", fp);

        // if (FindEntry(psEntry, "OutputCoringDataSw", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->OutputCoringDataSw, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->OutputCoringDataSw);
        AddSingleValueEntry(psEntry, "OutputCoringDataSw", fp);

        // if (FindEntry(psEntry, "OutputDepthDataSw", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->OutputDepthDataSw, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->OutputDepthDataSw);
        AddSingleValueEntry(psEntry, "OutputDepthDataSw", fp);

        // if (FindEntry(psEntry, "OutputDepthRelateDataSw", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->OutputDepthRelateDataSw, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->OutputDepthRelateDataSw);
        AddSingleValueEntry(psEntry, "OutputDepthRelateDataSw", fp);

        // if (FindEntry(psEntry, "OutputDepthOutDataSw", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->OutputDepthOutDataSw, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->OutputDepthOutDataSw);
        AddSingleValueEntry(psEntry, "OutputDepthOutDataSw", fp);

        // if (FindEntry(psEntry, "OutputIrOutDataSw", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->OutputIrOutDataSw, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->OutputIrOutDataSw);
        AddSingleValueEntry(psEntry, "OutputIrOutDataSw", fp);

        // if (FindEntry(psEntry, "InjPostReorderSw", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->InjPostReorderSw, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->InjPostReorderSw);
        AddSingleValueEntry(psEntry, "InjPostReorderSw", fp);

        // if (FindEntry(psEntry, "InjPostReorderA0", fp) == 0) {
        //       strncpy(this->InjPostReorderA0, psEntry, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%s", this->InjPostReorderA0);
        AddSingleValueEntry(psEntry, "InjPostReorderA0", fp);

        // if (FindEntry(psEntry, "InjPostReorderA1", fp) == 0) {
        //       strncpy(this->InjPostReorderA1, psEntry, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%s", this->InjPostReorderA1);
        AddSingleValueEntry(psEntry, "InjPostReorderA1", fp);

        // if (FindEntry(psEntry, "InjPostReorderA2", fp) == 0) {
        //       strncpy(this->InjPostReorderA2, psEntry, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%s", this->InjPostReorderA2);
        AddSingleValueEntry(psEntry, "InjPostReorderA2", fp);

        // if (FindEntry(psEntry, "InjPostGridSw", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->InjPostGridSw, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->InjPostGridSw);
        AddSingleValueEntry(psEntry, "InjPostGridSw", fp);

        // if (FindEntry(psEntry, "InjPostGridA0", fp) == 0) {
        //       strncpy(this->InjPostGridA0, psEntry, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%s", this->InjPostGridA0);
        AddSingleValueEntry(psEntry, "InjPostGridA0", fp);

        // if (FindEntry(psEntry, "InjPostGridA1", fp) == 0) {
        //       strncpy(this->InjPostGridA1, psEntry, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%s", this->InjPostGridA1);
        AddSingleValueEntry(psEntry, "InjPostGridA1", fp);

        // if (FindEntry(psEntry, "InjPostGridA2", fp) == 0) {
        //       strncpy(this->InjPostGridA2, psEntry, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%s", this->InjPostGridA2);
        AddSingleValueEntry(psEntry, "InjPostGridA2", fp);

        // From Trac Ticket #257:
        //  There is one parameter pair, M3W_SEL/ToF_ExpMode, that have different values as follows:
        //
        //   M3W_SEL = 0 / ToF_ExpMode = 1 => Method 3
        //   M3W_SEL = 1 / ToF_ExpMode = 2 => Method 3W
        //
        // if (FindEntry(psEntry, "M3W_SEL", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ucM3WSel, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", (this->ucM3WSel) + 1);
        // AddSingleValueEntry(psEntry, "M3W_SEL", fp);
        AddSingleValueEntry(psEntry, "Tof_ExpMode", fp);

        // if (FindEntry(psEntry, "GRIDVGA_SEL", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ucGridVGASel, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->ucGridVGASel);
        // AddSingleValueEntry(psEntry, "GRIDVGA_SEL", fp);
        AddSingleValueEntry(psEntry, "ReadRaw_LongShort", fp);
        AddSingleValueEntry(psEntry, "Reg_GridVgaSel", fp);
        
        // if (FindEntry(psEntry, "TOFSTART_HDCNT", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->ToFStartHDCnt, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hu", this->ToFStartHDCnt);
        // AddSingleValueEntry(psEntry, "TOFSTART_HDCNT", fp);
        AddSingleValueEntry(psEntry, "ReadRaw_VPos", fp);

        // if (FindEntry(psEntry, "TOFSTART_PIXCNT", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->ToFStartPixCnt, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hu", this->ToFStartPixCnt);
        // AddSingleValueEntry(psEntry, "TOFSTART_PIXCNT", fp);
        AddSingleValueEntry(psEntry, "ReadRaw_HPos", fp);

        // if (FindEntry(psEntry, "DFCT_PIX_ENBL", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->DfctPixEna, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->DfctPixEna);
        // AddSingleValueEntry(psEntry, "DFCT_PIX_ENBL", fp);
        AddSingleValueEntry(psEntry, "Reg_KizMedSel", fp);

        // if (FindEntry(psEntry, "DFCT_MED_REF_SEL", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->DfctMedRefSel, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->DfctMedRefSel);
        // AddSingleValueEntry(psEntry, "DFCT_MED_REF_SEL", fp);
        AddSingleValueEntry(psEntry, "Reg_KizMedRefSel", fp);

        // if (FindEntry(psEntry, "DFCT_DET_BSLN_SEL", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->DfctDetBslnSel, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->DfctDetBslnSel);
        // AddSingleValueEntry(psEntry, "DFCT_DET_BSLN_SEL", fp);
        AddSingleValueEntry(psEntry, "Reg_KizBaseSel", fp);

        // if (FindEntry(psEntry, "DFCT_PIX_SAT_TH", fp) == 0) {
        //      sscanf(psEntry, "%hx", &this->DfctPixSatTh, MAX_LINE_SIZE);
        // }
        // sprintf(psEntry, "0x%04hX", this->DfctPixSatTh);
        sprintf(psEntry, "%hd", this->DfctPixSatTh);     // Decimal in "ParamPana.ini"
        // AddSingleValueEntry(psEntry, "DFCT_PIX_SAT_TH", fp);
        AddSingleValueEntry(psEntry, "Reg_S0S1SatTh", fp);

        /*
        if (FindEntry(psEntry, "DFCT_PIX_TH_TBL", fp) == 0) {
                for (i = 0; i<DFCT_TH_TBL_SIZE; i++) {
                        fscanf_s(fp, "%hx", &this->DfctThrTbl[i], MAX_LINE_SIZE);
                }
        }
        */
        for (i = 0; i<DFCT_TH_TBL_SIZE; i++) {
          // sprintf(arrayStr1D[i], "0x%03hX", this->DfctThrTbl[i]);
          sprintf(arrayStr1D[i], "%hd", this->DfctThrTbl[i]);  // Decimal in "ParamPana.ini"
        }
        // AddOneDimensionalArrayAmodelEntry(arrayStr1D, DFCT_TH_TBL_SIZE, "DFCT_PIX_TH_TBL", fp);
        AddOneDimensionalArrayPmodelEntry(arrayStr1D, DFCT_TH_TBL_SIZE, "Reg_KizNoiseTbl", fp);

        // if (FindEntry(psEntry, "OBCLMPLEV", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->OBClmpLev, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hu", this->OBClmpLev);
        // AddSingleValueEntry(psEntry, "OBCLMPLEV", fp);
        AddSingleValueEntry(psEntry, "Reg_VgaOBLev", fp);

        // if (FindEntry(psEntry, "VGASHRT_XOFST", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->VGAShrtXOfst, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hu", this->VGAShrtXOfst);
        // AddSingleValueEntry(psEntry, "VGASHRT_XOFST", fp);
        AddSingleValueEntry(psEntry, "Reg_VgaWdrXOfst", fp);

        // if (FindEntry(psEntry, "VGASHRT_XPWR", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->VGAShrtXPwr, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->VGAShrtXPwr);
        // AddSingleValueEntry(psEntry, "VGASHRT_XPWR", fp);
        AddSingleValueEntry(psEntry, "Reg_VgaWdrXPwr", fp);

        // if (FindEntry(psEntry, "VGALNG_SAT_TH", fp) == 0) {
        //      sscanf(psEntry, "%hx", &this->VGALngSatTh, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hd", this->VGALngSatTh);
        // AddSingleValueEntry(psEntry, "VGALNG_SAT_TH", fp);
        AddSingleValueEntry(psEntry, "Reg_VgaLongSatTh", fp);

        // if (FindEntry(psEntry, "KS_VGA_SHRT2LNG", fp) == 0) {
        //      sscanf(psEntry, "%hx", &this->KsVGAShrt2Lng, MAX_LINE_SIZE);
        // }
        // sprintf(psEntry, "0x%04hX", this->KsVGAShrt2Lng);
        sprintf(psEntry, "%hd", this->KsVGAShrt2Lng);    // Decimal in "ParamPana.ini"
        // AddSingleValueEntry(psEntry, "KS_VGA_SHRT2LNG", fp);
        AddSingleValueEntry(psEntry, "Reg_VgaShort2LongK", fp);

        // if (FindEntry(psEntry, "WDR_BITSFT", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->WDRBitSft, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->WDRBitSft);
        // AddSingleValueEntry(psEntry, "WDR_BITSFT", fp);
        AddSingleValueEntry(psEntry, "Reg_VgaWdrBitShift", fp);

        // if (FindEntry(psEntry, "RawNREna", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->RawNREna, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->RawNREna);
        // AddSingleValueEntry(psEntry, "RawNREna", fp);
        AddSingleValueEntry(psEntry, "Reg_RawNrBlFilter1Sw", fp);

        // if (FindEntry(psEntry, "RAWNR_MED4BL1_SEL", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->RawNRMed4Bl1Sel, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->RawNRMed4Bl1Sel);
        // AddSingleValueEntry(psEntry, "RAWNR_MED4BL1_SEL", fp);
        AddSingleValueEntry(psEntry, "Reg_RawNr3x3MedianSw", fp);

        // if (FindEntry(psEntry, "RAWNR_MED4BL1_GAIN", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->RawNRMed4Bl1Gain, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hu", this->RawNRMed4Bl1Gain);
        // AddSingleValueEntry(psEntry, "RAWNR_MED4BL1_GAIN", fp);
        AddSingleValueEntry(psEntry, "Reg_RawNr3x3MedianGain", fp);

        // if (FindEntry(psEntry, "RAWNR_SAT_TH", fp) == 0) {
        //      sscanf(psEntry, "%hx", &this->RawNRSatTh, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hd", this->RawNRSatTh);
        // AddSingleValueEntry(psEntry, "RAWNR_SAT_TH", fp);
        AddSingleValueEntry(psEntry, "Reg_RawNrSatTh", fp);

        /*
        if (FindEntry(psEntry, "RAWNR_XPWR", fp) == 0) {
                this->RawNRXVal[0] = 0;
                for (i = 0; i<RAWNR_XPWR_TBL_SIZE; i++) {
                        fscanf_s(fp, "%hhu", &this->RawNRXPwr[i], MAX_LINE_SIZE);
                        this->RawNRXVal[i + 1] = (1 << this->RawNRXPwr[i]) + this->RawNRXVal[i];
                }
        }
        */
        for (i = 0; i<RAWNR_XPWR_TBL_SIZE; i++) {
          sprintf(arrayStr1D[i], "%hu", this->RawNRXPwr[i]);
        }
        // AddOneDimensionalArrayPmodelEntry(arrayStr1D, RAWNR_XPWR_TBL_SIZE, "RAWNR_XPWR", fp);
        AddOneDimensionalArrayPmodelEntry(arrayStr1D, RAWNR_XPWR_TBL_SIZE, "Reg_RawNrXPower", fp);

        /*
        if (FindEntry(psEntry, "RAWNR_BL_TBL", fp) == 0) {
                for (i = 0; i<RAWNR_YVAL_TBL_SIZE; i++) {
                        fscanf_s(fp, "%hu", &this->RawNRBlTbl[i], MAX_LINE_SIZE);
                }
        }
        */
        for (i = 0; i<RAWNR_YVAL_TBL_SIZE; i++) {
          //sprintf(arrayStr1D[i], "0x%03hX", this->RawNRBlTbl[i]);
          sprintf(arrayStr1D[i], "%hu", this->RawNRBlTbl[i]);
        }
        // AddOneDimensionalArrayAmodelEntry(arrayStr1D, RAWNR_YVAL_TBL_SIZE, "RAWNR_BL_TBL", fp);
        AddOneDimensionalArrayPmodelEntry(arrayStr1D, RAWNR_YVAL_TBL_SIZE, "Reg_RawNrBl1Tbl", fp);

        /*
        if (FindEntry(psEntry, "RAWNR_BK_TBL", fp) == 0) {
                for (i = 0; i<RAWNR_YVAL_TBL_SIZE; i++) {
                        fscanf_s(fp, "%hu", &this->RawNRBkTbl[i], MAX_LINE_SIZE);
                }
        }
        */
        for (i = 0; i<RAWNR_YVAL_TBL_SIZE; i++) {
          sprintf(arrayStr1D[i], "%hu", this->RawNRBkTbl[i]);
        }
        // AddOneDimensionalArrayAmodelEntry(arrayStr1D, RAWNR_YVAL_TBL_SIZE, "RAWNR_BK_TBL", fp);
        AddOneDimensionalArrayPmodelEntry(arrayStr1D, RAWNR_YVAL_TBL_SIZE, "Reg_CoringTbl", fp);
        
        /*
        if (FindEntry(psEntry, "CoefTbl", fp) == 0) {
                for (i = 0; i<NR_FLT_COEF_TBL_SIZE; i++) {
                        fscanf_s(fp, "%hu", &unCoefIn[i], MAX_LINE_SIZE);
                }
        }
        */
        // djs (Note): The CoefTbl is not used by the P-Model, as it is identical to
        //             the spec value.
        /*
        for (i = 0; i<NR_FLT_COEF_TBL_SIZE; i++) {
          sprintf(arrayStr1D[i], "%hu", this->unCoefIn[i]);
        }
        AddOneDimensionalArrayPmodelEntry(arrayStr1D, NR_FLT_COEF_TBL_SIZE, "CoefTbl", fp);
        */
        /*
        // Distribute 7x7 coefficients
        // Pixel postion array
        uint8 ucCoefIdx[49] =
        { 9, 8, 7, 6, 7, 8, 9,
        8, 5, 4, 3, 4, 5, 8,
        7, 4, 2, 1, 2, 4, 7,
        6, 3, 1, 0, 1, 3, 6,
        7, 4, 2, 1, 2, 4, 7,
        8, 5, 4, 3, 4, 5, 8,
        9, 8, 7, 6, 7, 8, 9 };

        for (i = 0; i<49; i++) {
                memcpy(&this->unCoefTbl[i][0], &unCoefIn[ucCoefIdx[i] * 7], 7 * sizeof(uint16));
        }
        */

        // if (FindEntry(psEntry, "SmSigRmvEna", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ucSmSigRmvEna, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->ucSmSigRmvEna);
        // AddSingleValueEntry(psEntry, "SmSigRmvEna", fp);
        AddSingleValueEntry(psEntry, "Reg_CoringSw", fp);

        // if (FindEntry(psEntry, "S0S1_CORTH", fp) == 0) {
        //      sscanf(psEntry, "%hx", &this->S0S1CorTh, MAX_LINE_SIZE);
        // }
        // sprintf(psEntry, "0x%02hX", this->S0S1CorTh);
        sprintf(psEntry, "%hd", this->S0S1CorTh);     // Decimal in "ParamPana.ini"
        // AddSingleValueEntry(psEntry, "S0S1_CORTH", fp);
        AddSingleValueEntry(psEntry, "Reg_CoringThS0S1", fp);

        // if (FindEntry(psEntry, "CORTH_DET_GAINF", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->CorThDetGainF, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hu", this->CorThDetGainF);
        // AddSingleValueEntry(psEntry, "CORTH_DET_GAINF", fp);
        AddSingleValueEntry(psEntry, "Reg_CoringGainF", fp);

        // if (FindEntry(psEntry, "CORTH_DET_CNTF", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->CorThDetCntF, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->CorThDetCntF);
        // AddSingleValueEntry(psEntry, "CORTH_DET_CNTF", fp);
        AddSingleValueEntry(psEntry, "Reg_CoringCntThF", fp);

        // if (FindEntry(psEntry, "CORTH_SFT_GAINF", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->CorThSftGainF, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hu", this->CorThSftGainF);
        // AddSingleValueEntry(psEntry, "CORTH_SFT_GAINF", fp);
        AddSingleValueEntry(psEntry, "Reg_CoringThSftGainF", fp);

        // if (FindEntry(psEntry, "CORTH_SFT_INC_OFST", fp) == 0) {
        //      sscanf(psEntry, "%hd", &this->CorThSftIncOfst, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hd", this->CorThSftIncOfst);
        // AddSingleValueEntry(psEntry, "CORTH_SFT_INC_OFST", fp);
        AddSingleValueEntry(psEntry, "Reg_CoringThUpperOfst", fp);

        // if (FindEntry(psEntry, "CORTH_SFT_DEC_OFST", fp) == 0) {
        //      sscanf(psEntry, "%hd", &this->CorThSftDecOfst, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hd", this->CorThSftDecOfst);
        // AddSingleValueEntry(psEntry, "CORTH_SFT_DEC_OFST", fp);
        AddSingleValueEntry(psEntry, "Reg_CoringThLowerOfst", fp);

        // if (FindEntry(psEntry, "CORTH_DET_GAINB", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->CorThDetGainB, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hu", this->CorThDetGainB);
        // AddSingleValueEntry(psEntry, "CORTH_DET_GAINB", fp);
        AddSingleValueEntry(psEntry, "Reg_CoringGainB", fp);

        // if (FindEntry(psEntry, "CORTH_DET_CNTB", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->CorThDetCntB, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->CorThDetCntB);
        //AddSingleValueEntry(psEntry, "CORTH_DET_CNTB", fp);
		AddSingleValueEntry(psEntry, "Reg_CoringCntThB", fp);

        // if (FindEntry(psEntry, "CORTH_SFT_GAINB", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->CorThSftGainB, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hu", this->CorThSftGainB);
        // AddSingleValueEntry(psEntry, "CORTH_SFT_GAINB", fp);
        AddSingleValueEntry(psEntry, "Reg_CoringThSftGainB", fp);

        /* 
        // if (FindEntry(psEntry, "DEPTHCALC_ADDVLU", fp) == 0) {
        //      sscanf(psEntry, "%hx", &this->DepthCalcAddVLU, MAX_LINE_SIZE);
        // }
        */
        sprintf(psEntry, "%hd", this->DepthCalcAddVLU);
        // AddSingleValueEntry(psEntry, "DEPTHCALC_ADDVLU", fp);
        AddSingleValueEntry(psEntry, "Reg_DepthCalcAddValue", fp);

        /*
        if (FindEntry(psEntry, "LNR_OFST", fp) == 0) {
                for (i = 0; i<LNR_OFFSET_VAL_TBL_SIZE; i++) {
                        fscanf_s(fp, "%hd", &this->LnrOfst[i], MAX_LINE_SIZE);
                }
        }
        */
        /*
        for (i = 0; i<LNR_OFFSET_VAL_TBL_SIZE; i++) {
          sprintf(arrayStr1D[i], "%hd", this->LnrOfst[i]);
        }
        AddOneDimensionalArrayAmodelEntry(arrayStr1D, LNR_OFFSET_VAL_TBL_SIZE, "LNR_OFST", fp);
        */
        for (i = 0; i<25; i++) {
          sprintf(arrayStr1D[i], "%hd", this->LnrOfst[i]);
        }
        AddOneDimensionalArrayPmodelEntry(arrayStr1D, 25, "Reg_DpthNonLinearOffset0_24", fp);

        for (i = 0; i<LNR_OFFSET_VAL_TBL_SIZE - 25; i++) {
          sprintf(arrayStr1D[i], "%hd", this->LnrOfst[i + 25]);
        }
        AddOneDimensionalArrayPmodelEntry(arrayStr1D, 24, "Reg_DpthNonLinearOffset25_48", fp);
        
        // if (FindEntry(psEntry, "LNR_X0", fp) == 0) {
        //      sscanf(psEntry, "%hd", &this->LnrX0, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hd", this->LnrX0);
        // AddSingleValueEntry(psEntry, "LNR_X0", fp);
        AddSingleValueEntry(psEntry, "Reg_DpthNonLinearX0", fp);

        /*
        if (FindEntry(psEntry, "LNR_XPWR", fp) == 0) {
                for (i = 0; i<LNR_OFFSET_XPWR_TBL_SIZE; i++) {
                        fscanf_s(fp, "%hhu", &this->LnrXPwr[i], MAX_LINE_SIZE);
                }
        }
        */
        /*
        for (i = 0; i<LNR_OFFSET_XPWR_TBL_SIZE; i++) {
          sprintf(arrayStr1D[i], "%hu", this->LnrXPwr[i]);
        }
        AddOneDimensionalArrayAmodelEntry(arrayStr1D, LNR_OFFSET_XPWR_TBL_SIZE, "LNR_XPWR", fp);
        */
        for (i = 0; i<24; i++) {
          sprintf(arrayStr1D[i], "%hu", this->LnrXPwr[i]);
        }
        AddOneDimensionalArrayPmodelEntry(arrayStr1D, 24, "Reg_DpthNonLinearX1_24", fp);

        for (i = 0; i<LNR_OFFSET_XPWR_TBL_SIZE - 24; i++) {
          sprintf(arrayStr1D[i], "%hu", this->LnrXPwr[i + 24]);
        }
        AddOneDimensionalArrayPmodelEntry(arrayStr1D, 24, "Reg_DpthNonLinearX25_48", fp);

        // if (FindEntry(psEntry, "DEPTH_ZEROCORRE", fp) == 0) {
        //      sscanf(psEntry, "%hd", &this->DepthZeroCorre, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hd", this->DepthZeroCorre);
        // AddSingleValueEntry(psEntry, "DEPTH_ZEROCORRE", fp);
        AddSingleValueEntry(psEntry, "Reg_DpthZeroCorre", fp);

        // if (FindEntry(psEntry, "SHD_OFST_ENBL", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ucShdOfstEna, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->ucShdOfstEna);
        // AddSingleValueEntry(psEntry, "SHD_OFST_ENBL", fp);
        AddSingleValueEntry(psEntry, "Reg_DepthShadingOffsetSw", fp);

        // if (FindEntry(psEntry, "SHD_X0", fp) == 0) {
        //      sscanf(psEntry, "%hd", &this->Shd_X0, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hd", this->Shd_X0);
        // AddSingleValueEntry(psEntry, "SHD_X0", fp);
        AddSingleValueEntry(psEntry, "Reg_DepthShadingX0", fp);

        // if (FindEntry(psEntry, "SHD_Y0", fp) == 0) {
        //      sscanf(psEntry, "%hd", &this->Shd_Y0, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hd", this->Shd_Y0);
        // AddSingleValueEntry(psEntry, "SHD_Y0", fp);
        AddSingleValueEntry(psEntry, "Reg_DepthShadingY0", fp);

        /*
        if (FindEntry(psEntry, "SHD_XPWR", fp) == 0) {
                for (i = 0; i<SHADING_XPWR_TBL_SIZE; i++) {
                        fscanf_s(fp, "%hhu", &this->ShdXPwr[i], MAX_LINE_SIZE);
                }
        }
        */
        for (i = 0; i<SHADING_XPWR_TBL_SIZE; i++) {
          sprintf(arrayStr1D[i], "%hhu", this->ShdXPwr[i]);
        }
        // AddOneDimensionalArrayAmodelEntry(arrayStr1D, SHADING_XPWR_TBL_SIZE, "SHD_XPWR", fp);
        AddOneDimensionalArrayPmodelEntry(arrayStr1D, SHADING_XPWR_TBL_SIZE, "Reg_DepthShadingX01_15", fp);
                
        /*
        if (FindEntry(psEntry, "SHD_YPWR", fp) == 0) {
                for (i = 0; i<SHADING_YPWR_TBL_SIZE; i++) {
                        fscanf_s(fp, "%hhu", &this->ShdYPwr[i], MAX_LINE_SIZE);
                }
        }
        */
        for (i = 0; i<SHADING_YPWR_TBL_SIZE; i++) {
          sprintf(arrayStr1D[i], "%hhu", this->ShdYPwr[i]);
        }
        // AddOneDimensionalArrayAmodelEntry(arrayStr1D, SHADING_YPWR_TBL_SIZE, "SHD_YPWR", fp);
        AddOneDimensionalArrayPmodelEntry(arrayStr1D, SHADING_YPWR_TBL_SIZE, "Reg_DepthShadingY01_11", fp);
        
        // SHD_OFST is stored in a filename specified in the "Reg_DepthShadingOffsetFileName" field
        /*
        if (FindEntry(psEntry, "SHD_OFST,", fp) == 0) {
                for (i = 0; i<SHADING_OFFSET_TBL_SIZE; i++) {
                        int16 offset;
                        fscanf_s(fp, "%hd", &offset, MAX_LINE_SIZE);
                        this->ShdOfst[i] = 2 * offset;
                }
        }
        */
        // We use a fixed filename
        sprintf(psEntry, "%s", "GeneratedDepthShadingTable.txt");
        AddSingleValueEntry(psEntry, "Reg_DepthShadingOffsetFileName", fp);
        fpDepthShadingOffsetFile = fopen(psEntry, "w");
        if (!fpDepthShadingOffsetFile) {
          printf("Failed to open Depth Shading Offset Table file: %s\n", psEntry);
          return EC_FAIL;
        }
        for (i = 0; i<SHADING_OFFSET_TBL_SIZE; i++) {
          sprintf(arrayStr1D[i], "%hd", this->ShdOfst[i]/2); // Account for post-read-in computation
        }
        // AddOneDimensionalArrayAmodelEntry(arrayStr1D, SHADING_OFFSET_TBL_SIZE, "SHD_OFST", fp);
        AddDepthShadingTablePmodelEntry(arrayStr1D, SHADING_OFFSET_TBL_SIZE, fpDepthShadingOffsetFile);
        fclose(fpDepthShadingOffsetFile);
        
        // if (FindEntry(psEntry, "DEPTH_SLOPE_GAIN", fp) == 0) {
        //      sscanf(psEntry, "%hx", &this->DepthSlopeGain, MAX_LINE_SIZE);
        // }
        // sprintf(psEntry, "0x%03hX", this->DepthSlopeGain);
        sprintf(psEntry, "%hd", this->DepthSlopeGain);        // Decimal in "ParamPana.ini"
        // AddSingleValueEntry(psEntry, "DEPTH_SLOPE_GAIN", fp);
        AddSingleValueEntry(psEntry, "Reg_DepthAdjustScale", fp);

        /*
        // if (FindEntry(psEntry, "DEPTH_OFSTVLU", fp) == 0) {
        //      sscanf(psEntry, "%hd", &this->DepthOfstVLU, MAX_LINE_SIZE);
        // }
        */
        sprintf(psEntry, "%hd", this->DepthOfstVLU);
        // AddSingleValueEntry(psEntry, "DEPTH_OFSTVLU", fp);
        AddSingleValueEntry(psEntry, "Reg_DepthAdjustOffset", fp);

        // if (FindEntry(psEntry, "IR_DGAIN", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->IRDGain, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hu", this->IRDGain);
        // AddSingleValueEntry(psEntry, "IR_DGAIN", fp);
        AddSingleValueEntry(psEntry, "Reg_SlevIrGain", fp);

        // if (FindEntry(psEntry, "IRIMG_SEL", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->IRImgSel, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->IRImgSel);
        // AddSingleValueEntry(psEntry, "IRIMG_SEL", fp);
        AddSingleValueEntry(psEntry, "Reg_SlevAddBgSel", fp);

        /*
        if (FindEntry(psEntry, "IR_GMM_PWR", fp) == 0) {
                for (i = 0; i<IR_GAMMA_PWR_TBL_SIZE - 1; i++) {
                        fscanf_s(fp, "%hhu", &this->IRGmmPwr[i], MAX_LINE_SIZE);
                        this->IRGmmX[i + 1] = (1 << this->IRGmmPwr[i]) + this->IRGmmX[i];
                }
        }
        */
        for (i = 0; i<IR_GAMMA_PWR_TBL_SIZE - 1; i++) {
          sprintf(arrayStr1D[i], "%hhu", this->IRGmmPwr[i]);
        }
        // AddOneDimensionalArrayAmodelEntry(arrayStr1D, IR_GAMMA_PWR_TBL_SIZE, "IR_GMM_PWR", fp);
        AddOneDimensionalArrayPmodelEntry(arrayStr1D, IR_GAMMA_PWR_TBL_SIZE - 1, "Reg_IrGammaX0_8", fp);
        
        /*
        if (FindEntry(psEntry, "IR_GMM_Y", fp) == 0) {
                uint16 unDeltaY;
                for (i = 1; i<IR_GAMMA_PWR_TBL_SIZE; i++) {
                        fscanf_s(fp, "%hx", &unDeltaY, MAX_LINE_SIZE);
                        this->IRGmmY[i] = this->IRGmmY[i - 1] + unDeltaY;
                }
        }
        */
        for (i = 0; i<IR_GAMMA_PWR_TBL_SIZE; i++) {
          // sprintf(arrayStr1D[i], "0x%04hx", this->__iniFileIRGmmY[i]); // the "__iniFile..." variable captures the original value
          sprintf(arrayStr1D[i], "%hd", this->__iniFileIRGmmY[i]);         // Decimal in "ParamPana.ini"
        }
        // AddOneDimensionalArrayAmodelEntry(arrayStr1D, IR_GAMMA_PWR_TBL_SIZE, "IR_GMM_Y", fp);
        // djs (Fix): IR_GMM_Y has an extra value compared to Reg_IrGammaY0_8
        AddOneDimensionalArrayPmodelEntry(arrayStr1D, IR_GAMMA_PWR_TBL_SIZE - 1, "Reg_IrGammaY0_8", fp); 

        // ***********************************************************************
        // djs (Note): None of the "CHKR_" values are used by the P-Model
        // ***********************************************************************
        /*
        // if (FindEntry(psEntry, "CHKR_DET_ENA", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ChkrDetEna, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->ChkrDetEna);
        AddSingleValueEntry(psEntry, "CHKR_DET_ENA", fp);

        // if (FindEntry(psEntry, "CHKR_DET_TYPE_SEL", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ChkrDetTypeSel, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->ChkrDetTypeSel);
        AddSingleValueEntry(psEntry, "CHKR_DET_TYPE_SEL", fp);
        
        // if (FindEntry(psEntry, "CHKR_START_H", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->ChkrStartH, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hu", this->ChkrStartH);
        AddSingleValueEntry(psEntry, "CHKR_START_H", fp);

        // if (FindEntry(psEntry, "CHKR_START_V", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->ChkrStartV, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hu", this->ChkrStartV);
        AddSingleValueEntry(psEntry, "CHKR_START_V", fp);

        // if (FindEntry(psEntry, "CHKR_SIZE_H", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ChkrSizeH, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->ChkrSizeH);
        AddSingleValueEntry(psEntry, "CHKR_SIZE_H", fp);

        // if (FindEntry(psEntry, "CHKR_UPPRTH", fp) == 0) {
        //      sscanf(psEntry, "%hx", &this->ChkrUpprTh, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "0x%04hX", this->ChkrUpprTh);
        AddSingleValueEntry(psEntry, "CHKR_UPPRTH", fp);

        // if (FindEntry(psEntry, "CHKR_LWRTH", fp) == 0) {
        //      sscanf(psEntry, "%hx", &this->ChkrLwrTh, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "0x%04hX", this->ChkrLwrTh);
        AddSingleValueEntry(psEntry, "CHKR_LWRTH", fp);

        // if (FindEntry(psEntry, "CHKR_UPPRERR_H", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ChkrUpprErrH, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->ChkrUpprErrH);
        AddSingleValueEntry(psEntry, "CHKR_UPPRERR_H", fp);

        // if (FindEntry(psEntry, "CHKR_LWRERR_H", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ChkrLwrErrH, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->ChkrLwrErrH);
        AddSingleValueEntry(psEntry, "CHKR_LWRERR_H", fp);

        // if (FindEntry(psEntry, "CHKR_UPPRERR_V", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ChkrUpprErrV, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->ChkrUpprErrV);
        AddSingleValueEntry(psEntry, "CHKR_UPPRERR_V", fp);

        // if (FindEntry(psEntry, "CHKR_LWRERR_V", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ChkrLwrErrV, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->ChkrLwrErrV);
        AddSingleValueEntry(psEntry, "CHKR_LWRERR_V", fp);

        // if (FindEntry(psEntry, "CHKR_STARTOFST_H", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ChkrStrtOfstH, MAX_LINE_SIZE);
        // }
        // djs (Fix): Changed to match hex input string.
        //sprintf(psEntry, "%hhu", this->ChkrStrtOfstH);
        sprintf(psEntry, "0x%02hX", this->ChkrStrtOfstH);
        AddSingleValueEntry(psEntry, "CHKR_STARTOFST_H", fp);
        */
        // ***********************************************************************
        
        // All of the following parameters are not used in the A-Model
        //   (as of the spreadsheet committed on 2016-04-01), and as
        //   such, should get zero values.
        //   --> Comments from spreadsheet are listed.
        sprintf(psEntry, "%d", 0);
        AddSingleValueEntry(psEntry, "OutputInputRawDataSw", fp);
        AddSingleValueEntry(psEntry, "OutputSubBGDataSw", fp);
        AddSingleValueEntry(psEntry, "OutputPostIrDataSw", fp);
        AddSingleValueEntry(psEntry, "ReadRaw_Endian", fp);
        AddSingleValueEntry(psEntry, "ReadRaw_PosExp", fp);       // used on 0 in fixed
        AddSingleValueEntry(psEntry, "DepthOut_StartPosH", fp);   // used on 0 in fixed
        AddSingleValueEntry(psEntry, "DepthOut_StartPosV", fp);   // used on 0 in fixed
        AddSingleValueEntry(psEntry, "Reg_TofResolSel", fp);      // used on 0 in fixed
        /*
          Although this parameter is in the spreadsheet, it is assigned a value in the A-Model.
        AddSingleValueEntry(psEntry, "DEPTH_OFSTVLU", fp);        // Fixed in 0  on Panasonic C model
        */
        
        // All of the following parameters are not used in the A-Model,
        //   but should get values of one.
        sprintf(psEntry, "%d", 1);
        AddSingleValueEntry(psEntry, "OutputDebugRawDataSw", fp);
        AddSingleValueEntry(psEntry, "Reg_CoringDynamicSw", fp);  // If disable;0 then Reg_CoringThUpperK=0 and Reg_CoringThLowerK=0
  
        if (fp) {
                fclose(fp);
        }
        return ec;
}

// Adds a one dimensional array entry to the P-Model parameter file, where everything is delimited by a comma only
int Param::AddOneDimensionalArrayPmodelEntry(array_str_t *arrayStr1D, unsigned int arrayLength, char *pcKeyword, FILE *fp)
{
        int ret_code = 0;
        
        /* Verify all input */
        if (arrayStr1D == NULL || pcKeyword == NULL || fp == NULL) {
                return -1;
        }

        ret_code = fprintf(fp, "%s,", pcKeyword);

        for (unsigned int i = 0; i < (arrayLength - 1); i++) {
          ret_code = fprintf(fp, "%s,", (char *) arrayStr1D++);
        }

        ret_code = fprintf(fp, "%s\n", (char *)arrayStr1D++);

        return ret_code;
}

// Generates the P-Model Depth Shading Table output, which is a space-delimited array of values without a keyword
int Param::AddDepthShadingTablePmodelEntry(array_str_t *arrayStr1D, unsigned int arrayLength, FILE *fp)
{
        int ret_code = 0;
        
        /* Verify all input */
        if (arrayStr1D == NULL || fp == NULL) {
                return -1;
        }

        for (unsigned int i = 0; i < (arrayLength - 1); i++) {
          ret_code = fprintf(fp, "%-8s", (char *) arrayStr1D++);
          if (!((i+1) % 16)) {
            fprintf(fp, "\n");
          }
        }

        ret_code = fprintf(fp, "%s\n", (char *)arrayStr1D++);

        return ret_code;
}

void Param::getCalFilePath(char *Path, int depthLevel)
{
    char fileNameExtension[5];

    switch(this->eImgSensorType) {
	case VGA_V1:
	case VGA_V2:
	case VGA_V3:
		strcpy(Path, "LinearCorrectVGA");
		break;
	case SXGA_V1:
	case SXGA_V2:
	case SXGA_V3:
		strcpy(Path, "LinearCorrectSXGA");
		break;
    default:
        strcpy(Path, "LinearCorrectVGA");
        break;
    }

        // djs (Fix): Missing case for DEPTH_RANGE_MAX?
	switch(this->eDepthRange) {
	case DEPTH_RANGE_NEAR:
		strcat(Path, "Near");
		break;
	case DEPTH_RANGE_XNEAR:
		strcat(Path, "XNear");
		break;
	case DEPTH_RANGE_MID:
		strcat(Path, "Mid");
		break;
	case DEPTH_RANGE_FAR:
	case DEPTH_RANGE_XFAR:
		strcat(Path, "Far");
		break;
    default:
        strcat(Path, "Mid");
        break;
    }

	if(depthLevel==0)
		sprintf(fileNameExtension,".ini");
	else
		sprintf(fileNameExtension,"%d.ini",depthLevel);

	strcat(Path,fileNameExtension);

}

// Writes calibration data to the parameter file for non-linear correction
void Param::CalParamWr(uint16 depthLevel)
{
        FILE *fp;
        char filename[MAX_PATH_SIZE];
        char filenameBak[MAX_PATH_SIZE];

        getCalFilePath(filename, depthLevel);


	// If file exists, rename to a backup.
    fp = fopen(filename, "r");

    if (fp) {
        fclose(fp);
        int k = 1;
        sprintf(filenameBak, "%s.bak", filename);
        fp = fopen(filenameBak, "r");
        while (fp) {
          fclose(fp);
          sprintf(filenameBak, "%s.bak.%d", filename, k);
          k++;
          fp = fopen( filenameBak, "r");
        }
        rename(filename, filenameBak);
    }
		
    fp = fopen(filename, "w");

    // DEPTH_SLOPE_GAIN
    fprintf(fp, "LDPulseCnt,%hu\n\n", unLDPulseCnt);

	//Laser Enable Register
	fprintf(fp, "LDEnable,%hu\n\n", unLaserEnaReg);

    // LNR_X0
    fprintf(fp, "LNR_X0,0\n\n");

    // LNR_XPWR
    fprintf(fp, "LNR_XPWR,");
    for (int i = 0; i < LNR_OFFSET_XPWR_TBL_SIZE-1; i++) {
        if (i % 8 == 0) {
          fprintf(fp, "\n");
        }
        fprintf(fp, " %d ", LnrXPwr[i]);
    }
    fprintf(fp, " %d\n\n", LnrXPwr[LNR_OFFSET_XPWR_TBL_SIZE-1]);


    // LNR_OFST
    fprintf(fp, "LNR_OFST,");
    for (int i = 0; i < LNR_OFFSET_VAL_TBL_SIZE-1; i++) {
        if (i % 8 == 0) {
          fprintf(fp, "\n");
        }
        fprintf(fp, " %d ", LnrOfst[i]);
    }
    fprintf(fp, " %d\n\n", LnrOfst[LNR_OFFSET_VAL_TBL_SIZE-1]);

    // DEPTH_SLOPE_GAIN
    fprintf(fp, "DEPTH_SLOPE_GAIN,0x%x\n\n", DepthSlopeGain);

    // DEPTH_CVN_GAIN
    fprintf(fp, "DEPTH_CNV_GAIN,%0.6f\n\n", DepthCnvGain);

    // DEPTH_MAX
    fprintf(fp, "DEPTH_MAX,0x%x\n", DepthMax);

    // DEPTH_SLOPE_GAIN
    fprintf(fp, "\nDEPTH_OFSTVLU,%d\n", this->DepthOfstVLU);

    fclose(fp);
}

// Creates a new calibration file and appends the offset data
void Param::CalParamOffsetWr(void)
{
    char filename[MAX_PATH_SIZE];
    char filenameBak[MAX_PATH_SIZE];

    getCalFilePath(filename, 0);

    // If file exists, rename to a backup.
    FILE *fp = fopen(filename, "r");

    if (!fp) {
        // Need to have a calibration file
        return;
    }

    // Check for a backup file
    sprintf(filenameBak, "%s.bak", filename);
    FILE *fpSrc = fopen(filenameBak, "r");
    if (!fpSrc) {
        // If not, this is a first time offset calibation
        // Rename the file to backup
        rename(filename, filenameBak);
        // Always use the backup as the source
        fpSrc = fopen(filenameBak, "r");
    }
    // Overwrite any previous offset changes.
    FILE *fpDst = fopen(filename, "w");

	char inBuf[MAX_LINE_SIZE];
	char outBuf[MAX_LINE_SIZE];
    int OfstSize = sizeof("DEPTH_OFSTVLU") - 1;
    int PCntSize = sizeof("LDPulseCnt") - 1;

	/* Search for keyword one line at a time */
    while (NULL != fgets(inBuf, MAX_LINE_SIZE, fpSrc)) {
        strcpy(outBuf, inBuf);
        outBuf[OfstSize] = '\0';
		if (strncmp(outBuf, "DEPTH_OFSTVLU", OfstSize) == 0) {
            continue;
        }
        strcpy(outBuf, inBuf);
        outBuf[PCntSize] = '\0';
		if (strncmp(outBuf, "LDPulseCnt", PCntSize) == 0) {
            continue;
        }
        fputs(inBuf, fpDst);
	}

    // Append offet entry to the end of the file
    fprintf(fpDst, "LDPulseCnt,%d\n", this->unLDPulseCnt);
    fprintf(fpDst, "DEPTH_OFSTVLU,%d\n", this->DepthOfstVLU);

    fclose(fpSrc);
    fclose(fpDst);
}

// Restore active calibration file to original settings
void Param::CalParamReset(void)
{
    char filename[MAX_PATH_SIZE];
    char filenameBak[MAX_PATH_SIZE];

    this->DepthOfstVLU = 0;

    getCalFilePath(filename, 0);
    sprintf(filenameBak, "%s.bak", filename);

    FILE *fpSrc = fopen(filenameBak, "r");
    FILE *fpDst = fopen(filename, "w");

    if (!fpSrc || !fpDst) {
        // Can't deal with missing files, just return
        return;
    }

	char inBuf[MAX_LINE_SIZE];
    while (NULL != fgets(inBuf, MAX_LINE_SIZE, fpSrc)) {
        fputs(inBuf, fpDst);
	}

    fclose(fpSrc);
    fclose(fpDst);

    this->ParamInit(filename);
}

// Writes calibration data to the parameter file for non-linear correction
void Param::CalTempParamWr(void)
{
    FILE *fp;
    char filename[MAX_PATH_SIZE];
        
    getCalFilePath(filename, 0);

	// Generate a new paramter file
	CalParamWr();

	// Reopen to append offset
    fp = fopen(filename, "a");

    // DEPTH_SLOPE_GAIN
    fprintf(fp, "\nDEPTH_OFSTVLU,%d\n", this->DepthOfstVLU);

   fclose(fp);
}


// Create a test to run on the TOF Processor UVM testbench, using the passed in filename.
errcode_t Param::CreateUVMTest(char *psUvmTestName, char *psUvmTestFilename, char *psImageListFilename)
{

        char psImageFilename[MAX_LINE_SIZE];
        char psSimDotSetupFilename[MAX_LINE_SIZE];
        FILE *fp = NULL;        // NOTE: Each of these file pointers are LOCAL, and are passed to each
        FILE *fpImage = NULL;
        errcode_t ec = EC_OK;

        if (!psUvmTestName || !psUvmTestFilename || !psImageListFilename)
        {
	        return EC_BAD_ARG;
                
        }
        else {
            fp = fopen(psUvmTestFilename, "w");
            if (!fp) {
                    printf("Failed to open UVM test output file: %s\n", psUvmTestFilename);
                    return EC_FAIL;
            }

            // Initialize input frame source
            fpImage = fopen(psImageListFilename, "r");
            if (!fpImage) {
                    printf("Failed to open image list file: %s\n", psImageListFilename);
                    return EC_FAIL;
            } else {
                    // ONLY READ THE FIRST image filename from image list file
                    fscanf(fpImage, "%s", psImageFilename);
                    fclose(fpImage);
            }
        }

        WriteUvmTestHeader(fp, psUvmTestName, psUvmTestFilename);
        WriteUvmTestSetupRegSeqClass(fp, psUvmTestName);
        WriteUvmTestTestClass(fp, psUvmTestName, psImageFilename);

        if (fp) {
                fclose(fp);
        }

        sprintf(psSimDotSetupFilename, "sim.setup");

        fp = fopen(psSimDotSetupFilename, "w");
        if (!fp) {
                printf("Failed to open UVM test output file: %s\n", psSimDotSetupFilename);
                return EC_FAIL;
        } else {
               WriteUvmTestSimDotSetupFile(fp, psImageFilename);
        }

        if (fp) {
                fclose(fp);
        }
        return ec;
}

// Translate all parameters into UVM register writes, which are included in the test's setup sequence.
errcode_t Param::WriteUVMParamRegWrites(FILE *fp)
{

        int i;
        char psEntry[MAX_LINE_SIZE];
        errcode_t ec = EC_OK;

        /* Write the various parameters from the supplied file */
        // if (FindEntry(psEntry, "ImgSensorType", fp) == 0) {
        //      sscanf(psEntry, "%d", &this->eImgSensorType, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%d", this->eImgSensorType);
        // AddSingleValueEntry(psEntry, "ImgSensorType", fp);
        switch (this->eImgSensorType)
          {
          case VGA_V1  : AddWriteFieldByName("2'b00", "sensor_type_ps", "ImgSensorType: VGA_V1, No defined part number.  Assuming VGA/IR.", fp);
                         break;
          case VGA_V2  : AddWriteFieldByName("2'b00", "sensor_type_ps", "ImgSensorType: VGA_V2, MN34902BL", fp);
                         break;
          case VGA_V3  : AddWriteFieldByName("2'b00", "sensor_type_ps", "ImgSensorType: VGA_V3, MN34906BL", fp);
                         break;
          case SXGA_V1 : AddWriteFieldByName("2'b01", "sensor_type_ps", "ImgSensorType: SXGA_V1, MN34920BL", fp);
                         break;
          case SXGA_V2 : AddWriteFieldByName("2'b01", "sensor_type_ps", "ImgSensorType: SXGA_V2, No defined part number.  Assuming SXGA/IR.", fp);
                         break;
          case SXGA_V3 : AddWriteFieldByName("2'b01", "sensor_type_ps", "ImgSensorType: SXGA_V3, MN34926BL", fp);
                         break;
          default      : AddWriteFieldByNameError(psEntry, "sensor_type_ps", "ImgSensorType", fp);
                         break;
          }

        // See "M3W_SEL" processing, as DepthMode is m3w_sel_ps[1].
        /*
        // if (FindEntry(psEntry, "DepthMode", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ucDepthMode, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->ucDepthMode);
        // AddSingleValueEntry(psEntry, "DepthMode", fp);
        AddWriteFieldByName(psEntry, "DepthMode", "DepthMode", fp);
        */
        
        // if (FindEntry(psEntry, "InWidth", fp) == 0) {
        //      sscanf(psEntry, "%u", &this->uiInWidth );
        // }
        sprintf(psEntry, "%u", this->uiInWidth);
        // AddSingleValueEntry(psEntry, "InWidth", fp);
        AddWriteFieldByName(psEntry, "tof_raw_width_pixcnt_ps", "InWidth", fp);
        AddWriteFieldByName(psEntry, "rgb_width_pixcnt_ps"    , "InWidth", fp);

        //if (FindEntry(psEntry, "InHeight", fp) == 0) {
        //      sscanf(psEntry, "%u", &this->uiInHeight );
        // }
        sprintf(psEntry, "%u", this->uiInHeight);
        // AddSingleValueEntry(psEntry, "InHeight", fp);
        AddWriteFieldByName(psEntry, "tof_raw_height_hdcnt_ps", "InHeight", fp);
        AddWriteFieldByName(psEntry, "rgb_height_hdcnt_ps"    , "InHeight", fp);

        // if (FindEntry(psEntry, "OutWidth", fp) == 0) {
        //      sscanf(psEntry, "%u", &this->uiOutWidth );
        // }
        sprintf(psEntry, "%u", this->uiOutWidth);
        // AddSingleValueEntry(psEntry, "OutWidth", fp);
        AddWriteFieldByName(psEntry, "tof_image_width_ps", "OutWidth", fp);
        AddWriteFieldByName("0"    , "tof_raw_roi_vstart", "0x000    (until ROI params are implemented within A-Model)", fp);
        AddWriteFieldByName(psEntry, "tof_raw_roi_width" , "OutWidth (until ROI params are implemented within A-Model)", fp);
        AddWriteFieldByName("0"    , "rgb_roi_vstart"    , "0x000    (until ROI params are implemented within A-Model)", fp);
        AddWriteFieldByName(psEntry, "rgb_roi_width"     , "OutWidth (until ROI params are implemented within A-Model)", fp);

        // if (FindEntry(psEntry, "OutHeight", fp) == 0) {
        //      sscanf(psEntry, "%u", &this->uiOutHeight );
        // }
        sprintf(psEntry, "%u", this->uiOutHeight);
        // AddSingleValueEntry(psEntry, "OutHeight", fp);
        AddWriteFieldByName(psEntry, "tof_image_height_ps", "OutHeight", fp);
        AddWriteFieldByName("0"    , "tof_raw_roi_hstart" , "0x000     (until ROI params are implemented within A-Model)", fp);
        AddWriteFieldByName(psEntry, "tof_raw_roi_height" , "OutHeight (until ROI params are implemented within A-Model)", fp);
        AddWriteFieldByName("0"    , "rgb_roi_hstart"     , "0x000     (until ROI params are implemented within A-Model)", fp);
        AddWriteFieldByName(psEntry, "rgb_roi_height"     , "OutHeight (until ROI params are implemented within A-Model)", fp);


        // The following parameters are not used by hardware; they influence how the A-Model runs.
        /*
        // if (FindEntry(psEntry, "OutputPath", fp) == 0) {
        //       strncpy(this->cOutputPath, psEntry, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%s", this->cOutputPath);
        // AddSingleValueEntry(psEntry, "OutputPath", fp);
        AddWriteFieldByName(psEntry, "OutputPath", "OutputPath", fp);

        // if (FindEntry(psEntry, "OutputSeparateDataSw", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->OutputSeparateDataSw );
        // }
        sprintf(psEntry, "%hhu", this->OutputSeparateDataSw);
        // AddSingleValueEntry(psEntry, "OutputSeparateDataSw", fp);
        AddWriteFieldByName(psEntry, "OutputSeparateDataSw", "OutputSeparateDataSw", fp);

        // if (FindEntry(psEntry, "OutputMedianDataSw", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->OutputMedianDataSw );
        // }
        sprintf(psEntry, "%hhu", this->OutputMedianDataSw);
        // AddSingleValueEntry(psEntry, "OutputMedianDataSw", fp);
        AddWriteFieldByName(psEntry, "OutputMedianDataSw", "OutputMedianDataSw", fp);

        // if (FindEntry(psEntry, "OutputTransDataSw", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->OutputTransDataSw );
        // }
        sprintf(psEntry, "%hhu", this->OutputTransDataSw);
        // AddSingleValueEntry(psEntry, "OutputTransDataSw", fp);
        AddWriteFieldByName(psEntry, "OutputTransDataSw", "OutputTransDataSw", fp);

        // if (FindEntry(psEntry, "OutputMixTransDataSw", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->OutputMixTransDataSw );
        // }
        sprintf(psEntry, "%hhu", this->OutputMixTransDataSw);
        // AddSingleValueEntry(psEntry, "OutputMixTransDataSw", fp);
        AddWriteFieldByName(psEntry, "OutputMixTransDataSw", "OutputMixTransDataSw", fp);

        // if (FindEntry(psEntry, "OutputRawNrDataSw", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->OutputRawNrDataSw );
        // }
        sprintf(psEntry, "%hhu", this->OutputRawNrDataSw);
        // AddSingleValueEntry(psEntry, "OutputRawNrDataSw", fp);
        AddWriteFieldByName(psEntry, "OutputRawNrDataSw", "OutputRawNrDataSw", fp);

        // if (FindEntry(psEntry, "OutputCoringDataSw", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->OutputCoringDataSw );
        // }
        sprintf(psEntry, "%hhu", this->OutputCoringDataSw);
        // AddSingleValueEntry(psEntry, "OutputCoringDataSw", fp);
        AddWriteFieldByName(psEntry, "OutputCoringDataSw", "OutputCoringDataSw", fp);

        // if (FindEntry(psEntry, "OutputDepthDataSw", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->OutputDepthDataSw );
        // }
        sprintf(psEntry, "%hhu", this->OutputDepthDataSw);
        // AddSingleValueEntry(psEntry, "OutputDepthDataSw", fp);
        AddWriteFieldByName(psEntry, "OutputDepthDataSw", "OutputDepthDataSw", fp);

        // if (FindEntry(psEntry, "OutputDepthRelateDataSw", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->OutputDepthRelateDataSw );
        // }
        sprintf(psEntry, "%hhu", this->OutputDepthRelateDataSw);
        // AddSingleValueEntry(psEntry, "OutputDepthRelateDataSw", fp);
        AddWriteFieldByName(psEntry, "OutputDepthRelateDataSw", "OutputDepthRelateDataSw", fp);

        // if (FindEntry(psEntry, "OutputDepthOutDataSw", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->OutputDepthOutDataSw );
        // }
        sprintf(psEntry, "%hhu", this->OutputDepthOutDataSw);
        // AddSingleValueEntry(psEntry, "OutputDepthOutDataSw", fp);
        AddWriteFieldByName(psEntry, "OutputDepthOutDataSw", "OutputDepthOutDataSw", fp);

        // if (FindEntry(psEntry, "OutputIrOutDataSw", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->OutputIrOutDataSw );
        // }
        sprintf(psEntry, "%hhu", this->OutputIrOutDataSw);
        // AddSingleValueEntry(psEntry, "OutputIrOutDataSw", fp);
        AddWriteFieldByName(psEntry, "OutputIrOutDataSw", "OutputIrOutDataSw", fp);

        // if (FindEntry(psEntry, "InjPostReorderSw", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->InjPostReorderSw );
        // }
        sprintf(psEntry, "%hhu", this->InjPostReorderSw);
        // AddSingleValueEntry(psEntry, "InjPostReorderSw", fp);
        AddWriteFieldByName(psEntry, "InjPostReorderSw", "InjPostReorderSw", fp);

        // if (FindEntry(psEntry, "InjPostReorderA0", fp) == 0) {
        //       strncpy(this->InjPostReorderA0, psEntry );
        // }
        sprintf(psEntry, "%s", this->InjPostReorderA0);
        // AddSingleValueEntry(psEntry, "InjPostReorderA0", fp);
        AddWriteFieldByName(psEntry, "InjPostReorderA0", "InjPostReorderA0", fp);

        // if (FindEntry(psEntry, "InjPostReorderA1", fp) == 0) {
        //       strncpy(this->InjPostReorderA1, psEntry, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%s", this->InjPostReorderA1);
        // AddSingleValueEntry(psEntry, "InjPostReorderA1", fp);
        AddWriteFieldByName(psEntry, "InjPostReorderA1", "InjPostReorderA1", fp);

        // if (FindEntry(psEntry, "InjPostReorderA2", fp) == 0) {
        //       strncpy(this->InjPostReorderA2, psEntry, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%s", this->InjPostReorderA2);
        // AddSingleValueEntry(psEntry, "InjPostReorderA2", fp);
        AddWriteFieldByName(psEntry, "InjPostReorderA2", "InjPostReorderA2", fp);

        // if (FindEntry(psEntry, "InjPostGridSw", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->InjPostGridSw, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->InjPostGridSw);
        // AddSingleValueEntry(psEntry, "InjPostGridSw", fp);
        AddWriteFieldByName(psEntry, "InjPostGridSw", "InjPostGridSw", fp);

        // if (FindEntry(psEntry, "InjPostGridA0", fp) == 0) {
        //       strncpy(this->InjPostGridA0, psEntry, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%s", this->InjPostGridA0);
        // AddSingleValueEntry(psEntry, "InjPostGridA0", fp);
        AddWriteFieldByName(psEntry, "InjPostGridA0", "InjPostGridA0", fp);

        // if (FindEntry(psEntry, "InjPostGridA1", fp) == 0) {
        //       strncpy(this->InjPostGridA1, psEntry, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%s", this->InjPostGridA1);
        // AddSingleValueEntry(psEntry, "InjPostGridA1", fp);
        AddWriteFieldByName(psEntry, "InjPostGridA1", "InjPostGridA1", fp);

        // if (FindEntry(psEntry, "InjPostGridA2", fp) == 0) {
        //       strncpy(this->InjPostGridA2, psEntry, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%s", this->InjPostGridA2);
        // AddSingleValueEntry(psEntry, "InjPostGridA2", fp);
        AddWriteFieldByName(psEntry, "InjPostGridA2", "InjPostGridA2", fp);
*/
        // if (FindEntry(psEntry, "M3W_SEL", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ucM3WSel, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "2'b%d%d", this->ucDepthMode, this->ucM3WSel);
        // AddSingleValueEntry(psEntry, "M3W_SEL", fp);
        AddWriteFieldByName(psEntry, "m3w_sel_ps", "{DepthMode, M3W_SEL}", fp);

        // if (FindEntry(psEntry, "GRIDVGA_SEL", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ucGridVGASel, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->ucGridVGASel);
        // AddSingleValueEntry(psEntry, "GRIDVGA_SEL", fp);
        AddWriteFieldByName(psEntry, "gridvga_sel_ps", "GRIDVGA_SEL", fp);
        
        // if (FindEntry(psEntry, "TOFSTART_HDCNT", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->ToFStartHDCnt, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hu", this->ToFStartHDCnt);
        // AddSingleValueEntry(psEntry, "TOFSTART_HDCNT", fp);
        AddWriteFieldByName(psEntry, "tof_raw_start_hdcnt_ps", "TOFSTART_HDCNT", fp);
        AddWriteFieldByName(psEntry, "rgb_start_hdcnt_ps"    , "TOFSTART_HDCNT", fp);

        // if (FindEntry(psEntry, "TOFSTART_PIXCNT", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->ToFStartPixCnt, MAX_LINE_SIZE);
        // }
        // See "http://aditrac.adsdesign.analog.com/trac/altostratus/ticket/389"
        if (this->ToFStartPixCnt != 0) {
          sprintf(psEntry, "%hu", this->ToFStartPixCnt);
        } else {
          sprintf(psEntry, "%hu", 2);
        }
        // AddSingleValueEntry(psEntry, "TOFSTART_PIXCNT", fp);
        AddWriteFieldByName(psEntry, "tof_raw_start_pixcnt_ps", "TOFSTART_PIXCNT; See http://aditrac.adsdesign.analog.com/trac/altostratus/ticket/389", fp);
        AddWriteFieldByName(psEntry, "rgb_start_pixcnt_ps"    , "TOFSTART_PIXCNT; See http://aditrac.adsdesign.analog.com/trac/altostratus/ticket/389", fp);

        // if (FindEntry(psEntry, "DFCT_PIX_ENBL", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->DfctPixEna, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->DfctPixEna);
        // AddSingleValueEntry(psEntry, "DFCT_PIX_ENBL", fp);
        AddWriteFieldByName(psEntry, "dfct_pix_enbl_ps", "DFCT_PIX_ENBL", fp);

        // if (FindEntry(psEntry, "DFCT_MED_REF_SEL", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->DfctMedRefSel, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->DfctMedRefSel);
        // AddSingleValueEntry(psEntry, "DFCT_MED_REF_SEL", fp);
        AddWriteFieldByName(psEntry, "dfct_med_ref_sel_ps", "DFCT_MED_REF_SEL", fp);

        // if (FindEntry(psEntry, "DFCT_DET_BSLN_SEL", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->DfctDetBslnSel, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->DfctDetBslnSel);
        // AddSingleValueEntry(psEntry, "DFCT_DET_BSLN_SEL", fp);
        AddWriteFieldByName(psEntry, "dfct_det_bsln_sel_ps", "DFCT_DET_BSLN_SEL", fp);

        // if (FindEntry(psEntry, "DFCT_PIX_SAT_TH", fp) == 0) {
        //      sscanf(psEntry, "%hx", &this->DfctPixSatTh, MAX_LINE_SIZE);
        // }
        //sprintf(psEntry, "0x%04hX", this->DfctPixSatTh);
        sprintf(psEntry, "12'h%03hx", this->DfctPixSatTh);
        // AddSingleValueEntry(psEntry, "DFCT_PIX_SAT_TH", fp);
        AddWriteFieldByName(psEntry, "dfct_pix_sat_th_ps", "DFCT_PIX_SAT_TH", fp);

        /*
        if (FindEntry(psEntry, "DFCT_PIX_TH_TBL", fp) == 0) {
                for (i = 0; i<DFCT_TH_TBL_SIZE; i++) {
                        fscanf_s(fp, "%hx", &this->DfctThrTbl[i], MAX_LINE_SIZE);
                }
        }
        */
        for (i = 0; i<DFCT_TH_TBL_SIZE; i++) {
          // sprintf(arrayStr1D[i], "0x%03hX", this->DfctThrTbl[i]);
          sprintf(arrayStr1D[i], "12'h%03hx", this->DfctThrTbl[i]);
        }
        //AddOneDimensionalArrayAmodelEntry(arrayStr1D, DFCT_TH_TBL_SIZE, "DFCT_PIX_TH_TBL", fp);
        AddWriteOneDimensionalArrayFieldByName(arrayStr1D, DFCT_TH_TBL_SIZE, "dfct_pix_th_tbl", "DFCT_PIX_TH_TBL", fp);
        
        // if (FindEntry(psEntry, "OBCLMPLEV", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->OBClmpLev, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hu", this->OBClmpLev);
        // AddSingleValueEntry(psEntry, "OBCLMPLEV", fp);
        AddWriteFieldByName(psEntry, "obclmplev_ps", "OBCLMPLEV", fp);

        // if (FindEntry(psEntry, "VGASHRT_XOFST", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->VGAShrtXOfst, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hu", this->VGAShrtXOfst);
        // AddSingleValueEntry(psEntry, "VGASHRT_XOFST", fp);
        AddWriteFieldByName(psEntry, "vgashrt_xofst_ps", "VGASHRT_XOFST", fp);

        // if (FindEntry(psEntry, "VGASHRT_XPWR", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->VGAShrtXPwr, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->VGAShrtXPwr);
        // AddSingleValueEntry(psEntry, "VGASHRT_XPWR", fp);
        AddWriteFieldByName(psEntry, "vgashrt_xpwr_ps", "VGASHRT_XPWR", fp);

        // if (FindEntry(psEntry, "VGALNG_SAT_TH", fp) == 0) {
        //      sscanf(psEntry, "%hx", &this->VGALngSatTh, MAX_LINE_SIZE);
        // }
        // sprintf(psEntry, "0x%04hX", this->VGALngSatTh);
        sprintf(psEntry, "12'h%03hx", this->VGALngSatTh);
        // AddSingleValueEntry(psEntry, "VGALNG_SAT_TH", fp);
        AddWriteFieldByName(psEntry, "vgalng_sat_th_ps", "VGALNG_SAT_TH", fp);

        // if (FindEntry(psEntry, "KS_VGA_SHRT2LNG", fp) == 0) {
        //      sscanf(psEntry, "%hx", &this->KsVGAShrt2Lng, MAX_LINE_SIZE);
        // }
        // sprintf(psEntry, "0x%04hX", this->KsVGAShrt2Lng);
        sprintf(psEntry, "12'h%03hx", this->KsVGAShrt2Lng);
        // AddSingleValueEntry(psEntry, "KS_VGA_SHRT2LNG", fp);
        AddWriteFieldByName(psEntry, "ks_vga_shrt2lng_ps", "KS_VGA_SHRT2LNG", fp);

        // if (FindEntry(psEntry, "WDR_BITSFT", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->WDRBitSft, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->WDRBitSft);
        // AddSingleValueEntry(psEntry, "WDR_BITSFT", fp);
        AddWriteFieldByName(psEntry, "wdr_bitsft_ps", "WDR_BITSFT", fp);

        // if (FindEntry(psEntry, "RawNREna", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->RawNREna, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->RawNREna);
        // AddSingleValueEntry(psEntry, "RawNREna", fp);
        AddWriteFieldByName(psEntry, "bypass_prodsum_ps", "RawNREna", fp);

        // if (FindEntry(psEntry, "RAWNR_MED4BL1_SEL", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->RawNRMed4Bl1Sel, MAX_LINE_SIZE);
        // }
        // sprintf(psEntry, "%hhu", this->RawNRMed4Bl1Sel);
        // AddSingleValueEntry(psEntry, "RAWNR_MED4BL1_SEL", fp);
        sprintf(psEntry, "%d", (this->RawNRMed4Bl1Sel & 0x2) >> 1);
        AddWriteFieldByName(psEntry, "rawnr_med_sel_ps", "RAWNR_MED4BL1_SEL[1]", fp);
        sprintf(psEntry, "%d", (this->RawNRMed4Bl1Sel & 0x1));
        AddWriteFieldByName(psEntry, "rawnr_med_en_ps" , "RAWNR_MED4BL1_SEL[0]", fp);

        // if (FindEntry(psEntry, "RAWNR_MED4BL1_GAIN", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->RawNRMed4Bl1Gain, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hu", this->RawNRMed4Bl1Gain);
        // AddSingleValueEntry(psEntry, "RAWNR_MED4BL1_GAIN", fp);
        AddWriteFieldByName(psEntry, "rawnr_medsel_gain_ps", "RAWNR_MED4BL1_GAIN", fp);

        // if (FindEntry(psEntry, "RAWNR_SAT_TH", fp) == 0) {
        //      sscanf(psEntry, "%hx", &this->RawNRSatTh, MAX_LINE_SIZE);
        // }
        // sprintf(psEntry, "0x%04hX", this->RawNRSatTh);
        sprintf(psEntry, "14'h%04hx", this->RawNRSatTh);
        // AddSingleValueEntry(psEntry, "RAWNR_SAT_TH", fp);
        AddWriteFieldByName(psEntry, "rawnr_sat_th_ps", "RAWNR_SAT_TH", fp);

        /*
        if (FindEntry(psEntry, "RAWNR_XPWR", fp) == 0) {
                this->RawNRXVal[0] = 0;
                for (i = 0; i<RAWNR_XPWR_TBL_SIZE; i++) {
                        fscanf_s(fp, "%hhu", &this->RawNRXPwr[i], MAX_LINE_SIZE);
                        this->RawNRXVal[i + 1] = (1 << this->RawNRXPwr[i]) + this->RawNRXVal[i];
                }
        }
        */
        for (i = 0; i<RAWNR_XPWR_TBL_SIZE; i++) {
          sprintf(arrayStr1D[i], "%hu", this->RawNRXPwr[i]);
        }
        //AddOneDimensionalArrayAmodelEntry(arrayStr1D, RAWNR_XPWR_TBL_SIZE, "RAWNR_XPWR", fp);
        AddWriteOneDimensionalArrayFieldByName(arrayStr1D, 1, RAWNR_XPWR_TBL_SIZE, "rawnr_xpwr", "RAWNR_XPWR", fp);

        /*
        if (FindEntry(psEntry, "RAWNR_BL_TBL", fp) == 0) {
                for (i = 0; i<RAWNR_YVAL_TBL_SIZE; i++) {
                        fscanf_s(fp, "%hu", &this->RawNRBlTbl[i], MAX_LINE_SIZE);
                }
        }
        */
        for (i = 0; i<RAWNR_YVAL_TBL_SIZE; i++) {
          //sprintf(arrayStr1D[i], "0x%03hX", this->RawNRBlTbl[i]);
          sprintf(arrayStr1D[i], "%hu", this->RawNRBlTbl[i]);
        }
        //AddOneDimensionalArrayAmodelEntry(arrayStr1D, RAWNR_YVAL_TBL_SIZE, "RAWNR_BL_TBL", fp);
        AddWriteOneDimensionalArrayFieldByName(arrayStr1D, RAWNR_YVAL_TBL_SIZE, "rawnr_bl_tbl", "RAWNR_BL_TBL", fp);

        /*
        if (FindEntry(psEntry, "RAWNR_BK_TBL", fp) == 0) {
                for (i = 0; i<RAWNR_YVAL_TBL_SIZE; i++) {
                        fscanf_s(fp, "%hu", &this->RawNRBkTbl[i], MAX_LINE_SIZE);
                }
        }
        */
        for (i = 0; i<RAWNR_YVAL_TBL_SIZE; i++) {
          sprintf(arrayStr1D[i], "%hu", this->RawNRBkTbl[i]);
        }
        //AddOneDimensionalArrayAmodelEntry(arrayStr1D, RAWNR_YVAL_TBL_SIZE, "RAWNR_BK_TBL", fp);
        AddWriteOneDimensionalArrayFieldByName(arrayStr1D, RAWNR_YVAL_TBL_SIZE, "rawnr_bk_tbl", "RAWNR_BK_TBL", fp);

        // djs (Note): These CoefTabl register field values are not currently being translated, but the following
        //             issues should be noted:
        //
        //                1) The default values defined in the spec are implemented as reset values.
        //                2) These registers may be eliminated due to timing and area constraints.
        //                3) These register fields form a 2-dimensional 10x7 array/table, but the 7th
        //                   value is always 0, and is not implemented in hardware.
        //                4) The register values are named "a" through "m", and do not appear in
        //                   "alphabetical" order in the register map.
        /*
        if (FindEntry(psEntry, "CoefTbl", fp) == 0) {
                for (i = 0; i<NR_FLT_COEF_TBL_SIZE; i++) {
                        fscanf_s(fp, "%hu", &unCoefIn[i], MAX_LINE_SIZE);
                }
        }
        */
        /*
        for (i = 0; i<NR_FLT_COEF_TBL_SIZE; i++) {
          sprintf(arrayStr1D[i], "%hu", this->unCoefIn[i]);
        }
        //AddOneDimensionalArrayAmodelEntry(arrayStr1D, NR_FLT_COEF_TBL_SIZE, "CoefTbl", fp);
        AddWriteOneDimensionalArrayFieldByName(arrayStr1D, NR_FLT_COEF_TBL_SIZE, "coeftbl", "CoefTbl", fp);   ** PLACEHOLDER ONLY **
        */
        
        /*
        // distribute 7x7 coefficients
        // Pixel postion array
        uint8 ucCoefIdx[49] =
        { 9, 8, 7, 6, 7, 8, 9,
        8, 5, 4, 3, 4, 5, 8,
        7, 4, 2, 1, 2, 4, 7,
        6, 3, 1, 0, 1, 3, 6,
        7, 4, 2, 1, 2, 4, 7,
        8, 5, 4, 3, 4, 5, 8,
        9, 8, 7, 6, 7, 8, 9 };

        for (i = 0; i<49; i++) {
                memcpy(&this->unCoefTbl[i][0], &unCoefIn[ucCoefIdx[i] * 7], 7 * sizeof(uint16));
        }
        */

        // if (FindEntry(psEntry, "SmSigRmvEna", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ucSmSigRmvEna, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->ucSmSigRmvEna);
        // AddSingleValueEntry(psEntry, "SmSigRmvEna", fp);
        AddWriteFieldByName(psEntry, "sm_sig_rmv_en_ps", "SmSigRmvEna", fp);
        
        // if (FindEntry(psEntry, "S0S1_CORTH", fp) == 0) {
        //      sscanf(psEntry, "%hx", &this->S0S1CorTh, MAX_LINE_SIZE);
        // }
        // sprintf(psEntry, "0x%02hX", this->S0S1CorTh);
        sprintf(psEntry, "14'h%04hx", this->S0S1CorTh);
        // AddSingleValueEntry(psEntry, "S0S1_CORTH", fp);
        AddWriteFieldByName(psEntry, "s0s1_corth_ps", "S0S1_CORTH", fp);

        // if (FindEntry(psEntry, "CORTH_DET_GAINF", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->CorThDetGainF, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hu", this->CorThDetGainF);
        // AddSingleValueEntry(psEntry, "CORTH_DET_GAINF", fp);
        AddWriteFieldByName(psEntry, "corth_det_gainf_ps", "CORTH_DET_GAINF", fp);

        // if (FindEntry(psEntry, "CORTH_DET_CNTF", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->CorThDetCntF, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->CorThDetCntF);
        // AddSingleValueEntry(psEntry, "CORTH_DET_CNTF", fp);
        AddWriteFieldByName(psEntry, "corth_det_cntf_ps", "CORTH_DET_CNTF", fp);

        // if (FindEntry(psEntry, "CORTH_SFT_GAINF", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->CorThSftGainF, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hu", this->CorThSftGainF);
        // AddSingleValueEntry(psEntry, "CORTH_SFT_GAINF", fp);
        AddWriteFieldByName(psEntry, "corth_sft_gainf_ps", "CORTH_SFT_GAINF", fp);

        // if (FindEntry(psEntry, "CORTH_SFT_INC_OFST", fp) == 0) {
        //      sscanf(psEntry, "%hd", &this->CorThSftIncOfst, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hd", this->CorThSftIncOfst);
        // AddSingleValueEntry(psEntry, "CORTH_SFT_INC_OFST", fp);
        AddWriteFieldByName(psEntry, "corth_sft_inc_ofst_ps", "CORTH_SFT_INC_OFST", fp);

        // if (FindEntry(psEntry, "CORTH_SFT_DEC_OFST", fp) == 0) {
        //      sscanf(psEntry, "%hd", &this->CorThSftDecOfst, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hd", this->CorThSftDecOfst);
        // AddSingleValueEntry(psEntry, "CORTH_SFT_DEC_OFST", fp);
        AddWriteFieldByName(psEntry, "corth_sft_dec_ofst_ps", "CORTH_SFT_DEC_OFST", fp);

        // if (FindEntry(psEntry, "CORTH_DET_GAINB", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->CorThDetGainB, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hu", this->CorThDetGainB);
        // AddSingleValueEntry(psEntry, "CORTH_DET_GAINB", fp);
        AddWriteFieldByName(psEntry, "corth_det_gainb_ps", "CORTH_DET_GAINB", fp);

        // if (FindEntry(psEntry, "CORTH_DET_CNTB", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->CorThDetCntB, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->CorThDetCntB);
        // AddSingleValueEntry(psEntry, "CORTH_DET_CNTB", fp);
        AddWriteFieldByName(psEntry, "corth_det_cntb_ps", "CORTH_DET_CNTB", fp);

        // if (FindEntry(psEntry, "CORTH_SFT_GAINB", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->CorThSftGainB, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hu", this->CorThSftGainB);
        // AddSingleValueEntry(psEntry, "CORTH_SFT_GAINB", fp);
        AddWriteFieldByName(psEntry, "corth_sft_gainb_ps", "CORTH_SFT_GAINB", fp);

        // if (FindEntry(psEntry, "DEPTHCALC_ADDVLU", fp) == 0) {
        //      sscanf(psEntry, "%hx", &this->DepthCalcAddVLU, MAX_LINE_SIZE);
        // }
        // sprintf(psEntry, "0x%04hX", this->DepthCalcAddVLU);
        sprintf(psEntry, "14'h%04hx", this->DepthCalcAddVLU);
        // AddSingleValueEntry(psEntry, "DEPTHCALC_ADDVLU", fp);
        AddWriteFieldByName(psEntry, "depthcalc_addvlu_ps", "DEPTHCALC_ADDVLU", fp);

        /*
        if (FindEntry(psEntry, "LNR_OFST", fp) == 0) {
                for (i = 0; i<LNR_OFFSET_VAL_TBL_SIZE; i++) {
                        fscanf_s(fp, "%hd", &this->LnrOfst[i], MAX_LINE_SIZE);
                }
        }
        */
        for (i = 0; i<LNR_OFFSET_VAL_TBL_SIZE; i++) {
          sprintf(arrayStr1D[i], "%hd", this->LnrOfst[i]);
        }
        //AddOneDimensionalArrayAmodelEntry(arrayStr1D, LNR_OFFSET_VAL_TBL_SIZE, "LNR_OFST", fp);
        AddWriteOneDimensionalArrayFieldByName(arrayStr1D, LNR_OFFSET_VAL_TBL_SIZE, "lnr_ofst", "LNR_OFST", fp);
        
        // if (FindEntry(psEntry, "LNR_X0", fp) == 0) {
        //      sscanf(psEntry, "%hd", &this->LnrX0, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hd", this->LnrX0);
        // AddSingleValueEntry(psEntry, "LNR_X0", fp);
        AddWriteFieldByName(psEntry, "lnr_x0_ps", "LNR_X0", fp);

        /*
        if (FindEntry(psEntry, "LNR_XPWR", fp) == 0) {
                for (i = 0; i<LNR_OFFSET_XPWR_TBL_SIZE; i++) {
                        fscanf_s(fp, "%hhu", &this->LnrXPwr[i], MAX_LINE_SIZE);
                }
        }
        */
        for (i = 0; i<LNR_OFFSET_XPWR_TBL_SIZE; i++) {
          sprintf(arrayStr1D[i], "%hu", this->LnrXPwr[i]);
        }
        //AddOneDimensionalArrayAmodelEntry(arrayStr1D, LNR_OFFSET_XPWR_TBL_SIZE, "LNR_XPWR", fp);
        // Register field values are named starting with "1"
        AddWriteOneDimensionalArrayFieldByName(arrayStr1D, 1, LNR_OFFSET_XPWR_TBL_SIZE, "lnr_xpwr", "LNR_XPWR", fp);
        
        // if (FindEntry(psEntry, "DEPTH_ZEROCORRE", fp) == 0) {
        //      sscanf(psEntry, "%hd", &this->DepthZeroCorre, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hd", this->DepthZeroCorre);
        // AddSingleValueEntry(psEntry, "DEPTH_ZEROCORRE", fp);
        AddWriteFieldByName(psEntry, "depth_zerocorre_ps", "DEPTH_ZEROCORRE", fp);

        // if (FindEntry(psEntry, "SHD_OFST_ENBL", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ucShdOfstEna, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->ucShdOfstEna);
        // AddSingleValueEntry(psEntry, "SHD_OFST_ENBL", fp);
        AddWriteFieldByName(psEntry, "shd_ofst_enbl_ps", "SHD_OFST_ENBL", fp);

        // if (FindEntry(psEntry, "SHD_X0", fp) == 0) {
        //      sscanf(psEntry, "%hd", &this->Shd_X0, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hd", this->Shd_X0);
        // AddSingleValueEntry(psEntry, "SHD_X0", fp);
        AddWriteFieldByName(psEntry, "shd_x0_ps", "SHD_X0", fp);

        // if (FindEntry(psEntry, "SHD_Y0", fp) == 0) {
        //      sscanf(psEntry, "%hd", &this->Shd_Y0, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hd", this->Shd_Y0);
        // AddSingleValueEntry(psEntry, "SHD_Y0", fp);
        AddWriteFieldByName(psEntry, "shd_y0_ps", "SHD_Y0", fp);

        /*
        if (FindEntry(psEntry, "SHD_XPWR", fp) == 0) {
                for (i = 0; i<SHADING_XPWR_TBL_SIZE; i++) {
                        fscanf_s(fp, "%hhu", &this->ShdXPwr[i], MAX_LINE_SIZE);
                }
        }
        */
        for (i = 0; i<SHADING_XPWR_TBL_SIZE; i++) {
          sprintf(arrayStr1D[i], "%hhu", this->ShdXPwr[i]);
        }
        //AddOneDimensionalArrayAmodelEntry(arrayStr1D, SHADING_XPWR_TBL_SIZE, "SHD_XPWR", fp);
        // Register field values are named starting with "1"
        AddWriteOneDimensionalArrayFieldByName(arrayStr1D, 1, SHADING_XPWR_TBL_SIZE, "shd_xpwr", "SHD_XPWR", fp);
                
        /*
        if (FindEntry(psEntry, "SHD_YPWR", fp) == 0) {
                for (i = 0; i<SHADING_YPWR_TBL_SIZE; i++) {
                        fscanf_s(fp, "%hhu", &this->ShdYPwr[i], MAX_LINE_SIZE);
                }
        }
        */
        for (i = 0; i<SHADING_YPWR_TBL_SIZE; i++) {
          sprintf(arrayStr1D[i], "%hhu", this->ShdYPwr[i]);
        }
        //AddOneDimensionalArrayAmodelEntry(arrayStr1D, SHADING_YPWR_TBL_SIZE, "SHD_YPWR", fp);
        // Register field values are named starting with "1"
        AddWriteOneDimensionalArrayFieldByName(arrayStr1D, 1, SHADING_YPWR_TBL_SIZE, "shd_ypwr", "SHD_YPWR", fp);
        
        /*
        if (FindEntry(psEntry, "SHD_OFST,", fp) == 0) {
                for (i = 0; i<SHADING_OFFSET_TBL_SIZE; i++) {
                        int16 offset;
                        fscanf_s(fp, "%hd", &offset, MAX_LINE_SIZE);
                        this->ShdOfst[i] = 2 * offset;
                }
        }
        */


        for (i = 0; i<SHADING_OFFSET_TBL_SIZE; i++) {
          sprintf(arrayStr1D[i], "%hd", this->ShdOfst[i]/2); // Account for post-read-in computation
        }
        //AddOneDimensionalArrayAmodelEntry(arrayStr1D, SHADING_OFFSET_TBL_SIZE, "SHD_OFST", fp);
        AddWriteOneDimensionalArrayRegByName(arrayStr1D, SHADING_OFFSET_TBL_SIZE, "SHD_OFST", "SHD_OFST", fp);

        // if (FindEntry(psEntry, "DEPTH_SLOPE_GAIN", fp) == 0) {
        //      sscanf(psEntry, "%hx", &this->DepthSlopeGain, MAX_LINE_SIZE);
        // }
        // sprintf(psEntry, "0x%03hX", this->DepthSlopeGain);
        sprintf(psEntry, "14'h%04hx", this->DepthSlopeGain);
        // AddSingleValueEntry(psEntry, "DEPTH_SLOPE_GAIN", fp);
        AddWriteFieldByName(psEntry, "depth_slope_gain_ps", "DEPTH_SLOPE_GAIN", fp);

        // if (FindEntry(psEntry, "DEPTH_OFSTVLU", fp) == 0) {
        //      sscanf(psEntry, "%hd", &this->DepthOfstVLU, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hd", this->DepthOfstVLU);
        // AddSingleValueEntry(psEntry, "DEPTH_OFSTVLU", fp);
        AddWriteFieldByName(psEntry, "depth_ofstvlu_ps", "DEPTH_OFSTVLU", fp);

        // if (FindEntry(psEntry, "IR_DGAIN", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->IRDGain, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hu", this->IRDGain);
        // AddSingleValueEntry(psEntry, "IR_DGAIN", fp);
        AddWriteFieldByName(psEntry, "ir_dgain_ps", "IR_DGAIN", fp);

        // if (FindEntry(psEntry, "IRIMG_SEL", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->IRImgSel, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->IRImgSel);
        // AddSingleValueEntry(psEntry, "IRIMG_SEL", fp);
        AddWriteFieldByName(psEntry, "ir_img_sel_ps", "IRIMG_SEL", fp);

        /*
        if (FindEntry(psEntry, "IR_GMM_PWR", fp) == 0) {
                for (i = 0; i<IR_GAMMA_PWR_TBL_SIZE - 1; i++) {
                        fscanf_s(fp, "%hhu", &this->IRGmmPwr[i], MAX_LINE_SIZE);
                        this->IRGmmX[i + 1] = (1 << this->IRGmmPwr[i]) + this->IRGmmX[i];
                }
        }
        */
        for (i = 0; i<IR_GAMMA_PWR_TBL_SIZE; i++) {
          sprintf(arrayStr1D[i], "%hhu", this->IRGmmPwr[i]);
        }
        //AddOneDimensionalArrayAmodelEntry(arrayStr1D, IR_GAMMA_PWR_TBL_SIZE, "IR_GMM_PWR", fp);
        // djs (Fix): IR_GAMMA_PWR_TBL_SIZE is larger than the actual number of registers, so we stop writing registers early
        //            See http://aditrac.adsdesign.analog.com/trac/altostratus/ticket/348
        AddWriteOneDimensionalArrayFieldByName(arrayStr1D, IR_GAMMA_PWR_TBL_SIZE - 1, "ir_gmm_pwr_x", "IR_GMM_PWR", fp);
        
        /*
        if (FindEntry(psEntry, "IR_GMM_Y", fp) == 0) {
                uint16 unDeltaY;
                for (i = 1; i<IR_GAMMA_PWR_TBL_SIZE; i++) {
                        fscanf_s(fp, "%hx", &unDeltaY, MAX_LINE_SIZE);
                        this->IRGmmY[i] = this->IRGmmY[i - 1] + unDeltaY;
                }
        }
        */
        for (i = 0; i<IR_GAMMA_PWR_TBL_SIZE; i++) {
          // sprintf(arrayStr1D[i], "0x%04hx", this->__iniFileIRGmmY[i]); // the "__iniFile..." variable captures the original value
          sprintf(arrayStr1D[i], "10'h%03hx", this->__iniFileIRGmmY[i]); // the "__iniFile..." variable captures the original value
        }
        //AddOneDimensionalArrayAmodelEntry(arrayStr1D, IR_GAMMA_PWR_TBL_SIZE, "IR_GMM_Y", fp);
        // djs (Fix): IR_GAMMA_PWR_TBL_SIZE is larger than the actual number of registers, so we stop writing registers early
        //            See http://aditrac.adsdesign.analog.com/trac/altostratus/ticket/348
        AddWriteOneDimensionalArrayFieldByName(arrayStr1D, IR_GAMMA_PWR_TBL_SIZE - 1, "ir_gmm_y", "IR_GMM_Y", fp);

        // if (FindEntry(psEntry, "OUTPUT_BG_SEL", fp) == 0) {
        //     sscanf(psEntry, "%hhu", &this->OutputBGSel);
        // }
        sprintf(psEntry, "%hhu", this->OutputBGSel);
        // AddSingleValueEntry(psEntry, "OUTPUT_BG_SEL", fp);
        AddWriteFieldByName(psEntry, "output_bg_sel", "OUTPUT_BG_SEL", fp);

        // if (FindEntry(psEntry, "OUTPUT_INTRLV_SEL", fp) == 0) {
        //     sscanf(psEntry, "%hhu", &this->OutputIntrlvSel);
        // }
        sprintf(psEntry, "%hhu", this->OutputIntrlvSel);
        // AddSingleValueEntry(psEntry, "OUTPUT_INTRLV_SEL", fp);
        AddWriteFieldByName(psEntry, "output_intrlv_sel", "OUTPUT_INTRLV_SEL", fp);

        // if (FindEntry(psEntry, "CHKR_DET_ENA", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ChkrDetEna, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->ChkrDetEna);
        // AddSingleValueEntry(psEntry, "CHKR_DET_ENA", fp);
        AddWriteFieldByName(psEntry, "chkr_det_ena_ps", "CHKR_DET_ENA", fp);

        // djs (Note): This register is actually managed by the "sensor_type_ps" register
        //               which is attached to the "ImgSensorType" parameter (see above)
        /*
        // if (FindEntry(psEntry, "CHKR_DET_TYPE_SEL", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ChkrDetTypeSel, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->ChkrDetTypeSel);
        // AddSingleValueEntry(psEntry, "CHKR_DET_TYPE_SEL", fp);
        AddWriteFieldByName(psEntry, "chkr_det_type_sel_ps", "CHKR_DET_TYPE_SEL", fp);
        */
        
        // if (FindEntry(psEntry, "CHKR_START_H", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->ChkrStartH, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hu", this->ChkrStartH);
        // AddSingleValueEntry(psEntry, "CHKR_START_H", fp);
        AddWriteFieldByName(psEntry, "chkr_start_h_ps", "CHKR_START_H", fp);

        // if (FindEntry(psEntry, "CHKR_START_V", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->ChkrStartV, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hu", this->ChkrStartV);
        // AddSingleValueEntry(psEntry, "CHKR_START_V", fp);
        AddWriteFieldByName(psEntry, "chkr_start_v_ps", "CHKR_START_V", fp);

        // if (FindEntry(psEntry, "CHKR_SIZE_H", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ChkrSizeH, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->ChkrSizeH);
        // AddSingleValueEntry(psEntry, "CHKR_SIZE_H", fp);
        AddWriteFieldByName(psEntry, "chkr_size_h_ps", "CHKR_SIZE_H", fp);

        // if (FindEntry(psEntry, "CHKR_UPPRTH", fp) == 0) {
        //      sscanf(psEntry, "%hx", &this->ChkrUpprTh, MAX_LINE_SIZE);
        // }
        // sprintf(psEntry, "0x%04hX", this->ChkrUpprTh);
        sprintf(psEntry, "12'h%03hx", this->ChkrUpprTh);
        // AddSingleValueEntry(psEntry, "CHKR_UPPRTH", fp);
        AddWriteFieldByName(psEntry, "chkr_upprth_ps", "CHKR_UPPRTH", fp);

        // if (FindEntry(psEntry, "CHKR_LWRTH", fp) == 0) {
        //      sscanf(psEntry, "%hx", &this->ChkrLwrTh, MAX_LINE_SIZE);
        // }
        // sprintf(psEntry, "0x%04hX", this->ChkrLwrTh);
        sprintf(psEntry, "12'h%03hx", this->ChkrLwrTh);
        // AddSingleValueEntry(psEntry, "CHKR_LWRTH", fp);
        AddWriteFieldByName(psEntry, "chkr_lwrth_ps", "CHKR_LWRTH", fp);

        // if (FindEntry(psEntry, "CHKR_UPPRERR_H", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ChkrUpprErrH, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->ChkrUpprErrH);
        // AddSingleValueEntry(psEntry, "CHKR_UPPRERR_H", fp);
        AddWriteFieldByName(psEntry, "chkr_upprerr_h", "CHKR_UPPRERR_H", fp);

        // if (FindEntry(psEntry, "CHKR_LWRERR_H", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ChkrLwrErrH, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->ChkrLwrErrH);
        // AddSingleValueEntry(psEntry, "CHKR_LWRERR_H", fp);
        AddWriteFieldByName(psEntry, "chkr_lwrerr_h", "CHKR_LWRERR_H", fp);

        // if (FindEntry(psEntry, "CHKR_UPPRERR_V", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ChkrUpprErrV, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->ChkrUpprErrV);
        // AddSingleValueEntry(psEntry, "CHKR_UPPRERR_V", fp);
        AddWriteFieldByName(psEntry, "chkr_upprerr_v", "CHKR_UPPRERR_V", fp);

        // if (FindEntry(psEntry, "CHKR_LWRERR_V", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ChkrLwrErrV, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hhu", this->ChkrLwrErrV);
        // AddSingleValueEntry(psEntry, "CHKR_LWRERR_V", fp);
        AddWriteFieldByName(psEntry, "chkr_lwrerr_v", "CHKR_LWRERR_V", fp);

        // if (FindEntry(psEntry, "CHKR_STARTOFST_H", fp) == 0) {
        //      sscanf(psEntry, "%hhu", &this->ChkrStrtOfstH, MAX_LINE_SIZE);
        // }
        // djs (Fix): Changed to match hex input string.
        //sprintf(psEntry, "%hhu", this->ChkrStrtOfstH);
        // sprintf(psEntry, "0x%02hX", this->ChkrStrtOfstH);
        sprintf(psEntry, "8'h%02hx", this->ChkrStrtOfstH);
        // AddSingleValueEntry(psEntry, "CHKR_STARTOFST_H", fp);
        AddWriteFieldByName(psEntry, "chkr_startofst_h_ps", "CHKR_STARTOFST_H", fp);
        
        return ec;
}

// Adds a single "write_field_by_name()" call to the UVM test
int Param::AddWriteFieldByName(char *pcEntry, char *pcRegisterField, char *pcAmodelKeyword, FILE *fp)
{
        int ret_code = 0;
	char psOutStr[MAX_LINE_SIZE];
        
        /* Verify all input */
        if (pcEntry == NULL || pcRegisterField == NULL || pcAmodelKeyword == NULL || fp == NULL) {
                return -1;
        }

        sprintf(psOutStr, "      write_field_by_name(status, \"%s\", %s);", pcRegisterField, pcEntry);
        sprintf(psOutStr, "%-"UVM_COMMENT_POS"s// A-Model parameter: %s\n", psOutStr, pcAmodelKeyword);

        ret_code = fprintf(fp, "%s", psOutStr);
        return ret_code;
}

// Adds a statement intended to cause a Verilog/SystemVerilog compilation error, but with some suitable clues as to what actually hosed the translation.
int Param::AddWriteFieldByNameError(char *pcEntry, char *pcRegisterField, char *pcAmodelKeyword, FILE *fp)
{
        int ret_code = 0;
        
        /* Verify all input */
        if (pcEntry == NULL || pcRegisterField == NULL || pcAmodelKeyword == NULL || fp == NULL) {
                return -1;
        }

        ret_code = fprintf(fp, "         `uvm_error(\"TRANSERR\", \"\n\tERROR IN TRANSLATION: Unsupported value for %s: %s.  %s register is not written\n\n\");", pcAmodelKeyword, pcEntry, pcRegisterField);
        return ret_code;
}

// Adds a one dimensional array entry to the UVM test, using "write_field_by_name()"
int Param::AddWriteOneDimensionalArrayFieldByName(array_str_t *arrayStr1D, unsigned int arrayLength, char *pcRegisterField, char *pcAmodelKeyword, FILE *fp)
{
        int ret_code = 0;
	char psOutStr[MAX_LINE_SIZE];
        
        /* Verify all input */
        if (arrayStr1D == NULL || pcRegisterField == NULL || pcAmodelKeyword == NULL || fp == NULL) {
                return -1;
        }

        for (unsigned int i = 0; i < arrayLength; i++) {
          sprintf(psOutStr, "      write_field_by_name(status, \"%s%d_ps\", %s);", pcRegisterField, i, (char *)arrayStr1D++);
          sprintf(psOutStr, "%-"UVM_COMMENT_POS"s// A-Model parameter: %s[%d]\n", psOutStr, pcAmodelKeyword, i);

          ret_code = fprintf(fp, "%s", psOutStr);
        }
        return ret_code;
}

// Adds a one dimensional array entry to the UVM test, using "write_field_by_name()", beginning at startingFieldNum
// --> ASSUMPTION: Input array begins at index 0 and end with an index of arrayLength (as might be rationally expected).
int Param::AddWriteOneDimensionalArrayFieldByName(array_str_t *arrayStr1D, unsigned int startingFieldNum, unsigned int arrayLength, char *pcRegisterField, char *pcAmodelKeyword, FILE *fp)
{
        int ret_code = 0;
	char psOutStr[MAX_LINE_SIZE];
        
        /* Verify all input */
        if (arrayStr1D == NULL || pcRegisterField == NULL || pcAmodelKeyword == NULL || fp == NULL) {
                return -1;
        }

        for (unsigned int i = startingFieldNum; i < arrayLength + startingFieldNum; i++) {
          sprintf(psOutStr, "      write_field_by_name(status, \"%s%d_ps\", %s);", pcRegisterField, i, (char *)arrayStr1D++);
          sprintf(psOutStr, "%-"UVM_COMMENT_POS"s// A-Model parameter: %s[%d]\n", psOutStr, pcAmodelKeyword, i - startingFieldNum);

          ret_code = fprintf(fp, "%s", psOutStr);
        }
        return ret_code;
}

// Adds a one dimensional array entry to the UVM test, using "write_reg_by_name()"
int Param::AddWriteOneDimensionalArrayRegByName(array_str_t *arrayStr1D, unsigned int arrayLength, char *pcRegisterName, char *pcAmodelKeyword, FILE *fp)
{
        int ret_code = 0;
	char psOutStr[MAX_LINE_SIZE];
        
        /* Verify all input */
        if (arrayStr1D == NULL || pcRegisterName == NULL || pcAmodelKeyword == NULL || fp == NULL) {
                return -1;
        }

        for (unsigned int i = 0; i < arrayLength; i++) {
          sprintf(psOutStr, "      reg_model.write_reg_by_name(status, \"%s[%d]\", %s);", pcRegisterName, i, (char *)arrayStr1D++);
          sprintf(psOutStr, "%-"UVM_COMMENT_POS"s// A-Model parameter: %s[%d]\n", psOutStr, pcAmodelKeyword, i);

          ret_code = fprintf(fp, "%s", psOutStr);
        }
        return ret_code;
}

int Param::WriteUvmTestHeader(FILE *fp, char *pcTestName, char *pcTestFilename)
{
        int ret_code;
  
        if ((ret_code = fprintf(fp, "//-----------------------------------------------------------------------------\n")) < 0)      return EC_FAIL;
        if ((ret_code = fprintf(fp, "// Project            : tof_processor\n")) < 0)                                                return EC_FAIL;
        if ((ret_code = fprintf(fp, "// File Name          : %s\n", pcTestFilename)) < 0)                                           return EC_FAIL;
        if ((ret_code = fprintf(fp, "// Original Author    : Generated by Param::CreateUVMTest()\n")) < 0)                          return EC_FAIL;
        if ((ret_code = fprintf(fp, "// Generated          : \n")) < 0)                                                             return EC_FAIL;
        if ((ret_code = fprintf(fp, "// Description        : Translated version of C++ Model %s test\n", pcTestName)) < 0)          return EC_FAIL;
        if ((ret_code = fprintf(fp, "//-----------------------------------------------------------------------------\n")) < 0)      return EC_FAIL;
        if ((ret_code = fprintf(fp, "// SVN Revision       : $Rev$\n")) < 0)                                                        return EC_FAIL;
        if ((ret_code = fprintf(fp, "// Last Commit Date   : $Date$\n")) < 0)                                                       return EC_FAIL;
        if ((ret_code = fprintf(fp, "// Last Commit Author : $Author$\n")) < 0)                                                     return EC_FAIL;
        if ((ret_code = fprintf(fp, "//-----------------------------------------------------------------------------\n")) < 0)      return EC_FAIL;
        if ((ret_code = fprintf(fp, "// Copyright (c) 2016 by ADI. This code is the confidential and\n")) < 0)                      return EC_FAIL;
        if ((ret_code = fprintf(fp, "// proprietary property of ADI and the possession or use of this\n")) < 0)                     return EC_FAIL;
        if ((ret_code = fprintf(fp, "// file requires a written license from ADI.\n")) < 0)                                         return EC_FAIL;
        if ((ret_code = fprintf(fp, "//------------------------------------------------------------------------------\n\n\n")) < 0) return EC_FAIL;

        return EC_OK;
}

int Param::WriteUvmTestSetupRegSeqClass(FILE *fp, char *pcTestName)
{
        int ret_code;
	char psImagerStr[MAX_LINE_SIZE];

        // djs (Fix): Might be useful to make this a private method
        switch (this->eImgSensorType)
          {
          case VGA_V1  : sprintf(psImagerStr, "_NO_DEFINED_PART_NUMBER_");
                         break;
          case VGA_V2  : sprintf(psImagerStr, "mn34902");
                         break;
          case VGA_V3  : sprintf(psImagerStr, "mn34906");
                         break;
          case SXGA_V1 : sprintf(psImagerStr, "mn34920");
                         break;
          case SXGA_V2 : sprintf(psImagerStr, "_NO_DEFINED_PART_NUMBER_");
                         break;
          case SXGA_V3 : sprintf(psImagerStr, "mn34926");
                         break;
          default      : sprintf(psImagerStr, "_NO_DEFINED_PART_NUMBER_");
                         break;
          }
  
        if ((ret_code = fprintf(fp, "// Setup for the %s sensor with align ramp and depth ramp\n", psImagerStr)) < 0)                                                                               return EC_FAIL;
        if ((ret_code = fprintf(fp, "class %s_setup extends tof_processor_%s_setup_reg_seq;\n\n", pcTestName, psImagerStr)) < 0)                                                                    return EC_FAIL;

        if ((ret_code = fprintf(fp, "   // UVM object utility macros\n\n")) < 0)                                                                                                                    return EC_FAIL;
        if ((ret_code = fprintf(fp, "   `uvm_object_utils(%s_setup)\n\n", pcTestName)) < 0)                                                                                                         return EC_FAIL;

        if ((ret_code = fprintf(fp, "   // Constructor\n")) < 0)                                                                                                                                    return EC_FAIL;
        if ((ret_code = fprintf(fp, "   function new(string name = \"%s_setup\");\n", pcTestName)) < 0)                                                                                             return EC_FAIL;
        if ((ret_code = fprintf(fp, "      super.new(name);\n")) < 0)                                                                                                                               return EC_FAIL;
        if ((ret_code = fprintf(fp, "   endfunction : new\n\n")) < 0)                                                                                                                               return EC_FAIL;

        if ((ret_code = fprintf(fp, "   // The body task contains the main functionality for the sequence\n")) < 0)                                                                                 return EC_FAIL;
        if ((ret_code = fprintf(fp, "   //   it is called directly by a sequence.start() call (for a root sequence)\n")) < 0)                                                                       return EC_FAIL;
        if ((ret_code = fprintf(fp, "   //   or from the body of another sequence (sub-sequence)\n")) < 0)                                                                                          return EC_FAIL;
        if ((ret_code = fprintf(fp, "   virtual task body();\n")) < 0)                                                                                                                              return EC_FAIL;
        if ((ret_code = fprintf(fp, "      uvm_status_e status;\n")) < 0)                                                                                                                           return EC_FAIL;
        if ((ret_code = fprintf(fp, "      uvm_reg_data_t data;\n\n")) < 0)                                                                                                                         return EC_FAIL;

        if ((ret_code = fprintf(fp, "      super.body();\n\n")) < 0)                                                                                                                                return EC_FAIL;

        // Generate all register writes based on test .ini parameters
        if ((ret_code = fprintf(fp, "      // --------------------------------------------------------------------\n")) < 0)                                                                        return EC_FAIL;
        if ((ret_code = fprintf(fp, "      //  All Param.ini registers are written below\n")) < 0)                                                                                                  return EC_FAIL;
        if ((ret_code = fprintf(fp, "      // --------------------------------------------------------------------\n")) < 0)                                                                        return EC_FAIL;

        WriteUVMParamRegWrites(fp);

        if ((ret_code = fprintf(fp, "      // --------------------------------------------------------------------\n")) < 0)                                                                        return EC_FAIL;
        if ((ret_code = fprintf(fp, "      //  All Param.ini registers are written above\n")) < 0)                                                                                                  return EC_FAIL;
        if ((ret_code = fprintf(fp, "      // --------------------------------------------------------------------\n\n")) < 0)                                                                      return EC_FAIL;

        if ((ret_code = fprintf(fp, "      // --------------------------------------------------------------------\n")) < 0)                                                                        return EC_FAIL;
        if ((ret_code = fprintf(fp, "      // All common registers are written below\n")) < 0)                                                                                                      return EC_FAIL;
        if ((ret_code = fprintf(fp, "      // --------------------------------------------------------------------\n")) < 0)                                                                        return EC_FAIL;
        if ((ret_code = fprintf(fp, "      // Interleave depth and IR data\n")) < 0)                                                                                                                return EC_FAIL;
        if ((ret_code = fprintf(fp, "      write_field_by_name(status,\"output_depth_ir_interleave_ps\", 1);\n\n")) < 0)                                                                            return EC_FAIL;

        if ((ret_code = fprintf(fp, "      // Write the image control registers\n")) < 0)                                                                                                           return EC_FAIL;
        if ((ret_code = fprintf(fp, "      write_field_by_name(status,\"tof_raw_start_pixcnt_ps\", dpiParam_get_tofStartPixCnt());\n")) < 0)                                                        return EC_FAIL;
        if ((ret_code = fprintf(fp, "      write_field_by_name(status,\"tof_raw_start_hdcnt_ps\",  dpiParam_get_tofStartHdCnt()); \n")) < 0)                                                        return EC_FAIL;
        if ((ret_code = fprintf(fp, "      write_field_by_name(status,\"tof_raw_width_pixcnt_ps\", dpiParam_get_uiInWidth() - dpiParam_get_tofStartPixCnt());\n\n")) < 0)                           return EC_FAIL;

        if ((ret_code = fprintf(fp, "      // Need to add 11 to keep the pipeline running until it is clear\n")) < 0)                                                                               return EC_FAIL;
        if ((ret_code = fprintf(fp, "      write_field_by_name(status,\"tof_raw_height_hdcnt_ps\", dpiParam_get_uiInHeight() - dpiParam_get_tofStartHdCnt() + 11);\n\n")) < 0)                      return EC_FAIL;

        if ((ret_code = fprintf(fp, "      write_field_by_name(status,\"tof_raw_roi_hstart\", 0);        // Until implemented in TOF C++ Model, set to 0\n")) < 0)                                  return EC_FAIL;
        if ((ret_code = fprintf(fp, "      write_field_by_name(status,\"tof_raw_roi_vstart\", 0);        // Until implemented in TOF C++ Model, set to 0\n\n")) < 0)                                return EC_FAIL;

        if ((ret_code = fprintf(fp, "      // Subtract 2 since gridding deletes 2 columns from the output image\n")) < 0)                                                                           return EC_FAIL;
        if ((ret_code = fprintf(fp, "      write_field_by_name(status,\"tof_image_width_ps\",  dpiParam_get_uiProcWidth() - 2);\n")) < 0)                                                           return EC_FAIL;
        if ((ret_code = fprintf(fp, "      // Set the ROI to the full width of the image\n")) < 0)                                                                                                  return EC_FAIL;             
        if ((ret_code = fprintf(fp, "      write_field_by_name(status,\"tof_raw_roi_width\",  dpiParam_get_uiProcWidth() - 2);\n\n")) < 0)                                                          return EC_FAIL;             

        if ((ret_code = fprintf(fp, "      // Subtract 1 since gridding deletes one line from the output image\n")) < 0)                                                                            return EC_FAIL;
        if ((ret_code = fprintf(fp, "      write_field_by_name(status,\"tof_image_height_ps\", dpiParam_get_uiProcHeight() - 1);\n")) < 0)                                                          return EC_FAIL;
        if ((ret_code = fprintf(fp, "      // Set the ROI to the full height of the image\n")) < 0)                                                                                                 return EC_FAIL;             
        if ((ret_code = fprintf(fp, "      write_field_by_name(status,\"tof_raw_roi_height\", dpiParam_get_uiProcHeight() - 1);\n\n")) < 0)                                                         return EC_FAIL;             
        
        if ((ret_code = fprintf(fp, "      // HD period must be:\n")) < 0)                                                                                                                          return EC_FAIL;
        if ((ret_code = fprintf(fp, "      //    1) > 4/3 the final image size\n")) < 0)                                                                                                            return EC_FAIL;
        if ((ret_code = fprintf(fp, "      //    2) Increased by 8 to handle the pipeline delay through the filter\n")) < 0)                                                                        return EC_FAIL;
        if ((ret_code = fprintf(fp, "      //    3) A multiple of 4\n")) < 0)                                                                                                                       return EC_FAIL;
        if ((ret_code = fprintf(fp, "      write_field_by_name(status,\"hd_period_ps\", 4*dpiParam_get_uiProcWidth()/3 + 8 + ((4 - (4*dpiParam_get_uiProcWidth()/3) %% 4) %% 4));\n")) < 0)         return EC_FAIL;

        if ((ret_code = fprintf(fp, "   endtask // body()\n\n")) < 0)                                                                                                                               return EC_FAIL;
        if ((ret_code = fprintf(fp, "endclass // %s_setup\n\n", pcTestName)) < 0)                                                                                                                   return EC_FAIL;

        return EC_OK;
}

int Param::WriteUvmTestTestClass(FILE *fp, char *pcTestName, char *pcImageFilename)
{
        int ret_code;
	char psEntry[MAX_LINE_SIZE];

        if ((ret_code = fprintf(fp, "class %s extends tof_processor_base_test;\n", pcTestName)) < 0)                                                                   return EC_FAIL;
        if ((ret_code = fprintf(fp, "// Instantiate the sequence to run during this test\n")) < 0)                                                                     return EC_FAIL;
        if ((ret_code = fprintf(fp, "   tof_processor_load_file_vseq seq;\n")) < 0)                                                                                    return EC_FAIL;
        if ((ret_code = fprintf(fp, "\n")) < 0)                                                                                                                        return EC_FAIL;
        if ((ret_code = fprintf(fp, "   // UVM component utility macros\n")) < 0)                                                                                      return EC_FAIL;
        if ((ret_code = fprintf(fp, "   `uvm_component_utils(%s)\n", pcTestName)) < 0)                                                                                 return EC_FAIL;
        if ((ret_code = fprintf(fp, "\n")) < 0)                                                                                                                        return EC_FAIL;
        if ((ret_code = fprintf(fp, "   // Constructor\n")) < 0)                                                                                                       return EC_FAIL;
        if ((ret_code = fprintf(fp, "   function new(string name = \"%s\", uvm_component parent = null);\n", pcTestName)) < 0)                                         return EC_FAIL;
        if ((ret_code = fprintf(fp, "      super.new(name, parent);\n")) < 0)                                                                                          return EC_FAIL;
        if ((ret_code = fprintf(fp, "\n")) < 0)                                                                                                                        return EC_FAIL;
        if ((ret_code = fprintf(fp, "      // Replace the setup with a different sensor\n")) < 0)                                                                      return EC_FAIL;
        if ((ret_code = fprintf(fp, "      set_type_override_by_type(tof_processor_setup_seq::get_type(), %s_setup::get_type());\n", pcTestName)) < 0)                 return EC_FAIL;
        if ((ret_code = fprintf(fp, "      // Replace the field type with an RGB field\n")) < 0)                                                                       return EC_FAIL;
        if ((ret_code = fprintf(fp, "      set_type_override_by_type(tof_input_base_seq::get_type(), tof_input_bw_seq::get_type());\n")) < 0)                          return EC_FAIL;
        if ((ret_code = fprintf(fp, "\n")) < 0)                                                                                                                        return EC_FAIL;
        if ((ret_code = fprintf(fp, "   endfunction : new\n")) < 0)                                                                                                    return EC_FAIL;
        if ((ret_code = fprintf(fp, "\n")) < 0)                                                                                                                        return EC_FAIL;
        if ((ret_code = fprintf(fp, "   // Build phase\n")) < 0)                                                                                                       return EC_FAIL;
        if ((ret_code = fprintf(fp, "   virtual function void build_phase(uvm_phase phase);\n")) < 0)                                                                  return EC_FAIL;
        if ((ret_code = fprintf(fp, "      super.build_phase(phase);\n")) < 0)                                                                                         return EC_FAIL;
        if ((ret_code = fprintf(fp, "\n")) < 0)                                                                                                                        return EC_FAIL;
        if ((ret_code = fprintf(fp, "      // Create the sequence\n")) < 0)                                                                                            return EC_FAIL;
        if ((ret_code = fprintf(fp, "      seq = tof_processor_load_file_vseq::type_id::create(\"seq\", this);\n")) < 0)                                               return EC_FAIL;
        if ((ret_code = fprintf(fp, "   endfunction : build_phase\n")) < 0)                                                                                            return EC_FAIL;
        if ((ret_code = fprintf(fp, "\n")) < 0)                                                                                                                        return EC_FAIL;
        if ((ret_code = fprintf(fp, "   // Main phase\n")) < 0)                                                                                                        return EC_FAIL;
        if ((ret_code = fprintf(fp, "\n")) < 0)                                                                                                                        return EC_FAIL;
        if ((ret_code = fprintf(fp, "   virtual task main_phase(uvm_phase phase);\n")) < 0)                                                                            return EC_FAIL;
        if ((ret_code = fprintf(fp, "      super.main_phase(phase);\n")) < 0)                                                                                          return EC_FAIL;
        if ((ret_code = fprintf(fp, "\n")) < 0)                                                                                                                        return EC_FAIL;
        if ((ret_code = fprintf(fp, "      // Connect register model to the sequence model\n")) < 0)                                                                   return EC_FAIL;
        if ((ret_code = fprintf(fp, "      seq.model = cfg.reg_model;\n")) < 0)                                                                                        return EC_FAIL;
        if ((ret_code = fprintf(fp, "\n")) < 0)                                                                                                                        return EC_FAIL;
        if ((ret_code = fprintf(fp, "      // Start the virtual sequence on the virtual sequencer\n")) < 0)                                                            return EC_FAIL;
        if ((ret_code = fprintf(fp, "      `uvm_info(\"START_SEQ\", \"Invoking tof_processor_load_file_vseq\", UVM_LOW)\n")) < 0)                                      return EC_FAIL;
        if ((ret_code = fprintf(fp, "      seq.starting_phase = phase;\n")) < 0)                                                                                       return EC_FAIL;
        if ((ret_code = fprintf(fp, "      seq.start(env.vsqr);\n")) < 0)                                                                                              return EC_FAIL;
        if ((ret_code = fprintf(fp, "\n")) < 0)                                                                                                                        return EC_FAIL;
        if ((ret_code = fprintf(fp, "   endtask : main_phase\n")) < 0)                                                                                                 return EC_FAIL;
        if ((ret_code = fprintf(fp, "\n")) < 0)                                                                                                                        return EC_FAIL;
        if ((ret_code = fprintf(fp, "   // Uncomment this function to set test-specific configuration parameters by overriding the base class implementation\n")) < 0) return EC_FAIL;
        if ((ret_code = fprintf(fp, "   //   This function is called in super.build_phase()\n")) < 0)                                                                  return EC_FAIL;
        if ((ret_code = fprintf(fp, "   virtual function void configure_env();\n")) < 0)                                                                               return EC_FAIL;
        if ((ret_code = fprintf(fp, "      // base test class instantiates tof_processor_env_cfg cfg and calls cfg.randomize()\n")) < 0)                               return EC_FAIL;
        if ((ret_code = fprintf(fp, "      cfg.afe_clk2x_dr_en = 0;\n")) < 0)                                                                                          return EC_FAIL;
        if ((ret_code = fprintf(fp, "\n")) < 0)                                                                                                                        return EC_FAIL;

        // Add the image buffer file, to be read by the driver
        sprintf(psEntry, "\"%s\"", pcImageFilename);
        AddConfigEnvCfgAssignment(psEntry, "input_data_buffer_loadfile_name", "From \"Image.txt\"\n", fp);

        // Generate all of the necessary config_env() writes, a much smaller subset of all parameters
        if ((ret_code = fprintf(fp, "      // --------------------------------------------------------------------\n")) < 0)                                           return EC_FAIL;
        if ((ret_code = fprintf(fp, "      //  All Param.ini config values are set below\n")) < 0)                                                                     return EC_FAIL;
        if ((ret_code = fprintf(fp, "      // --------------------------------------------------------------------\n")) < 0)                                           return EC_FAIL;

        WriteUVMConfigEnvWrites(fp);

        if ((ret_code = fprintf(fp, "      // --------------------------------------------------------------------\n")) < 0)                                           return EC_FAIL;
        if ((ret_code = fprintf(fp, "      //  All Param.ini config values are set above\n")) < 0)                                                                     return EC_FAIL;
        if ((ret_code = fprintf(fp, "      // --------------------------------------------------------------------\n\n")) < 0)                                         return EC_FAIL;                       

        if ((ret_code = fprintf(fp, "\n")) < 0)                                                                                                                        return EC_FAIL;
        if ((ret_code = fprintf(fp, "   endfunction : configure_env\n")) < 0)                                                                                          return EC_FAIL;
        if ((ret_code = fprintf(fp, "\n")) < 0)                                                                                                                        return EC_FAIL;
        if ((ret_code = fprintf(fp, "endclass : %s\n", pcTestName)) < 0)                                                                                               return EC_FAIL;

        return EC_OK;
}

// Translate any necessary parameters into UVM config assignments, which are included in the configure_env() function in the test's test class
errcode_t Param::WriteUVMConfigEnvWrites(FILE *fp)
{

        char psEntry[MAX_LINE_SIZE];
        errcode_t ec = EC_OK;

        // =============================================================================
        // All config **C++ dpiParam** assignments follow...
        // =============================================================================

        /* Write the various parameters from the supplied file */
        // if (FindEntry(psEntry, "ImgSensorType", fp) == 0) {
        //      sscanf(psEntry, "%d", &this->eImgSensorType, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%d", this->eImgSensorType);
        // AddSingleValueEntry(psEntry, "ImgSensorType", fp);
        switch (this->eImgSensorType)
          {
          case VGA_V1  : AddConfigEnvDpiParamSet("VGA_V1", "eImgSensorType", "ImgSensorType: VGA_V1, No defined part number.  Assuming VGA/IR.", fp);
                         break;                          
          case VGA_V2  : AddConfigEnvDpiParamSet("VGA_V2", "eImgSensorType", "ImgSensorType: VGA_V2, MN34902BL", fp);
                         break;                          
          case VGA_V3  : AddConfigEnvDpiParamSet("VGA_V3", "eImgSensorType", "ImgSensorType: VGA_V3, MN34906BL", fp);
                         break;                          
          case SXGA_V1 : AddConfigEnvDpiParamSet("SXGA_V1", "eImgSensorType", "ImgSensorType: SXGA_V1, MN34920BL", fp);
                         break;                          
          case SXGA_V2 : AddConfigEnvDpiParamSet("SXGA_V2", "eImgSensorType", "ImgSensorType: SXGA_V2, No defined part number.  Assuming SXGA/IR.", fp);
                         break;                          
          case SXGA_V3 : AddConfigEnvDpiParamSet("SXGA_V3", "eImgSensorType", "ImgSensorType: SXGA_V3, MN34926BL", fp);
                         break;
          default      : AddConfigEnvDpiParamSetError(psEntry, "eImgSensorType", "ImgSensorType", fp);
                         break;
          }

        // if (FindEntry(psEntry, "InWidth", fp) == 0) {
        //      sscanf(psEntry, "%u", &this->uiInWidth );
        // }
        sprintf(psEntry, "%u", this->uiInWidth);
        // AddSingleValueEntry(psEntry, "InWidth", fp);
        AddConfigEnvDpiParamSet(psEntry, "uiInWidth", "InWidth", fp);

        //if (FindEntry(psEntry, "InHeight", fp) == 0) {
        //      sscanf(psEntry, "%u", &this->uiInHeight );
        // }
        sprintf(psEntry, "%u", this->uiInHeight);
        // AddSingleValueEntry(psEntry, "InHeight", fp);
        AddConfigEnvDpiParamSet(psEntry, "uiInHeight", "InHeight", fp);

        // if (FindEntry(psEntry, "OutWidth", fp) == 0) {
        //      sscanf(psEntry, "%u", &this->uiOutWidth );
        // }
        sprintf(psEntry, "%u", this->uiOutWidth);
        // AddSingleValueEntry(psEntry, "OutWidth", fp);
        AddConfigEnvDpiParamSet(psEntry, "uiOutWidth", "OutWidth", fp);

        // if (FindEntry(psEntry, "OutHeight", fp) == 0) {
        //      sscanf(psEntry, "%u", &this->uiOutHeight );
        // }
        sprintf(psEntry, "%u", this->uiOutHeight);
        // AddSingleValueEntry(psEntry, "OutHeight", fp);
        AddConfigEnvDpiParamSet(psEntry, "uiOutHeight" , "OutHeight", fp);

        // if (FindEntry(psEntry, "TOFSTART_PIXCNT", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->ToFStartPixCnt, MAX_LINE_SIZE);
        // }
        // See "http://aditrac.adsdesign.analog.com/trac/altostratus/ticket/389"
        if (this->ToFStartPixCnt != 0) {
          sprintf(psEntry, "%hu", this->ToFStartPixCnt);
        } else {
          sprintf(psEntry, "%hu", 2);
        }
        // AddSingleValueEntry(psEntry, "TOFSTART_PIXCNT", fp);
        AddConfigEnvDpiParamSet(psEntry, "tofStartPixCnt", "TOFSTART_PIXCNT; See http://aditrac.adsdesign.analog.com/trac/altostratus/ticket/389", fp);

        // if (FindEntry(psEntry, "TOFSTART_HDCNT", fp) == 0) {
        //      sscanf(psEntry, "%hu", &this->ToFStartHDCnt, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%hu", this->ToFStartHDCnt);
        // AddSingleValueEntry(psEntry, "TOFSTART_HDCNT", fp);
        AddConfigEnvDpiParamSet(psEntry, "tofStartHdCnt", "TOFSTART_HDCNT\n", fp);


        // =============================================================================
        // All config **cfg data structure** assignments follow...
        // =============================================================================

        // cfg.input_frame_agt_cfg.input_raw_width    = dpiParam_get_uiInWidth();                         
        AddConfigEnvDpiParamCfgAssignment("dpiParam_get_uiInWidth()", "input_raw_width" , "", fp);

        // cfg.input_frame_agt_cfg.input_raw_height   = dpiParam_get_uiInHeight();              
        AddConfigEnvDpiParamCfgAssignment("dpiParam_get_uiInHeight()", "input_raw_height" , "", fp);

        // cfg.input_frame_agt_cfg.hd_period         = 4*dpiParam_get_uiProcWidth()/3 + 8 + ((4 - (4*dpiParam_get_uiProcWidth()/3) % 4) % 4); // HD period must be > 4/3 the final image size. Plus 8 to handle the pipeline delay through the filter, and be a multiple of 4
        AddConfigEnvDpiParamCfgAssignment("4*dpiParam_get_uiProcWidth()/3 + 8 + ((4 - (4*dpiParam_get_uiProcWidth()/3) % 4) % 4)", "hd_period", "HD period must be > 4/3 the final image size. Plus 8 to handle the pipeline delay through the filter, and be a multiple of 4", fp);
 
        // cfg.input_frame_agt_cfg.vd_period          = dpiParam_get_uiInHeight() + 11;     // Need to add 11 to keep the pipeline running until it is clear
        AddConfigEnvDpiParamCfgAssignment("dpiParam_get_uiInHeight() + 11", "vd_period" , "Need to add 11 to keep the pipeline running until it is clear", fp);
        

        /* Write the various parameters from the supplied file */
        // if (FindEntry(psEntry, "ImgSensorType", fp) == 0) {
        //      sscanf(psEntry, "%d", &this->eImgSensorType, MAX_LINE_SIZE);
        // }
        sprintf(psEntry, "%d", this->eImgSensorType);
        // AddSingleValueEntry(psEntry, "ImgSensorType", fp);
        switch (this->eImgSensorType)
          {
          case VGA_V1  : AddConfigEnvCfgAssignment("tof_processor_pkg::EN_SENSOR_TYPE_PS'(2'b00)", "sensor_type", "ImgSensorType: VGA_V1, No defined part number.  Assuming VGA/IR.", fp);
                         break;
          case VGA_V2  : AddConfigEnvCfgAssignment("tof_processor_pkg::EN_SENSOR_TYPE_PS'(2'b00)", "sensor_type", "ImgSensorType: VGA_V2, MN34902BL", fp);
                         break;
          case VGA_V3  : AddConfigEnvCfgAssignment("tof_processor_pkg::EN_SENSOR_TYPE_PS'(2'b00)", "sensor_type", "ImgSensorType: VGA_V3, MN34906BL", fp);
                         break;
          case SXGA_V1 : AddConfigEnvCfgAssignment("tof_processor_pkg::EN_SENSOR_TYPE_PS'(2'b01)", "sensor_type", "ImgSensorType: SXGA_V1, MN34920BL", fp);
                         break;
          case SXGA_V2 : AddConfigEnvCfgAssignment("tof_processor_pkg::EN_SENSOR_TYPE_PS'(2'b01)", "sensor_type", "ImgSensorType: SXGA_V2, No defined part number.  Assuming SXGA/IR.", fp);
                         break;
          case SXGA_V3 : AddConfigEnvCfgAssignment("tof_processor_pkg::EN_SENSOR_TYPE_PS'(2'b01)", "sensor_type", "ImgSensorType: SXGA_V3, MN34926BL", fp);
                         break;
          default      : AddConfigEnvCfgAssignmentError(psEntry, "sensor_type", "ImgSensorType", fp);
                         break;
          }

        return ec;
}

// Adds a config_env() dpiParam_set_ functional call to the UVM test
int Param::AddConfigEnvDpiParamSet(char *pcEntry, char *pcDpiParamVarName, char *pcAmodelKeyword, FILE *fp)
{
        int ret_code = 0;
	char psOutStr[MAX_LINE_SIZE];
        
        /* Verify all input */
        if (pcEntry == NULL || pcDpiParamVarName == NULL || pcAmodelKeyword == NULL || fp == NULL) {
                return -1;
        }

        sprintf(psOutStr, "      dpiParam_set_%s(%s);", pcDpiParamVarName, pcEntry);
        sprintf(psOutStr, "%-"UVM_CFG_COMMENT_POS"s // A-Model parameter: %s\n", psOutStr, pcAmodelKeyword);

        ret_code = fprintf(fp, "%s", psOutStr);
        return ret_code;
}

// Adds a statement intended to cause a Verilog/SystemVerilog compilation error, but with some suitable clues as to what actually hosed the translation.
// djs (Question): Necessary??  How about a common Error() function?
int Param::AddConfigEnvDpiParamSetError(char *pcEntry, char *pcDpiParamVarName, char *pcAmodelKeyword, FILE *fp)
{
        int ret_code = 0;
        
        /* Verify all input */
        if (pcEntry == NULL || pcDpiParamVarName == NULL || pcAmodelKeyword == NULL || fp == NULL) {
                return -1;
        }

        ret_code = fprintf(fp, "         `uvm_error(\"TRANSERR\", \"\n\tERROR IN TRANSLATION: Unsupported value for %s: %s.  %s Param::Param() variable is not assigned\n\n\");", pcAmodelKeyword, pcEntry, pcDpiParamVarName);
        return ret_code;
}

// Adds a config_env() assignment to the UVM test
int Param::AddConfigEnvCfgAssignment(char *pcEntry, char *pcConfigVarName, char *pcAmodelKeyword, FILE *fp)
{
        int ret_code = 0;
	char psOutStr[MAX_LINE_SIZE];
        
        /* Verify all input */
        if (pcEntry == NULL || pcConfigVarName == NULL || pcAmodelKeyword == NULL || fp == NULL) {
                return -1;
        }

        sprintf(psOutStr, "      cfg.input_frame_agt_cfg.%s", pcConfigVarName);
        sprintf(psOutStr, "%-"UVM_CFG_VAL_POS"s = %s;", psOutStr, pcEntry);
        sprintf(psOutStr, "%-"UVM_CFG_COMMENT_POS"s // A-Model parameter: %s\n", psOutStr, pcAmodelKeyword);

        ret_code = fprintf(fp, "%s", psOutStr);
        return ret_code;
}

// Adds a statement intended to cause a Verilog/SystemVerilog compilation error, but with some suitable clues as to what actually hosed the translation.
// djs (Question): Necessary??  How about a common Error() function?
int Param::AddConfigEnvCfgAssignmentError(char *pcEntry, char *pcConfigVarName, char *pcAmodelKeyword, FILE *fp)
{
        int ret_code = 0;
        
        /* Verify all input */
        if (pcEntry == NULL || pcConfigVarName == NULL || pcAmodelKeyword == NULL || fp == NULL) {
                return -1;
        }

        ret_code = fprintf(fp, "         `uvm_error(\"TRANSERR\", \"\n\tERROR IN TRANSLATION: Unsupported value for %s: %s.  %s config variable is not assigned\n\n\");", pcAmodelKeyword, pcEntry, pcConfigVarName);
        return ret_code;
}

// Adds a config_env() assignment to the UVM test
int Param::AddConfigEnvDpiParamCfgAssignment(char *pcEntry, char *pcConfigVarName, char *pcAmodelKeyword, FILE *fp)
{
        int ret_code = 0;
	char psOutStr[MAX_LINE_SIZE];
        
        /* Verify all input */
        if (pcEntry == NULL || pcConfigVarName == NULL || pcAmodelKeyword == NULL || fp == NULL) {
                return -1;
        }

        sprintf(psOutStr, "      cfg.input_frame_agt_cfg.%s", pcConfigVarName);
        sprintf(psOutStr, "%-"UVM_CFG_VAL_POS"s = %s;", psOutStr, pcEntry);
        if (strlen(pcAmodelKeyword) != 0) {
          sprintf(psOutStr, "%-"UVM_CFG_COMMENT_POS"s // %s\n", psOutStr, pcAmodelKeyword);
        } else {
          sprintf(psOutStr, "%-"UVM_CFG_COMMENT_POS"s\n", psOutStr);
        }

        ret_code = fprintf(fp, "%s", psOutStr);
        return ret_code;
}

// Adds a statement intended to cause a Verilog/SystemVerilog compilation error, but with some suitable clues as to what actually hosed the translation.
// djs (Question): Necessary??  How about a common Error() function?
int Param::AddConfigEnvDpiParamCfgAssignmentError(char *pcEntry, char *pcConfigVarName, char *pcAmodelKeyword, FILE *fp)
{
        int ret_code = 0;
        
        /* Verify all input */
        if (pcEntry == NULL || pcConfigVarName == NULL || pcAmodelKeyword == NULL || fp == NULL) {
                return -1;
        }

        ret_code = fprintf(fp, "         `uvm_error(\"TRANSERR\", \"\n\tERROR IN TRANSLATION: Unsupported value for %s: %s.  %s config variable is not assigned\n\n\");", pcAmodelKeyword, pcEntry, pcConfigVarName);
        return ret_code;
}

// Writes the test-specific sim.setup file, which is necessary to copy the image filename into the run directory
errcode_t Param::WriteUvmTestSimDotSetupFile(FILE *fp, char *pcImageFilename)
{
        int ret_code;
        errcode_t ec = EC_OK;
               
        if ((ret_code = fprintf(fp, "# $Id:$\n")) < 0)                                                                          return EC_FAIL;
        if ((ret_code = fprintf(fp, "# Test-specific sim.seup file\n")) < 0)                                                    return EC_FAIL;
        if ((ret_code = fprintf(fp, "# --> Generated by Param::CreateUVMTest()\n")) < 0)                                        return EC_FAIL;
        
        if ((ret_code = fprintf(fp, "\nPRE_SIM_COMMANDS : cp ${TOF_C_MODEL_TEST}/RawInputImages/%s .\n", pcImageFilename)) < 0) return EC_FAIL;

        return ec;
}
        
