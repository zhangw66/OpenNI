/********************************************************************************/
/*																				*/
/* @file	DepthCorrect.h														*/
/*																				*/
/* @brief	Performs post depth correction.										*/
/*																				*/
/* @author	Dhruvesh Gajaria													*/
/*																				*/
/* @date	May 3, 2017     													*/
/*																				*/
/* Copyright(c) Analog Devices, Inc.											*/
/*																				*/
/********************************************************************************/

#include <stdafx.h>
#include <cstdlib>
#include "Param.h"
#include "DepthCorrect.h"


DepthCorrect::DepthCorrect(Param *pcParams, uint16 *punS0, uint16 *punS1, uint16 *punBG, uint16 *punDepth)
{
	this->pcParams = pcParams;
	this->punS0 = punS0;
    this->punS1 = punS1;
    this->punBG = punBG;
	this->punDepth = punDepth;
}

DepthCorrect::~DepthCorrect()
{
}

/*
    Depth2MM - Converts from depth code to MM using floating
    point types for better accuracy.
*/
void  DepthCorrect::Depth2MM()
{
	int i;
	int uiBufSize = pcParams->uiProcWidth*pcParams->uiProcHeight;
	double DepthOfstVLU = (double) pcParams->DepthOfstVLU;
    double ConvFactor = pcParams->DepthCnvGain;
    double DepthMax = (double) pcParams->DepthMax;

    if (pcParams->eAfePart != AFE_ADDI9030 && !pcParams->ucRawMode) {
        ConvFactor *= 4;
    }

    for (i = 0; i < uiBufSize; i++) {
        double dDepth = (double) punDepth[i];
        dDepth *= ConvFactor;
        dDepth = dDepth > DepthMax ? DepthMax : dDepth;
        punDepth[i] = (uint16) (dDepth + DepthOfstVLU + 0.5);
    }
}


