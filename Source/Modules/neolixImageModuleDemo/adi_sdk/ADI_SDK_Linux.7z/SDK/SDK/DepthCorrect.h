/********************************************************************************/
/*																				*/
/* @file	DepthCorrect.h														*/
/*																				*/
/* @brief	Performs post depth correction.										*/
/*																				*/
/* @author	Dhruvesh Gajaria													*/
/*																				*/
/* @date	May 3, 2017     													*/
/*																				*/
/* Copyright(c) Analog Devices, Inc.											*/
/*																				*/
/********************************************************************************/
#ifndef _DEPTHCORRECT_H_
#define _DEPTHCORRECT_H_

#include "types.h"
#include "Param.h"

// Near Code increments per cm 
// CodeSlope is the total number of codes divided by the max distance.
// For near range, max distance is the distance it takes reflected light to 
// travel to and from a target during one sensor clock period
// CodeSlope = (16384 codes) / (speed of light/2 * clk period * 1 periods)
// CodeSlope = (16384 codes) / (299792458/2 m/s * 22.22 ns) = 4918.6 codes/m = 49.186 codes/cm
#ifndef ELSA_TIMING
#define CAL_NEAR_CODE_SLOPE 49.186
// Time tick slope = 16384 codes / (128 ticks/clk period * 1 clk periods) = 128
#define CAL_NEAR_TICK_SLOPE 128
#define CAL_NEAR_SLPADJ_GAIN 833
#define CAL_NEAR_DEPTH_MAX 3331
#define CAL_NEAR_MAX_STATE 3
#else
// For the Elsa system, Near range is modified to use a 16.84 ns LD pulse
#define CAL_NEAR_CODE_SLOPE 64.905
// Time tick slope = 16384 codes / (128 ticks/clk period * 1 clk periods) = 128
#define CAL_NEAR_TICK_SLOPE 168.9
#define CAL_NEAR_SLPADJ_GAIN 631
#define CAL_NEAR_DEPTH_MAX 2525
#define CAL_NEAR_MAX_STATE 3
#endif

// XNear Code increments per cm 
// CodeSlope is the total number of codes divided by the max distance.
// For near range, max distance is the distance it takes reflected light to 
// travel to and from a target during one sensor clock period
// CodeSlope = (16384 codes) / (speed of light/2 * clk period * 1 periods)
// CodeSlope = (16384 codes) / (299792458/2 m/s * 26.22 ns) = 4169.4 codes/m = 41.694 codes/cm
#ifndef TIMING_5_METER
#define CAL_XNEAR_CODE_SLOPE 41.694
#else
#define CAL_XNEAR_CODE_SLOPE 13
#endif
// Time tick slope = 16384 codes / 151 ticks = 108.5
#define CAL_XNEAR_TICK_SLOPE 108.5
#define CAL_XNEAR_SLPADJ_GAIN 982
#define CAL_XNEAR_DEPTH_MAX 3930
#define CAL_XNEAR_MAX_STATE 3

// Set the LD pos value for XNear since it's not available by reading the HPT register values in file 2
#define CAL_INIT_XNEAR_LD_POS 64
#define CAL_INIT_XNEAR_LD_NEG 81
#define CAL_INIT_XNEAR_SUB_POS 85
#define CAL_INIT_XNEAR_SUB_NEG 55
#define CAL_XNEAR_S0S1_DIFF 23

// XNear (for ADDI9033) Code increments per cm 
// CodeSlope is the total number of codes divided by the max distance.
// For near range, max distance is the distance it takes reflected light to 
// travel to and from a target during one sensor clock period
// CodeSlope = (16384 codes) / (speed of light/2 * clk period * 1 periods)
// CodeSlope = (16384 codes) / (299792458/2 m/s * 27.78 ns) = 3934.88218 codes/m = 39.3488218 codes/cm
#if 1
#define CAL_XNEAR_ADDI9033_CODE_SLOPE 41.694
// Time tick slope = 16384 codes / 151 ticks = 108.5
#define CAL_XNEAR_ADDI9033_TICK_SLOPE 108.5
#define CAL_XNEAR_ADDI9033_SLPADJ_GAIN 982
#define CAL_XNEAR_ADDI9033_DEPTH_MAX 3930
#define CAL_XNEAR_ADDI9033_MAX_STATE 3
// ELSA XNear range timing
#define CAL_INIT_ADDI9033_XNEAR_LD_POS 32
#define CAL_INIT_ADDI9033_XNEAR_LD_NEG 55
#define CAL_INIT_ADDI9033_XNEAR_SUB_POS 32
#define CAL_INIT_ADDI9033_XNEAR_SUB_NEG 55
#define CAL_XNEAR_ADDI9033_S0S1_DIFF 23
#else
// This is different XNear timing to reach 4m of detph range.
// This timing is used for customer G.  To recreate this timing
// loadfile #5 needs to be modified.  In the future, these settings
// will be part of the calibration configuration loaded from .ini files
#define CAL_XNEAR_ADDI9033_CODE_SLOPE 39.3488218
// Time tick slope = 16384 codes / 160 ticks = 102.4
#define CAL_XNEAR_ADDI9033_TICK_SLOPE 102.4
#define CAL_XNEAR_ADDI9033_SLPADJ_GAIN 1066
#define CAL_XNEAR_ADDI9033_DEPTH_MAX 4200
#define CAL_XNEAR_ADDI9033_MAX_STATE 3

#define CAL_INIT_ADDI9033_XNEAR_LD_POS 32
#define CAL_INIT_ADDI9033_XNEAR_LD_NEG 64
#define CAL_INIT_ADDI9033_XNEAR_SUB_POS 48
#define CAL_INIT_ADDI9033_XNEAR_SUB_NEG 80
#define CAL_XNEAR_ADDI9033_S0S1_DIFF 32
#endif

// MID Code increments per cm 
// CodeSlope is the total number of codes divided by the max distance.
// For mid range Max distance is the distance it takes reflected light 
// to travel to and from a target during two sensor clock periods
// CodeSlope = (16384 codes) / (speed of light/2 * clk period * 2 periods)
// CodeSlope = (16384 codes) / (299792458/2 m/s * 22.22 ns * 2) = 2459.3 codes/m = 24.593 codes/cm
#define CAL_MID_CODE_SLOPE 24.593
// Time tick slope = 16384 codes / (128 ticks/clk period * 2 clk periods) = 64
#define CAL_MID_TICK_SLOPE 64
#define CAL_MID_SLPADJ_GAIN 1666
#define CAL_MID_DEPTH_MAX 6662
#define CAL_MID_MAX_STATE 4

// Far Code increments per cm 
// CodeSlope is the total number of codes divided by the max distance.
// For near range, max distance is the distance it takes reflected light to 
// travel to and from a target during four sensor clock periods
// CodeSlope = (16384 codes) / (speed of light/2 * clk period * 4 periods)
// CodeSlope = (16384 codes) / (299792458/2 m/s * 22.22 ns * 4) = 1229.65 codes/m = 12.2965 codes/cm
#define CAL_FAR_CODE_SLOPE 12.2965
// Time tick slope = 16384 codes / (128 ticks/clk period * 4 clk periods) = 32
#define CAL_FAR_TICK_SLOPE 32
#define CAL_FAR_SLPADJ_GAIN 3339
#define CAL_FAR_DEPTH_MAX 13324
#define CAL_FAR_MAX_STATE 3



#define DEPTH_CALC_FULL_PHASE 0x2000
#define DEPTH_CALC_MAX_VALUE 0x3fff

#define DEPTH_OUTPUT_MAX_VALUE 0xfff

class DepthCorrect {
protected:
	Param *pcParams;  // Pointer to the system parameters
	uint16 *punS0;
    uint16 *punS1;
    uint16 *punBG;
	uint16 *punDepth;

public:
    DepthCorrect(Param *pcParams = NULL, uint16 *punS0 = NULL, uint16 *punS1 = NULL, uint16 *punBG = NULL, uint16 *punDepth = NULL);
    ~DepthCorrect();
    void setInPtrs(uint16 *punS0, uint16 *punS1, uint16 *punBG, uint16 *punDepth) { this->punS0 = punS0; this->punS1 = punS1; this->punBG = punBG; this->punDepth = punDepth; }
	void setDepthOutPtr(uint16 *punDepth) { this->punDepth = punDepth; }
    void Depth2MM();
};


#endif // _DEPTHCALC_H_
