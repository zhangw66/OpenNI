/********************************************************************************/
/*																				*/
/* @file	ADI_TOF.cpp															*/
/*																				*/
/* @brief	ADI TOF SDK to capture raw data, process it and return S0,S1,BG,	*/ 
/*			IR Image and the depth image										*/
/*          																	*/
/*																				*/
/* @author	Dhruvesh Gajaria													*/
/*																				*/
/* @date	April 26, 2016														*/
/*																				*/
/* Copyright(c) Analog Devices, Inc.											*/
/*																				*/
/********************************************************************************/
#define SDK_LITE
#include <stdafx.h>
#include "ADI_TOF.h"
#include "Param.h"

#include "DepthCorrect.h"
#include "IsaTg.h"
#include "SpiXfer.h"
#include "ConfidenceFilter.h"
#include "device.h"
#include "CalTbl.h"
#include<iostream>
using namespace std;

enum frameIndx
{
	RAW = 1, //668x750 Resolution 
	DEPTHIR = 2, //640x960 Resolution 
	DEPTH = 3, //640x480 Resolution
};

class ADI_TOF::Data
{
public:
	// Processing Ojects
    Param *pParams;
	SpiXfer *pSpiXfer;
	IsaTg *pIsaTg;

    DepthCorrect *pDepthCorrect;
	// Image buffers
	uint16 *punRawData;
    uint16 *punS0Raw;
	uint16 *punS1Raw;
	uint16 *punS2Raw;
#ifndef EXTRA_PROCESSING
	uint16 *punS0Grd;
	uint16 *punS1Grd;
	uint16 *punS2Grd;
#endif
	uint16 *punS0;
	uint16 *punS1;
	uint16 *punBG;
	uint8 *pucRngFlg;
	uint16 *punLastDepth;
	uint16 *punIR;
	uint16 *punDepth;
	uint16 *punDepthOut;
	uint16 *punIROut;

	//Confidence Map
	uint16 *punConfidenceMap;



	isa_code_block_t *pCodeBlk;
#ifdef OPENCV
	cv::VideoCapture *pCap;
	cv::Mat *mInputFrameY16;
#else
    Device *dev;
#endif

	//Filter Type
	eFilterSel_t eImgProcFilterSel;

	//Background Threshold
	uint16 unImgProcBkGndThr;

	//Post Process ConfidenceFilter
	ConfidenceFilter confidenceFilter;

	//Temporal Filter Flag
	uint16 temporalFilterEnable;

	//ADDI9033/35 Specific Declarations
    bool bDepthIRMode;
	bool bRawMode;

	//Streaming Flag
	bool bToFProcActive;

	//Multi-Range
	bool bMR;
	CalTbl *pCalTbl;

	//Initialize Depth Range
	void initDepthRange(range value, uint16 level);

	//Temporary variables to backup Depth range and level
	int oldRange;
	int oldLevel;
    int cameraNum;
};

ADI_TOF::ADI_TOF()
{
	data=new Data;
    data->pParams = new Param();

    data->pDepthCorrect = new DepthCorrect(data->pParams);
	data->pIsaTg = new IsaTg();
	data->pSpiXfer = new SpiXfer();
#ifdef OPENCV
	data->pCap = new cv::VideoCapture;
	data->mInputFrameY16 =  new cv::Mat;
#else
	data->dev=new Device();
#endif
	

	data->temporalFilterEnable = 0;
	data->bDepthIRMode = true;
	data->bRawMode = false;

	//Multi-Range
	data->bMR = false;
	data->pCalTbl = new CalTbl(data->pParams);

	data->oldRange = 0;
	data->oldLevel = 0;
    data->cameraNum = -1;
}

ADI_TOF::~ADI_TOF()
{
	
    delete(data->pParams);

    delete(data->pDepthCorrect);
	delete(data->pIsaTg);
	delete(data->pSpiXfer);
#ifdef OPENCV
	data->pCap = new cv::VideoCapture;
	data->mInputFrameY16 =  new cv::Mat;
#else
	delete(data->dev);
#endif
	delete(data->pCalTbl);
	delete(data);
}

void DispCpy(uint16 *punDispImg, uint16 *punOutImg, Param *pParams)
{
	int iInW = pParams->uiProcWidth;
	int iOutH = pParams->uiOutHeight;
	int iOutW = pParams->uiOutWidth;

	for (int j = 0; j < iOutH; j++) {
		for (int i = 0; i < iOutW; i++) {
			punDispImg[j*iOutW + i] = punOutImg[j*iInW + i];
		}
	}
}

void expandDisp(uint16 *punOutImg, uint16 *punInImg, Param *pParams)
{
	int iInW =  pParams->uiOutWidth;
	int iInH = pParams->uiOutHeight;
	int iOutH = pParams->uiProcHeight;
	int iOutW = pParams->uiProcWidth;

	for (int j = 0; j < iOutH; j++) {
		for (int i = 0; i < iOutW; i++) {
			if(i<iInW && j<iInH)
				punOutImg[j*iOutW + i] = punInImg[j*iInW + i];
			else
				punOutImg[j*iOutW + i] = 0;
		}
	}
}

int ADI_TOF::Init(bool playBackEna, int cameraNum)
{

	// Initialize system paramters based on sensor type
	errcode_t ec;
	//ec = data->pParams->ParamInit("SensorType.ini");
	if (data->pParams->eImgSensorType == VGA_V2 || data->pParams->eImgSensorType == VGA_V3) {
		ec = data->pParams->ParamInit("ParamVGA.ini");
		if (ec != EC_OK) {
            cout<<"ParamVGA.ini read failed\n";
		}
	}
	else if (data->pParams->eImgSensorType == SXGA_V1) {
		ec = data->pParams->ParamInit("ParamSXGA.ini");
				
		if (ec != EC_OK) {
            cout<<"ParamVGA.ini read Failed\n";
		}
	}
	else {
		//errMsg = "Senso type not supported","Error!!!";
	}
	ec = data->pParams->ParamInit("SensorType.ini");
    //cout<<"Initialized Camera Sensor2\n";
	// Open the input stream device (ToF camera)
			
	if (data->pParams->eImgSensorType <= VGA_V3) {
		switch (data->pParams->eDepthRange) {
		case DEPTH_RANGE_NEAR:
			data->pParams->ParamInit("LinearCorrectVGANear.ini");
			data->pParams->ucDepthMode = 0;
			break;
		case DEPTH_RANGE_MID:
			data->pParams->ParamInit("LinearCorrectVGAMid.ini");
			if (data->pParams->eAfePart == AFE_ADDI9030) {
				data->pParams->ucDepthMode = 1;
			}
			else {
				data->pParams->ucDepthMode = 0;
				data->pParams->ucM3WSel = 1;
			}
			break;
		case DEPTH_RANGE_FAR:
		case DEPTH_RANGE_XFAR:
			data->pParams->ParamInit("LinearCorrectVGAFar.ini");
			data->pParams->ucDepthMode = 1;
			break;
		}
	}
	else {
		switch (data->pParams->eDepthRange) {
		case DEPTH_RANGE_NEAR:
			data->pParams->ParamInit("LinearCorrectSXGANear.ini");
			data->pParams->ucDepthMode = 0;
			break;
		case DEPTH_RANGE_MID:
			data->pParams->ParamInit("LinearCorrectSXGAMid.ini");
			data->pParams->ucDepthMode = 1;
			break;
		case DEPTH_RANGE_FAR:
		case DEPTH_RANGE_XFAR:
			data->pParams->ParamInit("LinearCorrectSXGAFar.ini");
			data->pParams->ucDepthMode = 1;
			break;
		}
	}
    if(!playBackEna)
    {
 #ifdef OPENCV
	        int deviceNo=-1;
            deviceNo = data->pSpiXfer->getDeviceId(data->pParams->eImgSensorType);
	        cout<<"ADI TOF Camera Found:"<<deviceNo<<endl;
	        if(deviceNo==-1)

	        {
		        std::cout<<"ADI TOF Camera not found Error!!!"<<endl;
		        return -1;

	        }
	
			
	        this->data->pCap->open(deviceNo);
 
	        if( !this->data->pCap->isOpened() )

	        {	
		        std::cout<<"ADI TOF Camera cannot be opened Error!!!"<<endl;
		        return -1;

	        }
#else
		int status;
		if(data->pParams->ucRawMode || data->pParams->eAfePart == AFE_ADDI9030)
		{
			status=data->dev->openDevice(RAW, cameraNum); //Open Camera with frame index 1 :  668x750 RAW
		}
		else
		{
			status=data->dev->openDevice(DEPTHIR, cameraNum); //Open Camera with frame index 2 :  640x960 Depth/IR
		}

		if(status==-1)
		{
            cout<<"ADI TOF Camera not found Error!!!\n";
			return -1;
		}
		else if(status==-2)
		{
            cout<<"ADI TOF Camera cannot be opened Error!!!\n";
			return -1;
		}
#endif
    
	}

	//cout<<"Initialized Camera Sensor3\n";
	// Allocate all the image buffers
	// Pre-grid buffers
	int iBufSize = data->pParams->uiProcWidth * data->pParams->uiProcHeight;
	data->punRawData = (uint16 *)malloc(sizeof(uint16) * data->pParams->uiInWidth * data->pParams->uiInHeight);
	
	//Gridding Buffers
	data->punS0Grd = (uint16 *) malloc(sizeof(uint16) * iBufSize);
    data->punS1Grd = (uint16 *) malloc(sizeof(uint16) * iBufSize);
    data->punS2Grd = (uint16 *) malloc(sizeof(uint16) * iBufSize);
	
	// Post-grid buffers
	data->punS0 = (uint16 *)malloc(sizeof(uint16) * iBufSize);
	data->punS1 = (uint16 *)malloc(sizeof(uint16) * iBufSize);
	data->punBG = (uint16 *)malloc(sizeof(uint16) * iBufSize);
	data->pucRngFlg = (uint8 *)malloc(sizeof(uint8) * iBufSize);
			
	// Final depth buffer
	data->punDepth = (uint16 *)malloc(sizeof(uint16) * iBufSize);
	data->punIR = (uint16 *)malloc(sizeof(uint16) * iBufSize);
	data->punLastDepth=NULL;

	//Confidence Map
	data->punConfidenceMap = (uint16 *)malloc(sizeof(uint16) * iBufSize);



	/*
		* IsaTg Initialization
		*	Related parameters:
        *		eDepthRange
		*		unLDPulseCnt
		*/
	data->pIsaTg->setSensorType(data->pParams->eImgSensorType);
	data->pIsaTg->setDepthRange(data->pParams->eDepthRange);
	data->pParams->ucDepthMode = data->pIsaTg->getDepthRange() == DEPTH_RANGE_NEAR ? 0 : 1;
	data->pIsaTg->setPulseCnt(data->pParams->unLDPulseCnt);
	data->pIsaTg->setRawMode(data->pParams->ucRawMode);
	data->pIsaTg->setAfePart(data->pParams->eAfePart);
    data->pIsaTg->setLaserEnaReg(data->pParams->unLaserEnaReg);
	data->pCodeBlk = data->pIsaTg->getBaseCode();

	// Initialize ISATG code
	data->pIsaTg->setSensorType(data->pParams->eImgSensorType);
	data->pIsaTg->setDepthRange(data->pParams->eDepthRange);

		try {
#ifndef OPENCV
				data->pSpiXfer->spiInit(data->dev);
#else
				data->pSpiXfer->spiInit(data->pCap,(xferT) data->pParams->xferType);
#endif

                if (data->pParams->eAfePart != AFE_ADDI9030) {
                    data->pIsaTg->setAfePart(data->pParams->eAfePart);
					// Clear the current values
                    data->pIsaTg->clrHPTStdbyOffsets();
					// Reload and send to SPI
    		        data->pCodeBlk = data->pIsaTg->getBaseCode(data->pParams);
				    data->pIsaTg->setTALEnable(true);
					if(data->pParams->ucRawMode == 0)
					{
						data->pParams->RawNREna = 1;  //Enable NR filter by default for ADDI9033/35
					}
                    if(data->pParams->ucRawMode == 0)
                    {
                        data->pIsaTg->getDepthIRModeCode(true);  // Set Depth/IR mode
                    }
			}
		
		}
		catch (STRING e) {
			//return e;
		}

    data->cameraNum = cameraNum;
	return 0;
}

void ADI_TOF::Release()
{
	delete(data->punRawData);
	free(data->punS0Grd);
    free(data->punS1Grd);
    free(data->punS2Grd);
    free(data->punS0);
	free(data->punS1);	
	free(data->punBG);
	free(data->pucRngFlg);
	free(data->punDepth);
	free(data->punIR);
	free(data->punConfidenceMap);


}




void ADI_TOF::setThreshold(uint16 unImgProcBkGndThr)
{
	//cout<<" setThreshold called\n";
	data->unImgProcBkGndThr = unImgProcBkGndThr*10;
	data->pParams->S0S1CorTh = data->unImgProcBkGndThr;
    data->pParams->ucSmSigRmvEna = data->unImgProcBkGndThr ? 1 : 0;

    if ((data->pParams->eAfePart != AFE_ADDI9030) && !data->pParams->ucRawMode) {
        data->pSpiXfer->SpiWrSlow(data->pIsaTg->getToFIPCode(data->pParams));
    }
}


void ADI_TOF::setFilter(eFilterSel_t filter)
{
	//cout<<" setFilter called\n";
	data->eImgProcFilterSel=filter;	
	
	data->pParams->RawNREna = filter == (FILT_SEL_NONE )? 0:1;
	if ((data->pParams->eAfePart != AFE_ADDI9030) && !data->pParams->ucRawMode) {
        data->pSpiXfer->SpiWrSlow(data->pIsaTg->getBaseCode(data->pParams));
    }
}

void ADI_TOF::setConfidenceFilter(uint16 confidencePercent, uint16 *confidenceMap)
{
	data->confidenceFilter.setConfidencePercent(confidencePercent);
	data->confidenceFilter.setDimensions(data->pParams->uiOutHeight,data->pParams->uiOutWidth);
	data->confidenceFilter.enable=1;
	data->confidenceFilter.setOutPtr(data->punConfidenceMap);
	punConfidenceMap = data->punConfidenceMap;
}

uint16* ADI_TOF::confidenceFilter(uint16 confidencePercent)
{
	data->confidenceFilter.setConfidencePercent(confidencePercent);
	data->confidenceFilter.setDimensions(data->pParams->uiOutHeight,data->pParams->uiOutWidth);
    data->confidenceFilter.setInPtr(punDepth, punIR);
	data->confidenceFilter.setOutPtr(data->punConfidenceMap);
	data->confidenceFilter.confidenceFilter();
    punConfidenceMap = data->punConfidenceMap;
	return(data->punConfidenceMap);
}

void ADI_TOF::clearConfidenceFilter()
{
	data->confidenceFilter.enable=0;
}

void ADI_TOF::setTemporalFilter()
{
	data->temporalFilterEnable=1;
}

void ADI_TOF::clearTemporalFilter()
{
	data->temporalFilterEnable=0;
}


/* 
 * Gaus5x5 - Optimized Gaussian 5x5 filter.
 *   pnDst - input/output image
 *   iW - Image width
 *   iH - Image height
*/
void Gaus5x5(uint16 *pnDst, int iW, int iH)
{
	int sumA5, sumB3;

	int *sumA1 = (int *)calloc(iW, sizeof(int));
	int *sumA2 = (int *)calloc(iW, sizeof(int));
	int *sumA3 = (int *)calloc(iW, sizeof(int));
	int *sumA4 = (int *)calloc(iW, sizeof(int));
	int *sumB1 = (int *)calloc(iW, sizeof(int));
	int *sumB2 = (int *)calloc(iW, sizeof(int));

	uint16 *pnSrc = (uint16 *) malloc(iW*iH*sizeof(uint16));
	memcpy(pnSrc, pnDst, iW*iH*sizeof(uint16));

	for (int j = 0; j < iH - 2; j++) {
		int trmA1 = 0, trmA2 = 0, trmA3 = 0, trmA4 = 0, trmA5;
		int trmB1 = 0, trmB2 = 0, trmB3;
		int y = j*iW;
//#pragma omp parallel for
		for (int i = 0; i < iW - 2; i++) {
			trmB3 = 24 * pnSrc[y + (i + 1)];
			trmA5 = 6 * pnSrc[y + (i + 2)];
			int y1 = y + iW;
			sumB3 = 4 * pnSrc[y1 + (i - 2)] + 16 * pnSrc[y1 + (i - 1)] + 24 * pnSrc[y1 + i] + 16 * pnSrc[y1 + (i + 1)] + 4 * pnSrc[y1 + (i + 2)];
			int y2 = y1 + iW;
			sumA5 = pnSrc[y2 + (i - 2)] + 4 * pnSrc[y2 + (i - 1)] + 6 * pnSrc[y2 + i] + 4 * pnSrc[y2 + (i + 1)] + pnSrc[y2 + (i + 2)];
	
			if (pnSrc[y + i] != 0x3fff) {
				pnDst[y + i] = (sumA1[i] + sumB1[i] + trmA1 + trmB1 + 36 * pnSrc[y + i] + trmB3 + trmA5 + sumA5 + sumB3) >> 8;
			}
			else {
				pnDst[y + i] = 0x3fff;
			}
			
			trmA1 = trmA2; trmA2 = trmA3; trmA3 = trmA4; trmA4 = trmA5;
			trmB1 = trmB2; trmB2 = trmB3;
			sumA1[i] = sumA2[i]; sumA2[i] = sumA3[i]; sumA3[i] = sumA4[i]; sumA4[i] = sumA5;
			sumB1[i] = sumB2[i]; sumB2[i] = sumB3;
		}
		//pnDst[j*iW + iW - 2] = pnSrc[j*iW + iW - 2];
		//pnDst[j*iW + iW - 1] = pnSrc[j*iW + iW - 1];
	}
	//memcpy(&pnDst[iW*(iH-2)], &pnSrc[iW*(iH-2)], 2*iW*sizeof(int16));

	free(sumA1);
	free(sumA2);
	free(sumA3);
	free(sumA4);
	free(sumB1);
	free(sumB2);
	free(pnSrc);
}



int ADI_TOF::rawProcFrame(uint16 *punRawIn)
{
	uint32 uiProcHeight = data->pParams->uiProcHeight;
	uint32 uiProcWidth = data->pParams->uiProcWidth;
	uint32 uiInHeight = data->pParams->uiInHeight;
	uint32 uiInWidth = data->pParams->uiInWidth;
    int iBufSize = data->pParams->uiInWidth * data->pParams->uiInHeight;
	punDepth = NULL;
	punIR = NULL;
	punRaw = NULL;
	punS0 = NULL;
	punS1 = NULL;
	punS2 = NULL;

#ifndef OPENCV
	uint16 *punInputBuffer = NULL;
#endif

	int emptyFrame=0;

	if(punRawIn==NULL)
	{
#ifndef OPENCV
		punInputBuffer=(data->dev->getImage());
        // If an empty frame is recieved, reset AFE and return
		while(punInputBuffer == NULL) {
#else		
		*data->pCap >> *data->mInputFrameY16;
        // If an empty frame is recieved, reset AFE and return
		while( data->mInputFrameY16->empty()) {
#endif
			if(emptyFrame == 1)
			{
				cout<<"Empty Frame\n";
			}
			emptyFrame=1;

#ifdef OPENCV
			*data->pCap>>*data->mInputFrameY16;
#else           
            delete data->dev;
            data->dev = NULL;

            data->dev= new Device();
            int status = 0;
            if(data->pParams->ucRawMode || data->pParams->eAfePart == AFE_ADDI9030)
               {
                   status=data->dev->openDevice(1, data->cameraNum); //Open Camera with frame index 2 : 640x960 Depth/IR
               }
               else
               {
                   status=data->dev->openDevice(2, data->cameraNum); //Open Camera with frame index 1 : 668*750 Raw
               }
            if(status==-1)
            {
               printf("ADI TOF Camera not found : Error!!!\n");
               return -1;
            }
            else if(status==-2)
            {
               printf("ADI TOF Camera cannot be opened : Error!!!\n");
               return -1;
            }
            printf("Empty Frame, Programming AFE\n");
            data->pCodeBlk = data->pIsaTg->getBaseCode(data->pParams);
            data->pSpiXfer->SpiWrSlow(data->pCodeBlk);
            data->pIsaTg->wrToFIPToFile("12_TOF_ProcCtrl.lf");
			punInputBuffer=(data->dev->getImage());
#endif
		}
    }
    else
    {
            punInputBuffer=punRawIn;
    }

		/************* Raw sensor data processing ***********/
        if (data->pParams->eAfePart == AFE_ADDI9030 || data->pParams->ucRawMode) {
		    // Copy raw data into a local buffer
		    for(uint32 j=0; j<uiInHeight; j++) {
#ifndef OPENCV
			    for(uint32 i=0; i<uiInWidth; i++) {
					data->punRawData[j*uiInWidth + i] = punInputBuffer[j*uiInWidth + i];
			    }
#else
			    for(uint32 i=0; i<uiInWidth; i++) {
				    data->punRawData[j*uiInWidth + i] = data->mInputFrameY16->at<ushort>(j, i);
			    }
			    data->bProgramAFE=false;
#endif
		    }
	    }
        else {
#ifndef OPENCV
            // For ADDI9033 check for how data is being output and copy to buffers accordingly
		    for(uint32 j=0; j<data->pParams->uiOutHeight * 2; j++) {
                if (j & 1) {
                    // IR Lines
			        for(uint32 i=0; i<data->pParams->uiOutWidth; i++) {
                        if (!data->pParams->ucRawMode) {
                            if (data->pParams->OutputIntrlvSel) {
                                // IR and BG interleave
                                if (i & 1) {

        				            data->punBG[(j >> 1)*uiProcWidth + i - 1] = punInputBuffer[j*data->pParams->uiOutWidth + i];
        				            data->punBG[(j >> 1)*uiProcWidth + i] = punInputBuffer[j*data->pParams->uiOutWidth + i];
                                }
                                else {
				                    data->punIR[(j >> 1)*uiProcWidth + i] = punInputBuffer[j*data->pParams->uiOutWidth + i];
				                    data->punIR[(j >> 1)*uiProcWidth + i + 1] = punInputBuffer[j*data->pParams->uiOutWidth + i];
                                }
                            }
                            else {
				                data->punIR[(j >> 1)*uiProcWidth + i] = punInputBuffer[j*data->pParams->uiOutWidth + i];
                            }
                        }
                        else {
				            data->punS1[(j >> 1)*uiProcWidth + i] = (punInputBuffer[j*data->pParams->uiOutWidth + i] << 2) | 3;
                        }
			        }
                }
                else {
                    // Depth Lines
			        for(uint32 i=0; i<data->pParams->uiOutWidth; i++) {
                        if (data->bDepthIRMode) {
				                data->punDepth[(j >> 1)*uiProcWidth + i] = punInputBuffer[j*data->pParams->uiOutWidth + i];
                        }
                        else {
				            data->punS0[(j >> 1)*uiProcWidth + i] = (punInputBuffer[j*data->pParams->uiOutWidth + i] << 2) | 3;
                        }
			        }
                }
		    }
#else
            // For ADDI9033 check for how data is being output and copy to buffers accordingly
		    for(uint32 j=0; j<data->pParams->uiOutHeight * 2; j++) {
                if (j & 1) {
                    // IR Lines
			        for(uint32 i=0; i<data->pParams->uiOutWidth; i++) {
                        if (data->bDepthIRMode) {
                            if (data->pParams->OutputIntrlvSel) {
                                // IR and BG interleave
                                if (i & 1) {
        				            data->punBG[(j >> 1)*uiProcWidth + i - 1] = data->mInputFrameY16->at<ushort>(j, i);
        				            data->punBG[(j >> 1)*uiProcWidth + i] = data->mInputFrameY16->at<ushort>(j, i);
                                }
                                else {
				                    data->punIR[(j >> 1)*uiProcWidth + i] = data->mInputFrameY16->at<ushort>(j, i);
				                    data->punIR[(j >> 1)*uiProcWidth + i + 1] = data->mInputFrameY16->at<ushort>(j, i);
                                }
                            }
                            else {
				                data->punIR[(j >> 1)*uiProcWidth + i] = data->mInputFrameY16->at<ushort>(j, i);
                            }
                        }
                        else {
				            data->punS1[(j >> 1)*uiProcWidth + i] = (data->mInputFrameY16->at<ushort>(j, i) << 2) | 3;
                        }
			        }
                }
                else {
                    // Depth Lines
			        for(uint32 i=0; i<data->pParams->uiOutWidth; i++) {
                        if (data->bDepthIRMode) {              
				                punDepth[(j >> 1)*uiProcWidth + i] = data->mInputFrameY16->at<ushort>(j, i);
                        }
                        else {
				            punS0[(j >> 1)*uiProcWidth + i] = (data->mInputFrameY16->at<ushort>(j, i) << 2) | 3;
                        }
			        }
                }
		    }
#endif
        }
#ifndef OPENCV
		free(punInputBuffer);
		punInputBuffer = NULL;
#endif
		if(data->pParams->eAfePart == AFE_ADDI9033 && !data->pParams->ucRawMode && data->bDepthIRMode)
		{
			data->pDepthCorrect->setInPtrs(data->punS0, data->punS1, data->punBG, data->punDepth);
			data->pDepthCorrect->setDepthOutPtr(data->punDepth);
			data->pDepthCorrect->Depth2MM();
		}
		DispCpy(data->punDepth, data->punDepth, data->pParams);
		DispCpy(data->punIR, data->punIR, data->pParams);
		DispCpy(data->punBG, data->punBG, data->pParams);

		DispCpy(data->punS0, data->punS0, data->pParams);
		DispCpy(data->punS1, data->punS1, data->pParams);
		

		punS0 = data->punS0;
		punS1 = data->punS1;
		punS2 = data->punBG;
		punDepth = data->punDepth;
		punIR = data->punIR;
		width = 640;
		height = 480;

	#ifdef RAW_OUT
		punRaw=data->punRawData;
		rawHeight=uiInHeight;
		rawWidth=uiInWidth;
	#endif
		return 0;
}

int ADI_TOF::preProcFrame(uint16 *punRawIn)
{	
	if (data->pParams->eAfePart == AFE_ADDI9033 && !data->pParams->ucRawMode) {
        // Skip if 9033 but no raw mode
        return -2;
    }

	return 0;
}

int ADI_TOF::depthProcFrame(uint16* S0, uint16* S1)
{

	return 0;
}

int ADI_TOF::postProcFrame()
{
	if (data->pParams->eAfePart == AFE_ADDI9033 && !data->pParams->ucRawMode) {
        // Skip if 9033 but no raw mode
        return -2;
    }

	return 0;
}

int ADI_TOF::ProcFrame(uint16 *punRawIn)
{
	static int processFrame=0;
	
	while(processFrame==1)
	{
		cout<<"Previous frame processing\n";
	}
	processFrame=1;
	errcode_t ec = EC_OK;
	

	rawProcFrame(punRawIn);

	uint32 uiFirstPass = 1;
    //if (data->pParams->eAfePart == AFE_ADDI9030 || data->pParams->ucRawMode) {
		preProcFrame(punRawIn);

		depthProcFrame(); //Get Depth/IR image

		postProcFrame();
    //}
	
	processFrame=0;
	return 0;
}

void ADI_TOF::Data::initDepthRange(range value, uint16 level)
{
	char fileName[50];
	pParams->DepthCnvGain = 0;
	pParams->ucM3WSel = 0;
	pParams->eDepthRange=(depth_range_e)value;
	if (pParams->eImgSensorType <= VGA_V3) {
		switch (pParams->eDepthRange) {
		case DEPTH_RANGE_NEAR:
			if(level==0)
				sprintf(fileName,"LinearCorrectVGANear.ini");
			else
				sprintf(fileName,"LinearCorrectVGANear%d.ini",level);
			pParams->ParamInit(fileName);
			//data->pParams->ParamInit("LinearCorrectVGANear.ini");
			pParams->ucDepthMode = 0;
			break;
		case DEPTH_RANGE_XNEAR:
			if(level==0)
				sprintf(fileName,"LinearCorrectVGAXNear.ini");
			else
				sprintf(fileName,"LinearCorrectVGAXNear%d.ini",level);
			pParams->ParamInit(fileName);
			pParams->ucDepthMode = 0;
			break;
		case DEPTH_RANGE_MID:
			if(level==0)
				sprintf(fileName,"LinearCorrectVGAMid.ini");
			else
				sprintf(fileName,"LinearCorrectVGAMid%d.ini",level);
			pParams->ParamInit(fileName);
			//data->pParams->ParamInit("LinearCorrectVGAMid.ini");
			 if (pParams->eAfePart == AFE_ADDI9030) {
    			pParams->ucDepthMode = 1;
            }
            else {
                // The ADDI9033 uses near mode timing with method 3W and therefore needs depth calc method 0
                pParams->ucDepthMode = 0;
                pParams->ucM3WSel = 1;
                pIsaTg->setMethod3WEnable(true);
            }
			break;
		case DEPTH_RANGE_FAR:
		case DEPTH_RANGE_XFAR:
			if(level==0)
				sprintf(fileName,"LinearCorrectVGAFar.ini");
			else
				sprintf(fileName,"LinearCorrectVGAFar%d.ini",level);
			pParams->ParamInit(fileName);
			//data->pParams->ParamInit("LinearCorrectVGAFar.ini");
			pParams->ucDepthMode = 1;
			break;
		}
	}
	else {
		switch (pParams->eDepthRange) {
		case DEPTH_RANGE_NEAR:
			pParams->ParamInit("LinearCorrectSXGANear.ini");
			pParams->ucDepthMode = 0;
			break;
		case DEPTH_RANGE_MID:
			pParams->ParamInit("LinearCorrectSXGAMid.ini");
			pParams->ucDepthMode = 1;
			break;
		case DEPTH_RANGE_FAR:
		case DEPTH_RANGE_XFAR:
			pParams->ParamInit("LinearCorrectSXGAFar.ini");
			pParams->ucDepthMode = 1;
			break;
		}
	}
	// If the conversion gain is still 1, that means the .ini file
    // is an old version and the conversion gain is missing.  In that 
    // case, we will initialize if from the calibration slope values.
    if (pParams->DepthCnvGain == 0) {
		switch (pParams->eDepthRange) {
		case DEPTH_RANGE_NEAR:
            pParams->DepthCnvGain = 10/CAL_NEAR_CODE_SLOPE;
			break;
		case DEPTH_RANGE_XNEAR:
            if (pParams->eAfePart == AFE_ADDI9030) {
                pParams->DepthCnvGain = 10/CAL_XNEAR_CODE_SLOPE;
            }
            else {
                pParams->DepthCnvGain = 10/CAL_XNEAR_ADDI9033_CODE_SLOPE;
            }
			break;
		case DEPTH_RANGE_MID:
            pParams->DepthCnvGain = 10/CAL_MID_CODE_SLOPE;
			break;
		case DEPTH_RANGE_FAR:
		case DEPTH_RANGE_XFAR:
            pParams->DepthCnvGain = 10/CAL_FAR_CODE_SLOPE;
			break;
		}
    }
}

void ADI_TOF::setDepthRange(range value, uint16 level)
{
	if(data->bMR)
		setMultiRange(false);

    if(getCancellationStatus() != DISABLE_CANCELLATION)
    {
        data->pParams->ucGridVGASel = 0;
        data->pIsaTg->setCancellation((cancellationPatternNum)DISABLE_CANCELLATION);
    }

	range oldValue=getDepthRange();

	data->initDepthRange(value, level);
	data->oldLevel = level;
	
	if(oldValue!=value)
	{
		//printf("Setting New Depth Range to value=%d\n",value);
        data->pIsaTg->setLaserEnaReg(data->pParams->unLaserEnaReg);
        //Temporary, HPTLaserEneble gets set here
        data->pIsaTg->getLaserEnaCode();
        data->pIsaTg->setPulseCnt(data->pParams->unLDPulseCnt);
		data->pIsaTg->setDepthRange((depth_range_e)value);
        data->pCodeBlk = data->pIsaTg->getBaseCode(data->pParams);
        data->pIsaTg->wrToFIPToFile("12_TOF_ProcCtrl.lf");
		data->pSpiXfer->SpiWrSlow(data->pCodeBlk);

        setPulseCount(data->pParams->unLDPulseCnt);
	}
	else
	{
		//cout<<"Setting pulse count value\n";
		setPulseCount(data->pParams->unLDPulseCnt);
	}
}

range ADI_TOF::getDepthRange()
{
	return((range)data->pIsaTg->getDepthRange());
}

void ADI_TOF::setPulseCount(uint16 value)
{
	/*
	value=value<1?1:value;
	value=value>4000?4000:value;
	data->pIsaTg->setPulseCnt(value);
	data->pCodeBlk = data->pIsaTg->getBaseCode();
	data->pSpiXfer->SpiWrSlow(data->pCodeBlk);*/

    data->pIsaTg->setPulseCnt(value);
	isa_code_block_t *pCodeBlk = data->pIsaTg->getPulseCntCode();
    data->pParams->unLDPulseCnt = data->pIsaTg->getPulseCnt();
	data->pSpiXfer->SpiWrFast(pCodeBlk);
}

uint16 ADI_TOF::getPulseCount()
{
	return(data->pIsaTg->getPulseCnt());
}

void ADI_TOF::getCameraIntrinsic(float **pfIntrinsics, double **pDistortionCoeff)
{
	*pfIntrinsics = data->pParams->fIntrinsic;
	*pDistortionCoeff = data->pParams->dDistortionCoeff;
}

void ADI_TOF::setCancellation(cancellationPattern cCancellationNum, bool activate)
{
	if(data->bMR)
		setMultiRange(false);
    if(cCancellationNum != getCancellationStatus())
    {
        if(data->pParams->eAfePart == AFE_ADDI9033 && data->pParams->ucRawMode == 0)
        {
            return;
        }

        if(cCancellationNum >= 2)
            return;

        if(getCancellationStatus() != DISABLE_CANCELLATION && cCancellationNum == DISABLE_CANCELLATION)
        {
            data->pParams->ucGridVGASel = 0;
            this->setDepthRange((range)data->oldRange,data->oldLevel);
        }
        else
        {
            data->oldRange = data->pParams->eDepthRange;
            data->initDepthRange(NEAR_RANGE,0);
            data->pIsaTg->setPulseCnt(data->pParams->unLDPulseCnt);
            data->pParams->unLDPulseCnt = data->pIsaTg->getPulseCnt();
            data->pIsaTg->setDepthRange((depth_range_e)NEAR_RANGE);
        }
        data->pIsaTg->setCancellation((cancellationPatternNum)cCancellationNum);
        data->pCodeBlk = data->pIsaTg->getBaseCode();
        data->pSpiXfer->SpiWrSlow(data->pCodeBlk);
    }
    this->activateCancellation(activate);
}

void ADI_TOF::activateCancellation(bool activate)
{
    if(getCancellationStatus() != DISABLE_CANCELLATION)
    {
        if(activate)
            data->pParams->ucGridVGASel = 2;
        else
            data->pParams->ucGridVGASel = 3;
    }
}

// setMulitRange - This function enables or disables the multirange feature
void ADI_TOF::setMultiRange(bool bMR)
{
    char filename[50];

	//Needs to be changed when we timing for multirange supports Cancellation
	if((cancellationPattern)data->pIsaTg->getCancellation() != DISABLE_CANCELLATION)
	{
		setCancellation(DISABLE_CANCELLATION);
	}

    if (data->bMR == bMR) {
        // No change, nothing to do
        return;
    }

    data->bMR = bMR;
	
    if (bMR) {
        // IF enabling, initialize the multirange tables
        isa_mr_pattern_t *Pat = data->pCalTbl->Init();
		if(Pat == NULL)
		{
			bMR = false;
			return;
		}

        int iNumLvls = data->pCalTbl->getNumLevels();

        // Format the ISATG code for download
        data->pIsaTg->setMultRangePattern(Pat, iNumLvls);

        // Since we have a separate set of loadfiles for multirange
        // we need to load the full set of code.
        data->pSpiXfer->SpiWrSlow(data->pIsaTg->getBaseCode());
        // Overwrite the multirange table with the new settings 
        data->pSpiXfer->SpiWrFast(data->pIsaTg->getMultiRangeCode());
    }
    else {
        // If disabling, Null out the multirange table
        data->pIsaTg->setMultRangePattern(NULL, 0);
        // Since we have separate mulitrange loadfiles, we need to reload the normal ones
        data->pSpiXfer->SpiWrSlow(data->pIsaTg->getBaseCode());
    }
}

void ADI_TOF::getMultiRange(int *uiIndex, int *pulseCnt, int *depthRange)
{
    if(uiIndex == NULL)
        return;
    else
        *uiIndex = data->pCalTbl->getLevel();

    if(pulseCnt == NULL)
        return;
    else
        *pulseCnt = data->pCalTbl->getPulseCnt(*uiIndex);

    if(depthRange == NULL)
        return;
    else
        *depthRange = data->pCalTbl->getMode(*uiIndex);
}

cancellationPattern ADI_TOF::getCancellationStatus(void)
{
	return (cancellationPattern)data->pIsaTg->getCancellation();
}


void ADI_TOF::programAFE(uint16 *punAddr,uint16 *punData, uint16 noOfEntries)
{
	isa_code_entry_t *codeEntry=new isa_code_entry_t [noOfEntries];
	isa_code_block_t codeBlk;

	for(int i=0;i<noOfEntries;i++)
	{
		codeEntry[i].data =	punData[i];
		codeEntry[i].addr = punAddr[i];
	}
	codeBlk.iLength = noOfEntries;
	data->pSpiXfer->SpiWrSlow(&codeBlk);
}

