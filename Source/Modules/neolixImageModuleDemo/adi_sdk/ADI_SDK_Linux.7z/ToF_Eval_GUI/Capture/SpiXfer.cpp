/********************************************************************************/
/*																				*/
/* @file	SpiXfer.cpp															*/
/*																				*/
/* @brief	Programs the AFE													*/
/*																				*/																				
/* @author	Dhruvesh Gajaria													*/
/*																				*/
/* @date	October 15, 2015													*/
/*																				*/
/* Copyright(c) Analog Devices, Inc.											*/
/*																				*/
/********************************************************************************/
#include <stdafx.h>
#include "SpiXfer.h"

using namespace std;

#pragma comment(lib, "strmiids")

SpiXfer::SpiXfer()
{
	bXferInProgress = false;
}

#ifndef OPENCV
void SpiXfer::spiInit(Device *dev, xferT xferType)
{
    this->dev=dev;
    this->xferType=xferType;
}
#else
void SpiXfer::spiInit(cv::VideoCapture *cvCap, xferT xferType)
{
	this->cvCap=cvCap;
	this->xferType=xferType;
}
#endif

bool SpiXfer::SpiWrSlow(isa_code_block_t *pCodeBlk)
{

#ifdef DISABLE_REG_WRITES //PLG
	if(pCodeBlk->iLength<50)
	{
		return false;
	}
#endif
    //printf("SPI/I2C write called\n");

	while (bXferInProgress);
	bXferInProgress = true;
	bool status=true;
	
	if(xferType==UVC)
	{
		FILE *fp = NULL;

		fp = fopen( "afe_firmware.bin","wb");
		if (fp) 
		{
			fwrite(pCodeBlk->pCode,sizeof(isa_code_entry_t),pCodeBlk->iLength,fp);
			fclose(fp);

#ifndef OPENCV
			status = dev->program();
			int counter=0;
			while(status!=true&&counter<4)
			{

				status = dev->program();
				counter++;
				printf("\nUVC Transfer Failed : Reprograming Attempt %d\n",counter);
                //Sleep(1);
			}
#else
			status=cvCap->set(CV_CAP_PROP_FPGA_PROGRAM, 140);
			int counter=0;
            while(status!=true&&counter<4)
			{
				status=cvCap->set(CV_CAP_PROP_FPGA_PROGRAM, 140);
				counter++;
				printf("\nUVC Transfer Failed : Reprograming Attempt %d\n",counter);
				Sleep(1);
			}
#endif
		}           
	}
#ifndef Linux
	else
	{
		unsigned char location[4];
		CCyBulkEndPoint *BulkInEpt = NULL;
		CCyBulkEndPoint *BulkOutEpt = NULL;
		CCyFX3Device *USBDevice = new CCyFX3Device();
		int eptCount = USBDevice->EndPointCount();
		isa_code_entry_t *pCodeIt = pCodeBlk->pCode;
		int iLen = pCodeBlk->iLength;

		if (eptCount) {
			for (int i=0; i<eptCount; i++) {
				bool bIn = (USBDevice->EndPoints[i]->Address == 0x84);
				bool bBulk = (USBDevice->EndPoints[i]->Attributes == 2);
				if (bBulk && bIn) {
					BulkInEpt = (CCyBulkEndPoint *) USBDevice->EndPoints[i];
				}
				if (bBulk && (USBDevice->EndPoints[i]->Address == 0x04)) {
					BulkOutEpt = (CCyBulkEndPoint *) USBDevice->EndPoints[i];
				}
			}

			if (BulkOutEpt) {
				for (int i=0; (i < iLen) && (status == true); i++) {
					long buflen = 4;
					location[0] = pCodeIt->addr & 0xFF;
					location[1] = (pCodeIt->addr & 0xFF00) >> 8;
					location[2] = pCodeIt->data & 0xFF;
					location[3] = (pCodeIt->data & 0xFF00) >> 8;
					status=BulkOutEpt->XferData(location, buflen);
			
					for (int j=0; (j < SPIXFER_MAX_ERR_CNT) && (status == false); j++) {
						buflen = 4;
						status = BulkOutEpt->XferData(location, buflen);
					}
					//printf("Slow: %4.4X %4.4X\n", pCodeIt->addr, pCodeIt->data);
					pCodeIt++;
				}
			}
			else {
				status = false;
			}
		}
		USBDevice->Close();
		free(USBDevice);
	}
#endif
	bXferInProgress = false;
	return (true);
}

bool SpiXfer::SpiWrFast(isa_code_block_t *pCodeBlk)
{

#ifdef DISABLE_REG_WRITES //PLG
	if(pCodeBlk->iLength<50)
	{
		return false;
	}
#endif
    //printf("SPI/I2C write called\n");

	while (bXferInProgress);
	bXferInProgress = true;
	bool status=true;
	
	if(xferType==UVC)
	{
		FILE *fp = NULL;

		fp = fopen( "afe_firmware.bin","wb");
		if (fp) 
		{
			fwrite(pCodeBlk->pCode,sizeof(isa_code_entry_t),pCodeBlk->iLength,fp);
			fclose(fp);

#ifndef OPENCV
			status =  dev->program();
			int counter=0;
			while(status!=true&&counter<4)
			{

				status = dev->program();
				counter++;
				printf("\nUVC Transfer Failed : Reprograming Attempt %d\n",counter);
                //Sleep(1);
			}
#else
			status=cvCap->set(CV_CAP_PROP_FPGA_PROGRAM, 140);
			int counter=0;
			while(status!=true&&counter<4)
			{
				status=cvCap->set(CV_CAP_PROP_FPGA_PROGRAM, 140);
				counter++;
				printf("\nUVC Transfer Failed : Reprograming Attempt %d\n",counter);
				Sleep(1);
			}
#endif
		}           
	}
#ifndef Linux
	else
	{
		isa_code_entry_t *pCodeIt = pCodeBlk->pCode;
		int iLen = pCodeBlk->iLength;
		

		for (int i=0; (i<iLen) && (status == true); i++) {
			CCyControlEndPoint *ControlEpt = NULL;
			CCyUSBDevice *USBDevice = new CCyUSBDevice(NULL);
			int eptCount = USBDevice->EndPointCount();

			if(eptCount) {
				for (int j=0; j<eptCount; j++) {
					if (USBDevice->EndPoints[j]->Address == 0x00) {
						ControlEpt = (CCyControlEndPoint *) USBDevice->EndPoints[j];
					}
				}

				if (ControlEpt == NULL) {
					status = false;
				}
				else {
					ControlEpt->Target = TGT_DEVICE;
					ControlEpt->ReqType = REQ_VENDOR;
					ControlEpt->ReqCode = 0xC2;
					ControlEpt->Value = 2;
					ControlEpt->Index = 0;

					byte buf[4];
					long len = 4;
					buf[0] = pCodeIt->addr & 0xFF;
					buf[1] = (pCodeIt->addr & 0xFF00) >> 8;
					buf[2] = pCodeIt->data & 0xFF;
					buf[3] = (pCodeIt->data & 0xFF00) >> 8;
					status = ControlEpt->Write(buf, len);

					for (int j = 0; (j < SPIXFER_MAX_ERR_CNT) && (status == false); j++) {
						status = true;
						status = ControlEpt->Write(buf, len);
					}
					//printf("Fast: %4.4X %4.4X\n", pCodeIt->addr, pCodeIt->data);
					pCodeIt++;
				}
			}
			else {
				status = false;
			}
			free(USBDevice);
		}
	}
#endif
	bXferInProgress = false;
	return status;
}

#ifndef Linux
int SpiXfer::getDeviceId(img_sensor_e eSensorType) {
	int deviceID = 0;

	// Create the System Device Enumerator.
	ICreateDevEnum *pSysDevEnum = NULL;

	HRESULT hr = CoInitializeEx(NULL, COINIT_MULTITHREADED);

	hr = CoCreateInstance(CLSID_SystemDeviceEnum, NULL, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&pSysDevEnum));
	if (FAILED(hr))	{
			cout << "Create Device Enumeration Failed" << endl;
			//pSysDevEnum->Release();
			return -1;
	}

	// Obtain a class enumerator for the video compressor category.
	IEnumMoniker *pEnumCat = NULL;
	hr = pSysDevEnum->CreateClassEnumerator(CLSID_VideoInputDeviceCategory, &pEnumCat, 0);
		
	if (hr == S_OK) {
		// Enumerate the monikers.
		IMoniker *pMoniker = NULL;
		ULONG cFetched;
	
		while(pEnumCat->Next(1, &pMoniker, &cFetched) == S_OK) {
			IPropertyBag *pPropBag;
			hr = pMoniker->BindToStorage(0, 0, IID_PPV_ARGS(&pPropBag));
		
			if (SUCCEEDED(hr)) {
				// To retrieve the filter's friendly name, do the following:
				VARIANT varName;
				VariantInit(&varName);
				hr = pPropBag->Read(L"FriendlyName", &varName, 0);
			
				if (SUCCEEDED(hr)) {
					char newstr[80];
					sprintf_s(newstr, "%S", varName.bstrVal);
					if (eSensorType == SXGA_V1 || eSensorType == SXGA_V2 || eSensorType == SXGA_V3) {
						if(strcmp(newstr, "ADI TOF DEPTH SENSOR") == 0) {
							//cout << newstr;
							VariantClear(&varName);
							pPropBag->Release();
							pMoniker->Release();
							pEnumCat->Release();
							pSysDevEnum->Release();
							return deviceID;
						}
					}
					else {
						if(strcmp(newstr, "ADI TOF DEPTH SENSOR") == 0) {
						//if (strcmp(newstr, "e-con's CX3 RDK with OV5640") == 0)	{
							//cout << newstr;
							VariantClear(&varName);
							pPropBag->Release();
							pMoniker->Release();
							pEnumCat->Release();
							pSysDevEnum->Release();
							return deviceID;
						}
					}
				}
				VariantClear(&varName);

				pPropBag->Release();
			}
			pMoniker->Release();
			deviceID++;
		}
		pEnumCat->Release();
		pSysDevEnum->Release();
		return -1;
	}
	else
	{
		return -1;
		pSysDevEnum->Release();
	}
}
#endif
