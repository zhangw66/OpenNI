/********************************************************************************/
/*																				*/
/* @file	ISATG.cpp															*/
/*																				*/
/* @brief	Reads ISATG Code from files											*/
/*																				*/
/*																				*/
/* @author	Dhruvesh Gajaria													*/
/*																				*/
/* @date	December 15, 2016													*/
/*																				*/
/* Copyright(c) Analog Devices, Inc.											*/
/*																				*/
/********************************************************************************/

#include <stdafx.h>
#include "Param.h"
#include "IsaTg.h"
#include<iostream>

#ifdef Linux
#include<dirent.h>
#endif

using namespace std;

IsaTg::IsaTg(void)
{
	eSensorType = NO_SENSOR;
	eDepthRange = DEPTH_RANGE_NEAR;
    // Assume ADDI9030
    eAfePart = AFE_ADDI9030;
    unLaserEnaReg = ISATG_ADDI9030_SUB_BIT | ISATG_LD_ALL;
    bWDREnable = false;
    bM3WEnabled = false;
    bDepthIRMode = true;
    bRawMode = false;
    bToFLoadFile12 = false;
    bTalEnable = true;

	icCodeBlock.iLength = 0;
	icCodeBlock.pCode = NULL;

    icSweepCode.iLength = 0;
	icSweepCode.pCode = NULL;

    icPulseCntCode.iLength = 0;
    icPulseCntCode.pCode = NULL;
	unPulseCnt = 4000;
	cPulseTiming = 0;

    icHPTStdbyCode.iLength = 0;
    icHPTStdbyCode.pCode = NULL;
    icHPTIsaCode.iLength = 0;
    icHPTIsaCode.pCode = NULL;

    icHPTBlkEna.iLength = 2;
    icHPTBlkEna.pCode = pHPTBlkEna;
    pHPTBlkEna[0].addr = ISATG_HPT_POS_BLK_ADDR;
    pHPTBlkEna[0].data = this->unLaserEnaReg;
    pHPTBlkEna[1].addr = ISATG_HPT_NEG_BLK_ADDR;
    pHPTBlkEna[1].data = this->unLaserEnaReg;

    icTALEnable.iLength = 2;
    icTALEnable.pCode = pTALCode;
    pTALCode[0].addr = ISATG_ADDI9033_TAL_PH_CMP_EN_ADDR;
    pTALCode[0].data = 0;
    pTALCode[1].addr = ISATG_ADDI9033_TAL_EDGE_EN_ADDR;
    pTALCode[1].data = 0;

    icToFIPCode.iLength = sizeof(tof_ip_regs_t)/sizeof(isa_code_entry_t);
    icToFIPCode.pCode = (isa_code_entry_t *) &ToFIPRegs;
    ToFIPInitAddrs();

    icMultiRangeCode.iLength = sizeof(isa_mr_tbl_t) / sizeof(isa_code_entry_t);
    icMultiRangeCode.pCode = (isa_code_entry_t *) &imMultRangeTbl;

    char filename[128];
    findLoadFile(filename, 6, "./IsaTgCode/VGAv3/MultiRange/");
    isa_code_block_t tmpCodeBlk = { 0, 0 };

    parseCode(filename, &tmpCodeBlk);
    uint16 addr = findCodeBlockData(&tmpCodeBlk, ISATG_MULTIRANGE_TBL_ADDR);
    addr += 0x4000;
    if (tmpCodeBlk.pCode) {
        free(tmpCodeBlk.pCode);
    }

    // Set multirange to disabled and initialize all the addresses
    bMultiRange = false;
    imMultRangeTbl.NumLvls.addr = addr++;
    for (int i = 0; i < ISATG_MAX_PATTERN; i++) {
        imMultRangeTbl.Entry[i].PulseCnt.addr = addr++;
        imMultRangeTbl.Entry[i].NumFrames.addr = addr++;
        imMultRangeTbl.Entry[i].Stdby.addr = addr++;
        imMultRangeTbl.Entry[i].Mode.addr = addr++;
    }

    icTmpCode.pCode = NULL;
    icTmpCode.iLength = 0;

	//Interference Cancellation
	cCancellation = -1;
}

IsaTg::~IsaTg()
{
	if (icCodeBlock.pCode) {
		free(icCodeBlock.pCode);
	}

	if (icSweepCode.pCode) {
		free(icSweepCode.pCode);
	}

	if (icHPTStdbyCode.pCode) {
		free(icHPTStdbyCode.pCode);
	}

	if (icHPTIsaCode.pCode) {
		free(icHPTIsaCode.pCode);
	}

    if (icTmpCode.pCode) {
        free(icTmpCode.pCode);
    }

}

void IsaTg::setAfePart(afe_part_e eAfePart) 
{ 
    this->eAfePart = eAfePart; 

    this->unLaserEnaReg &= 0x0F;
    if (eAfePart == AFE_ADDI9030) {
        this->unLaserEnaReg |= ISATG_ADDI9030_SUB_BIT;
    }
    else {
        this->unLaserEnaReg |= ISATG_ADDI9033_SUB_BIT;
    }

    pHPTBlkEna[0].data = this->unLaserEnaReg;
    pHPTBlkEna[1].data = this->unLaserEnaReg;
}

void IsaTg::findLoadFile(char *filename, int number, char *path)
{
#ifndef Linux
	WIN32_FIND_DATAA FindFileData;
	// Open directory
	sprintf(filename, "%s%d_*.lf", path, number);
	HANDLE hFind = FindFirstFileA(filename, &FindFileData);

	FindNextFileA(hFind, &FindFileData);
	FindClose(hFind);
	sprintf(filename, "%s%s", path, FindFileData.cFileName);
#else
    DIR *d;
    struct dirent *dir;
    char pathTmp[100];
    sprintf(pathTmp,"./%s",path);
    d = opendir(pathTmp);
    if(d)
    {
        char sset[4];
        sprintf(sset,"%d_", number);
        while((dir=readdir(d))!=NULL)
        {
                //printf("Directory name=\n%s\n", dir->d_name);
                //cout<<dir->d_name<<endl;
                //int i=strspn(sset,(dir->d_name));
                //cout<<"i="<<i<<endl;
                if(strncmp(sset,dir->d_name,2)==0)
                sprintf(filename, "%s%s", pathTmp, dir->d_name);
        }
    }
    closedir(d);
#endif
}


void IsaTg::getModePath(char *path)
{
    if (eAfePart == AFE_ADDI9033) {
	    switch (eSensorType) {
	    case NO_SENSOR:
		    return;
	    case VGA_V1:
	    case VGA_V2:
            strcpy(path, "./IsaTgCode/VGAv2/ADDI9033/");
		    break;
	    case VGA_V3:
            if(cCancellation >= CANCEL_INTERFERNCE_CAM0){
                sprintf(path, "./IsaTgCode/VGAv3/ADDI9033/Mode0_Interference_Cam%d/", cCancellation);
            }
            else{
                strcpy(path, "./IsaTgCode/VGAv3/ADDI9033/");
            }
		    break;
	    case SXGA_V1:
	    case SXGA_V2:
	    case SXGA_V3:
            strcpy(path, "./IsaTgCode/SXGA/ADDI9033/");
		    break;
	    }
    }
    else
    {
	    switch (eSensorType) {
	    case NO_SENSOR:
		    return;
	    case VGA_V1:
	    case VGA_V2:
            strcpy(path, "./IsaTgCode/VGAv2/Mode0_Near/");
		    break;
	    case VGA_V3:

            if (!bWDREnable) 
            {
                if(cCancellation >= CANCEL_INTERFERNCE_CAM0){
                    sprintf(path, "./IsaTgCode/VGAv3/Mode0_Interference_Cam%d/", cCancellation);
				}
				else{
#ifndef TIMING_5_METER
					strcpy(path, "./IsaTgCode/VGAv3/Mode0_Near/");
#else
					strcpy(path, "./IsaTgCode/VGAv3/5Meter_Timing/");
#endif
				}
            }
            else {
                strcpy(path, "./IsaTgCode/VGAv3/WDR/");
            }
		    break;
	    case SXGA_V1:
	    case SXGA_V2:
	    case SXGA_V3:
            strcpy(path, "./IsaTgCode/SXGA/Mode0_Near/");
		    break;
	    }

        if (bMultiRange) {
            strcpy(path, "./IsaTgCode/VGAv3/MultiRange/");
        }
    }
}

void IsaTg::parseDir(char *path, isa_code_block_t *pCodeBlk, bool bCal)
{
	char filename[128];

    if (pCodeBlk->pCode) {
        free(pCodeBlk->pCode);
        pCodeBlk->pCode = NULL;
	    pCodeBlk->iLength = 0;
    }

    isa_code_block_t tmpCodeBlk;
	tmpCodeBlk.pCode = NULL;
	tmpCodeBlk.iLength = 0;

	for (int i=1; i<=13; i++) {
        findLoadFile(filename, i, path);

        // load the next block of code
        if (eAfePart == AFE_ADDI9033 && i == 12 && !bToFLoadFile12) {
            // Replace ToF processor code with local settings
            tmpCodeBlk.iLength = icToFIPCode.iLength;
        	tmpCodeBlk.pCode = (isa_code_entry_t *) malloc(icToFIPCode.iLength*sizeof(isa_code_entry_t));
            memcpy(tmpCodeBlk.pCode, icToFIPCode.pCode, icToFIPCode.iLength * sizeof(isa_code_entry_t));
        }
        else {
		    parseCode(filename, &tmpCodeBlk);
        }

        if (tmpCodeBlk.pCode == NULL) {
			break;
		}

        // #2 holds HPT timing registers
		if (i == 2) {
            if (icHPTStdbyCode.pCode) {
                // If there are HTP values from the UI, then replace
                for (int k=0; k<icHPTStdbyCode.iLength; k++) {
                    replaceCodeBlockData(&tmpCodeBlk, icHPTStdbyCode.pCode[k].addr, icHPTStdbyCode.pCode[k].data);
                }
			}

            if ((eDepthRange == DEPTH_RANGE_XNEAR) && !bCal) {
			    // Set the mode value based on depth range
                int idx = 0;
                replaceCodeBlockData(&tmpCodeBlk, ISATG_HPT_ENA_ADDR, 0x0002);
            }

#ifdef ELSA_TIMING
            if ((eAfePart == AFE_ADDI9030) && (eDepthRange == DEPTH_RANGE_NEAR || bMultiRange) && !bCal && (cCancellation == CANCELLATION_DISABLE)) {
			    // Special LD timing for Elsa using narrow LD pulse
                replaceCodeBlockData(&tmpCodeBlk, ISATG_HPT_LD1_POS_ADDR, 0x007F);
                replaceCodeBlockData(&tmpCodeBlk, ISATG_HPT_LD1_NEG_ADDR, 0x005A);
                replaceCodeBlockData(&tmpCodeBlk, ISATG_HPT_LD2_POS_ADDR, 0x007F);
                replaceCodeBlockData(&tmpCodeBlk, ISATG_HPT_LD2_NEG_ADDR, 0x005A);
                replaceCodeBlockData(&tmpCodeBlk, ISATG_HPT_LD3_POS_ADDR, 0x007F);
                replaceCodeBlockData(&tmpCodeBlk, ISATG_HPT_LD3_NEG_ADDR, 0x005A);
                replaceCodeBlockData(&tmpCodeBlk, ISATG_HPT_LD4_POS_ADDR, 0x007F);
                replaceCodeBlockData(&tmpCodeBlk, ISATG_HPT_LD4_NEG_ADDR, 0x005A);
            }
#endif

        }


		if (i == 5) {
            if (icHPTIsaCode.pCode) {
                // If there are HTP values from the UI, then replace
                for (int k=0; k<icHPTIsaCode.iLength; k++) {
                    replaceCodeBlockData(&tmpCodeBlk, icHPTIsaCode.pCode[k].addr, icHPTIsaCode.pCode[k].data);
                }
                replaceCodeBlockData(&tmpCodeBlk, ISATG_HPT_ENA_ADDR, 0x0002);
			}
        }

        if (i == 6 && eAfePart == AFE_ADDI9033) {
            // Enable/disable TAL
            replaceCodeBlockData(&tmpCodeBlk,  pTALCode[0].addr, pTALCode[0].data);
            replaceCodeBlockData(&tmpCodeBlk,  pTALCode[1].addr, pTALCode[1].data);
        }

        if( i == 8 && (cCancellation != CANCELLATION_DISABLE))
        {
            for (int k=0; k<tmpCodeBlk.iLength; k++) {
                if(tmpCodeBlk.pCode[k].data == 0x003c)
                {
                    //cout<<"ISATG unpulsecnt ="<<unPulseCnt<<endl;
                    tmpCodeBlk.pCode[k].data = (((double)unPulseCnt/36) +  0.5);
                    this->unPulseCnt = tmpCodeBlk.pCode[k].data * 36;
                }
            }
        }


         //File #9 holds LD and Sub pulse timing
        if (i == 9 && !bWDREnable &&  (cCancellation == CANCELLATION_DISABLE)) {
			// Replace the default value of 0x0FA0 (4000) with the currently selected value
			for (int k=0; k<tmpCodeBlk.iLength; k++) {
				
				if( tmpCodeBlk.pCode[k].data != 142) // 60 FPS support
				{
					tmpCodeBlk.pCode[k].data = unPulseCnt;
				}
			}
		}

		// File #10 holds the mode register
		if (i == 10) {
			// Set the mode value based on depth range

            uint16 data;
            if (eAfePart == AFE_ADDI9030) {
                switch (eDepthRange) {
                    case DEPTH_RANGE_NEAR:
        		        data = ISATG_MODE_NEAR;
                        break;
                    case DEPTH_RANGE_XNEAR:
        		        data = ISATG_MODE_NEAR;
                        break;
                    case DEPTH_RANGE_MID:
        		        data = ISATG_MODE_MID;
                        break;
                    case DEPTH_RANGE_FAR:
        		        data = ISATG_MODE_FAR;
                        break;
                    case DEPTH_RANGE_XFAR:
        		        data = ISATG_MODE_XFAR;
                        break;
                }
            }
            else {
                switch (eDepthRange) {
                    case DEPTH_RANGE_NEAR:
        		        data = ISATG_MODE_NEAR;
                        break;
                    case DEPTH_RANGE_XNEAR:
        		        data = ISATG_MODE_NEAR;
                        break;
                    case DEPTH_RANGE_MID:
        		        data = ISATG_MODE_MID;
                        break;
                    case DEPTH_RANGE_FAR:
        		        //data = ISATG_MODE_FAR;
        		        data = ISATG_MODE_NEAR;
                        break;
                    case DEPTH_RANGE_XFAR:
        		        //data = ISATG_MODE_XFAR;
        		        data = ISATG_MODE_NEAR;
                        break;
                }
            }
            replaceCodeBlockData(&tmpCodeBlk, ISATG_MODE_ADDR, data);
            
            // Enable lasers
            replaceCodeBlockData(&tmpCodeBlk, pHPTBlkEna[0].addr, pHPTBlkEna[0].data);
            replaceCodeBlockData(&tmpCodeBlk, pHPTBlkEna[1].addr, pHPTBlkEna[1].data);

            if (eAfePart == AFE_ADDI9033) {
                // Enable/disable TAL
                replaceCodeBlockData(&tmpCodeBlk, ISATG_ADDI9033_TAL_PH_CMP_REG, pTALCode[0].data);
                replaceCodeBlockData(&tmpCodeBlk, ISATG_ADDI9033_TAL_EDGE_REG, pTALCode[1].data);
            }
		}

		// Add to the accumulated block
        appendCodeBlock(pCodeBlk, &tmpCodeBlk);
		free(tmpCodeBlk.pCode);
		tmpCodeBlk.pCode = NULL;
	    tmpCodeBlk.iLength = 0;
	}
}

void IsaTg::parseCode(char *filename, isa_code_block_t *pCodeBlk)
{
	int isCmntDS = 0;
	int isCmntBlk = 0;
	char buf[5] = "40CE";
	int codeIndex = 0;
	int hexIndex = 0;
	int toggle = 0;
    FILE *fp;

#ifndef Linux

    errno_t err = fopen_s(&fp, filename, "r");
    if (err || fp == NULL) {
        STRING e = "Missing ISATG file!";
		  throw e;
	}
#else
    fp = fopen(filename, "r");
    if(fp==NULL)
    {
        cout<<"Missing ISATG File!\n";
    }
#endif
	isa_code_entry_t *tmpBlk = (isa_code_entry_t *) malloc(ISATG_MAX_CODE_SIZE*sizeof(isa_code_entry_t));

/*    FILE *fpTemp;
    fpTemp=fopen("afe_firmware2.bin", "w+");
    */
	while(1) {
		char ch = fgetc(fp);
        if(ch == EOF || ch==255) {
			break;
		}

		// Test for comment
        if (ch == '/')	{
			ch = fgetc(fp);
			if (ch == '/') {
				// Double slash comment
				isCmntDS = 1;
			}
			else if((ch == '*') && (isCmntDS == 0)) {
				// Block comment
				isCmntBlk = 1;
			}
		}
		else if (ch == '*') {
			ch = fgetc(fp);
			if(ch == '/')	{
				// End of block comment
				isCmntBlk = 0;
			}
		}
		else if (ch=='\n') {
			// End of line is the end of double slash comment
			isCmntDS = 0;
		}
        else if ((ch != ' ') && (ch != '\t') && (ch != '\r') && (isCmntDS == 0) && (isCmntBlk == 0)) {
			// Not space, tab, or comment, must be code!
			buf[hexIndex%4] = ch;
			if (hexIndex%4 == 3) {
				buf[(hexIndex%4) + 1] = '\0';  // terminate the string
				if (strcmp(buf, "dumm") == 0) {
					hexIndex -= 4;
					ch = fgetc(fp);
				}
				else {
					//Convert hexa string to corresponding int value
					string s;
					s = string(buf);
					stringstream ss;
					ss << hex << s;

					if (toggle == 0) {
						ss >> tmpBlk[codeIndex].addr;
                        toggle = 1;
					}
					else {
						ss >> tmpBlk[codeIndex].data;;
                        codeIndex++;
						toggle = 0;
					}

/*
                            if (fpTemp!=NULL) {
                                fwrite(buf,sizeof(char),4,fpTemp);
                                if(toggle==1)
                                {
                                    cout<<buf<<" ";
                                    fwrite(" ",sizeof(char),1,fpTemp);

                                }
                                else
                                {
                                    cout<<buf<<"\n";
                                    fwrite("\n",sizeof(char),1,fpTemp);
                                }

                            }
                            */
				}
			}
			hexIndex++;
		}
	}
    //fclose(fpTemp);
	fclose(fp);

	// Free previously allocated block
	if (pCodeBlk->pCode) {
		free(pCodeBlk->pCode);
        pCodeBlk->pCode = NULL;
        pCodeBlk->iLength = 0;
	}
	// Allocate a new block that's just the right size and copy from the temp block
	pCodeBlk->pCode = (isa_code_entry_t *) malloc(codeIndex*sizeof(isa_code_entry_t));
	memcpy(pCodeBlk->pCode, tmpBlk, codeIndex*sizeof(isa_code_entry_t));
	pCodeBlk->iLength = codeIndex;
	free(tmpBlk);
}

isa_code_block_t *IsaTg::getBaseCode(depth_range_e eDepthRange)
{
	this->eDepthRange = eDepthRange;

	return(getBaseCode());
}

isa_code_block_t *IsaTg::getBaseCode(void)
{
	char path[128];

	if (icCodeBlock.pCode) {
		free(icCodeBlock.pCode);
		icCodeBlock.pCode = NULL;
		icCodeBlock.iLength = 0;
	}

	if (eSensorType == NO_SENSOR) {
		return(&icCodeBlock);
	}

	getModePath(path);

	parseDir(path, &icCodeBlock, false);

    return(&icCodeBlock);
}

isa_code_block_t *IsaTg::getBaseCode(Param *pParams)
{
	this->eDepthRange = pParams->eDepthRange;

    if (eAfePart == AFE_ADDI9033) {
        this->updateToFIPCode(pParams);
    }

	return(getBaseCode());
}

isa_code_block_t *IsaTg::getSweepCode(depth_range_e eDepthRange, int iSwpState, Param *pParams)
{
	char path[128];

    if (eAfePart == AFE_ADDI9033) {
        //strcpy(path, "IsaTgCode\\\\VGAv3\\\\ADDI9033");
        strcpy(path, "IsaTgCode\\\\VGAv3\\\\ADDI9033\\\\");
    }
    else {
	    switch(eSensorType) {
	    case VGA_V1:
		    strcpy(path, "CalibrateCode\\\\\\VGAv1\\\\Mode0_Near");
		    break;
	    case VGA_V2:
		    strcpy(path, "CalibrateCode\\\\\\VGAv2\\\\Mode0_Near");
		    break;
	    case VGA_V3:
		    strcpy(path, "CalibrateCode\\\\VGAv3\\\\Mode0_Near");
		    break;
	    case SXGA_V1:
		    strcpy(path, "CalibrateCode\\\\SXGAv1\\\\Mode0_Near");
		    break;
	    case SXGA_V2:
		    strcpy(path, "CalibrateCode\\\\SXGAv2\\\\Mode0_Near");
		    break;
	    case SXGA_V3:
		    strcpy(path, "CalibrateCode\\\\\\SXGAv3\\\\Mode0_Near");
		    break;
        }

    }

	switch (iSwpState) {
	case 1:
		strcat(path, "\\\\Swp1\\\\");
		break;
	case 2:
	case 6:
		strcat(path, "\\\\Swp2\\\\");
		break;
	case 3:
	case 7:
		strcat(path, "\\\\Swp3\\\\");
		break;
	case 4:
		strcat(path, "\\\\Swp4\\\\");
		break;
	case 0:
	case 5:
		strcat(path, "\\\\Swp0\\\\");
		break;
	}

	if (icSweepCode.pCode != NULL) {
		free(icSweepCode.pCode);
		icSweepCode.pCode = NULL;
		icSweepCode.iLength = 0;
	}

    this->updateToFIPCode(pParams);
	parseDir(path, &icSweepCode, true);

	return(&icSweepCode);
}

    
uint16 IsaTg::setPulseCnt(uint16 unPulseCnt) 
{
    uint16 unPulseCntMax;

    // Select the max pulse count for the given depth range
    switch (eDepthRange) {
    case DEPTH_RANGE_NEAR:
        unPulseCntMax = ISATG_PULSE_CNT_NEAR_MAX;
        break;
    case DEPTH_RANGE_XNEAR:
        unPulseCntMax = ISATG_PULSE_CNT_XNEAR_MAX;
        break;
    case DEPTH_RANGE_MID:
        unPulseCntMax = ISATG_PULSE_CNT_MID_MAX;
        break;
    case DEPTH_RANGE_FAR:
        unPulseCntMax = ISATG_PULSE_CNT_FAR_MAX;
        break;
    case DEPTH_RANGE_XFAR:
        unPulseCntMax = ISATG_PULSE_CNT_XFAR_MAX;
        break;
    default:
        unPulseCntMax = ISATG_PULSE_CNT_MAX;
    }

    // Set the pulse count and clip to min and max
    this->unPulseCnt = unPulseCnt > unPulseCntMax ? unPulseCntMax : unPulseCnt; 
    this->unPulseCnt = unPulseCnt == 0 ? 1 : this->unPulseCnt; 

    // Only needed for ADDI9033
    ToFIPRegs.tof_raw_start_hdcnt.setData(getStartHDCnt(unPulseCnt)); 

    // Return pulse count in case it has change due to clipping 
    return(this->unPulseCnt);
}

isa_code_block_t *IsaTg::getPulseCntCode(void)
{
	char filename[128];

	if (icPulseCntCode.pCode != NULL) {
		free(icPulseCntCode.pCode);
		icPulseCntCode.pCode = NULL;
		icPulseCntCode.iLength = 0;
	}

	char path[128];
	getModePath(path);
 
    if(cCancellation == CANCELLATION_DISABLE)
        findLoadFile(filename, 9, path);
    else
        findLoadFile(filename, 8, path);

	parseCode(filename, &icPulseCntCode);

	/*
	 * Note: The way we identifuy LD pulse registers in file #9 is by 
	 * looking for the default value of 0x0FA0 (4000). If this default 
	 * value changes then this code will not longer work!!!!
	 */
    if(!bWDREnable && (cCancellation == CANCELLATION_DISABLE))
	{
		for (int i=0; i<icPulseCntCode.iLength; i++) {
			if(icPulseCntCode.pCode[i].data != 142)//60 FPS Supprt
			icPulseCntCode.pCode[i].data = unPulseCnt;
		}
	}

    //printf("requested Pulse Count = %d\n", this->unPulseCnt);
    //Pulse count change for cancellation
    if(cCancellation != CANCELLATION_DISABLE)
    {
        for (int k=0; k<icPulseCntCode.iLength; k++) {
            if(icPulseCntCode.pCode[k].data == 0x003c)
            {
                icPulseCntCode.pCode[k].data = ((double)unPulseCnt/36+0.5);
                this->unPulseCnt = icPulseCntCode.pCode[k].data *36;

            }
        }
        //printf("New pulse count=%d\n", this->unPulseCnt);
    }

	if (icTmpCode.pCode != NULL) {
		free(icTmpCode.pCode);
		icTmpCode.pCode = NULL;
        icTmpCode.iLength = 0;
	}

    // Disable lasers
    icHPTBlkEna.pCode[0].data = 0;
    icHPTBlkEna.pCode[1].data = 0;
    appendCodeBlock(&icTmpCode, &icHPTBlkEna);
    // Append pulse counts
    appendCodeBlock(&icTmpCode, &icPulseCntCode);

    if (this->eAfePart != AFE_ADDI9030) {
        uint16 addr = TOF_READ_SIZE2;
        uint16 data = getStartHDCnt(unPulseCnt);
        appendCodeBlockData(&icTmpCode, addr, data);
    }

    // Re-enable lasers
    icHPTBlkEna.pCode[0].data = this->unLaserEnaReg;
    icHPTBlkEna.pCode[1].data = this->unLaserEnaReg;
    appendCodeBlock(&icTmpCode, &icHPTBlkEna);

	return(&icTmpCode);
}

isa_code_block_t *IsaTg::getPulseCntCode(uint16 unPulseCnt)
{

	this->unPulseCnt = unPulseCnt;
    // Only needed for ADDI9033
    ToFIPRegs.tof_raw_start_hdcnt.setData(getStartHDCnt(unPulseCnt)); 
	return(getPulseCntCode());

}

void IsaTg::setLaserEnaReg(uint16 unLaserEnaReg) 
{ 
    this->unLaserEnaReg &= 0xF0; 
    this->unLaserEnaReg |= unLaserEnaReg & 0x0F; 

    pHPTBlkEna[0].data = this->unLaserEnaReg;
    pHPTBlkEna[1].data = this->unLaserEnaReg;
}

isa_code_block_t *IsaTg::getLaserEnaCode(void)
{
    pHPTBlkEna[0].data = this->unLaserEnaReg;
    pHPTBlkEna[1].data = this->unLaserEnaReg;

    return(&icHPTBlkEna);
}

isa_code_block_t *IsaTg::getHPTStdbyCode(depth_range_e eDepthRange)
{
	this->eDepthRange = eDepthRange;

	return(getHPTStdbyCode());
}

void IsaTg::getHPTStdbyValues(uint8 *ucLDPos, uint8 *ucLDNeg, uint8 *ucSubPos, uint8 *ucSubNeg)
{
	if (icHPTStdbyCode.pCode == NULL) {
    	getHPTStdbyCode();
	}

    *ucLDPos = getCodeBlockData(&icHPTStdbyCode, ISATG_HPT_LD1_POS_ADDR);
    *ucLDNeg = getCodeBlockData(&icHPTStdbyCode, ISATG_HPT_LD1_NEG_ADDR);
    if (eAfePart == AFE_ADDI9030) {
        *ucSubPos = getCodeBlockData(&icHPTStdbyCode, ISATG_HPT_SUB_POS_ADDR);
        *ucSubNeg = getCodeBlockData(&icHPTStdbyCode, ISATG_HPT_SUB_NEG_ADDR);
    }
    else {
        *ucSubPos = getCodeBlockData(&icHPTStdbyCode, ISATG_ADDI9033_HPT_SUB_POS_ADDR);
        *ucSubNeg = getCodeBlockData(&icHPTStdbyCode, ISATG_ADDI9033_HPT_SUB_NEG_ADDR);
    }
}

isa_code_block_t *IsaTg::getHPTStdbyCode(void)
{
	char filename[128];
	char path[128];

	if (icHPTStdbyCode.pCode) {
    	return(&icHPTStdbyCode);
	}

	if (eSensorType == NO_SENSOR) {
		return(NULL);
	}

	getModePath(path);

    findLoadFile(filename, 2, path);

	parseCode(filename, &icHPTStdbyCode);

	return(&icHPTStdbyCode);
}

void IsaTg::clrHPTStdbyOffsets(void)
{
	if (icHPTStdbyCode.pCode != NULL) {
		free(icHPTStdbyCode.pCode);
		icHPTStdbyCode.pCode = NULL;
        icHPTStdbyCode.iLength = 0;
	}
}

void IsaTg::setHPTStdbyOffsets(uint8 ucLDPos, uint8 ucLDNeg, uint8 ucSubPos, uint8 ucSubNeg)
{

	if (icHPTStdbyCode.pCode != NULL) {
		free(icHPTStdbyCode.pCode);
		icHPTStdbyCode.pCode = NULL;
        icHPTStdbyCode.iLength = 0;
	}

    struct htp_code {
        CodeEntry<uint16> LDPosBlk;
        CodeEntry<uint16> LDNegBlk;
        CodeEntry<uint16> LDStby;
        CodeEntry<uint16> LD1Pos;
        CodeEntry<uint16> LD1Neg;
        CodeEntry<uint16> LD2Pos;
        CodeEntry<uint16> LD2Neg;
        CodeEntry<uint16> LD3Pos;
        CodeEntry<uint16> LD3Neg;
        CodeEntry<uint16> LD4Pos;
        CodeEntry<uint16> LD4Neg;
        CodeEntry<uint16> SubPos;
        CodeEntry<uint16> SubNeg;
    } HPTStdbyCode;

    HPTStdbyCode.LDPosBlk.set(ISATG_HPT_LD_POS_BLK_ADDR, 0x0010);
    HPTStdbyCode.LDNegBlk.set(ISATG_HPT_LD_NEG_BLK_ADDR, 0x0003);
    HPTStdbyCode.LDStby.set(ISATG_HPT_LD_STBY_ADDR, 0x0000);

    HPTStdbyCode.LD1Pos.set(ISATG_HPT_LD1_POS_ADDR, ucLDPos);
    HPTStdbyCode.LD1Neg.set(ISATG_HPT_LD1_NEG_ADDR, ucLDNeg);
    HPTStdbyCode.LD2Pos.set(ISATG_HPT_LD2_POS_ADDR, ucLDPos);
    HPTStdbyCode.LD2Neg.set(ISATG_HPT_LD2_NEG_ADDR, ucLDNeg);
    HPTStdbyCode.LD3Pos.set(ISATG_HPT_LD3_POS_ADDR, ucLDPos);
    HPTStdbyCode.LD3Neg.set(ISATG_HPT_LD3_NEG_ADDR, ucLDNeg);
    if (eAfePart == AFE_ADDI9030) {
        HPTStdbyCode.LD4Pos.set(ISATG_HPT_LD4_POS_ADDR, ucLDPos);
        HPTStdbyCode.LD4Neg.set(ISATG_HPT_LD4_NEG_ADDR, ucLDNeg);
        HPTStdbyCode.SubPos.set(ISATG_HPT_SUB_POS_ADDR, ucSubPos);
        HPTStdbyCode.SubNeg.set(ISATG_HPT_SUB_NEG_ADDR, ucSubNeg);
    }
    else {
        HPTStdbyCode.LD4Pos.set(ISATG_ADDI9033_HPT_LD4_POS_ADDR, ucLDPos);
        HPTStdbyCode.LD4Neg.set(ISATG_ADDI9033_HPT_LD4_NEG_ADDR, ucLDNeg);
        HPTStdbyCode.SubPos.set(ISATG_ADDI9033_HPT_SUB_POS_ADDR, ucSubPos);
        HPTStdbyCode.SubNeg.set(ISATG_ADDI9033_HPT_SUB_NEG_ADDR, ucSubNeg);
    }


    icHPTStdbyCode.pCode = (isa_code_entry_t *) malloc(sizeof(HPTStdbyCode));
    memcpy(icHPTStdbyCode.pCode, &HPTStdbyCode, sizeof(HPTStdbyCode));
    icHPTStdbyCode.iLength = sizeof(HPTStdbyCode)/sizeof(CodeEntry<uint16>);

}

isa_code_block_t *IsaTg::getHPTIsaCode(depth_range_e eDepthRange)
{
	this->eDepthRange = eDepthRange;

	return(getHPTIsaCode());
}

isa_code_block_t *IsaTg::getHPTIsaCode(void)
{
	char filename[128];
	char path[128];

	if (icHPTIsaCode.pCode != NULL) {
        return(&icHPTIsaCode);
	}

	if (eSensorType == NO_SENSOR) {
		return(NULL);
	}

	getModePath(path);

    // Read in file 5
    findLoadFile(filename, 5, path);
    parseCode(filename, &icHPTIsaCode);

    uint8 ucLD0Pos, ucLD0Neg, ucLD1Pos, ucLD1Neg; 
    uint8 ucS0Pos, ucS0Neg, ucS1Pos, ucS1Neg;

    // Extract the offsets from file 5 code
    this->getHPTIsaValues(&ucLD0Pos, &ucLD0Neg, &ucLD1Pos, &ucLD1Neg,
                          &ucS0Pos, &ucS0Neg, &ucS1Pos, &ucS1Neg);

    // Reformat with just the offset code
    this->setHPTIsaOffsets(ucLD0Pos, ucLD0Neg,
                               ucLD1Pos, ucLD1Neg, 
                               ucS0Pos, ucS0Neg,  
                               ucS1Pos, ucS1Neg);

    return(&icHPTIsaCode);
}

void IsaTg::getHPTIsaValues(uint8 *ucLD0Pos, uint8 *ucLD0Neg,
                            uint8 *ucLD1Pos, uint8 *ucLD1Neg, 
                            uint8 *ucS0Pos, uint8 *ucS0Neg,  
                            uint8 *ucS1Pos, uint8 *ucS1Neg)
{
	if (icHPTIsaCode.pCode == NULL) {
    	getHPTIsaCode();
	}

    uint16 addr = ISATG_HPT_SEQ01_ADDR;
    uint16 tmp = getCodeBlockData(&icHPTIsaCode, addr);
    *ucLD0Pos = tmp & 0x00ff;
    *ucLD0Neg = tmp >> 8;

    if (eAfePart == AFE_ADDI9030) addr++;
    tmp = getCodeBlockData(&icHPTIsaCode, addr + 4);
    *ucS0Pos = tmp & 0x00ff;
    *ucS0Neg = tmp >> 8;

    addr = ISATG_HPT_SEQ03_ADDR;
    tmp = getCodeBlockData(&icHPTIsaCode, addr);
    *ucLD1Pos = tmp & 0x00ff;
    *ucLD1Neg = tmp >> 8;

    if (eAfePart == AFE_ADDI9030) addr++;
    tmp = getCodeBlockData(&icHPTIsaCode, addr + 4);
    *ucS1Pos = tmp & 0x00ff;
    *ucS1Neg = tmp >> 8;
}

void IsaTg::setHPTIsaOffsets(uint8 ucLD0Pos, uint8 ucLD0Neg,
                               uint8 ucLD1Pos, uint8 ucLD1Neg, 
                               uint8 ucS0Pos, uint8 ucS0Neg,  
                               uint8 ucS1Pos, uint8 ucS1Neg)
{

	if (icHPTIsaCode.pCode != NULL) {
		free(icHPTIsaCode.pCode);
		icHPTIsaCode.pCode = NULL;
        icHPTIsaCode.iLength = 0;
	}

    uint16 LD0Data = (ucLD0Neg << 8) | ucLD0Pos;
    uint16 LD1Data = (ucLD1Neg << 8) | ucLD1Pos;
    uint16 S0Data = (ucS0Neg << 8) | ucS0Pos;
    uint16 S1Data = (ucS1Neg << 8) | ucS1Pos;

    struct htp_code {
        CodeEntry<uint16> ceSeq01LD1;
        CodeEntry<uint16> ceSeq01LD2;
        CodeEntry<uint16> ceSeq01LD3;
        CodeEntry<uint16> ceSeq01LD4;
        CodeEntry<uint16> ceSeq01Sub;

        CodeEntry<uint16> ceSeq03LD1;
        CodeEntry<uint16> ceSeq03LD2;
        CodeEntry<uint16> ceSeq03LD3;
        CodeEntry<uint16> ceSeq03LD4;
        CodeEntry<uint16> ceSeq03Sub;

        CodeEntry<uint16> ceSeq05Sub;

        CodeEntry<uint16> ceSeq07LD1;
        CodeEntry<uint16> ceSeq07LD2;
        CodeEntry<uint16> ceSeq07LD3;
        CodeEntry<uint16> ceSeq07LD4;
        CodeEntry<uint16> ceSeq07Sub;
    } HPTIsaCode;

    uint16 addr = ISATG_HPT_SEQ01_ADDR;
    HPTIsaCode.ceSeq01LD1.set(addr++,  LD0Data);
    HPTIsaCode.ceSeq01LD2.set(addr++,  LD0Data);
    HPTIsaCode.ceSeq01LD3.set(addr++,  LD0Data);
    HPTIsaCode.ceSeq01LD4.set(addr++,  LD0Data);
    if (eAfePart == AFE_ADDI9030) addr++;
    HPTIsaCode.ceSeq01Sub.set(addr++,  S0Data);

    addr = ISATG_HPT_SEQ03_ADDR;
    HPTIsaCode.ceSeq03LD1.set(addr++,  LD1Data);
    HPTIsaCode.ceSeq03LD2.set(addr++,  LD1Data);
    HPTIsaCode.ceSeq03LD3.set(addr++,  LD1Data);
    HPTIsaCode.ceSeq03LD4.set(addr++,  LD1Data);
    if (eAfePart == AFE_ADDI9030) addr++;
    HPTIsaCode.ceSeq03Sub.set(addr++,  S1Data);

    addr = ISATG_HPT_SEQ05_ADDR+4;
    if (eAfePart == AFE_ADDI9030) addr++;
    HPTIsaCode.ceSeq05Sub.set(addr++,  S0Data);

    addr = ISATG_HPT_SEQ07_ADDR;
    HPTIsaCode.ceSeq07LD1.set(addr++,  LD0Data);
    HPTIsaCode.ceSeq07LD2.set(addr++,  LD0Data);
    HPTIsaCode.ceSeq07LD3.set(addr++,  LD0Data);
    HPTIsaCode.ceSeq07LD4.set(addr++,  LD0Data);
    if (eAfePart == AFE_ADDI9030) addr++;
    HPTIsaCode.ceSeq07Sub.set(addr++,  S0Data);

    icHPTIsaCode.pCode = (isa_code_entry_t *) malloc(sizeof(HPTIsaCode));
    memcpy(icHPTIsaCode.pCode, &HPTIsaCode, sizeof(HPTIsaCode));
    icHPTIsaCode.iLength = sizeof(HPTIsaCode)/sizeof(CodeEntry<uint16>);

   	char filename[128];
	char path[128];
   	getModePath(path);

    // Append file 10
    findLoadFile(filename, 10, path);
    parseCode(filename, &icTmpCode);
    appendCodeBlock(&icHPTIsaCode, &icTmpCode);

    // Append file 13
    findLoadFile(filename, 10, path);
    parseCode(filename, &icTmpCode);
    appendCodeBlock(&icHPTIsaCode, &icTmpCode);

}

void IsaTg::setTALEnable(bool bTalEnable)
{
    this->bTalEnable = bTalEnable;
    if (bTalEnable) {
        pTALCode[0].data = ISATG_ADDI9033_TAL_PH_CMP_EN_DATA;
        pTALCode[1].data = ISATG_ADDI9033_TAL_EDGE_EN_DATA;
    }
    else {
        pTALCode[0].data = 0;
        pTALCode[1].data = 0;
    }
}

isa_code_block_t *IsaTg::getTALEnableCode(bool bTalEnable)
{
    this->setTALEnable(bTalEnable);

    return(&icTALEnable);
}

isa_code_block_t *IsaTg::getMultiRangeCode(void) { 
    return (&icMultiRangeCode); 
}

void IsaTg::setMultRangePattern(isa_mr_pattern_t *PatternMap, int iSize)
{
    if (PatternMap == NULL || iSize <= 0 || iSize > ISATG_MAX_PATTERN) {
        bMultiRange = false;
        // disable multirange
        imMultRangeTbl.NumLvls.data = 0;
        return;
    }

    bMultiRange = true;
    imMultRangeTbl.NumLvls.data = iSize;

    for (int i = 0; i < iSize; i++) {
        imMultRangeTbl.Entry[i].PulseCnt.data = PatternMap[i].PulseCnt;
        imMultRangeTbl.Entry[i].NumFrames.data = PatternMap[i].Iter;
        imMultRangeTbl.Entry[i].Stdby.data = PatternMap[i].Stdby;
        imMultRangeTbl.Entry[i].Mode.data = PatternMap[i].Mode;
    }
}

/*
 * getCodeBlockData - Returns the data from the last instance of the given 
 *   address for the input code block.
 */
uint16 IsaTg::getCodeBlockData(isa_code_block_t *pCodeBlock, uint16 addr)
{
    if ((pCodeBlock == NULL) || (pCodeBlock->iLength == 0) || (pCodeBlock->pCode == NULL)) {
        return 0;
    }

    uint16 data = 0;
    for (int i=0; i<pCodeBlock->iLength; i++) {
        if (pCodeBlock->pCode[i].addr == addr) {
            data = pCodeBlock->pCode[i].data;
        }
    }
    return (data);
}

/*
 * replaceCodeBlockData - For the input code block, replaces the data for every code
 *   entry instance having the given address with the input data value.
 */
void IsaTg::replaceCodeBlockData(isa_code_block_t *pCodeBlock, uint16 addr, uint16 data)
{
	//PLG
#ifndef DISABLE_REG_WRITES
    if ((pCodeBlock == NULL) || (pCodeBlock->iLength == 0) || (pCodeBlock->pCode == NULL)) {
        return;
    }

    for (int i=0; i<pCodeBlock->iLength; i++) {
        if (pCodeBlock->pCode[i].addr == addr) {
            pCodeBlock->pCode[i].data = data;
        }
    }
#endif
}

/*
 * readCodeBlockData - Returns the data associated with the last instance of the given address.
 *   If the address is not present, a zero is returned;
 */
uint16 IsaTg::readCodeBlockData(isa_code_block_t *pCodeBlock, uint16 addr)
{
    if ((pCodeBlock == NULL) || (pCodeBlock->iLength == 0) || (pCodeBlock->pCode == NULL)) {
        return 0;
    }

    uint16 data = 0;

    for (int i=0; i<pCodeBlock->iLength; i++) {
        if (pCodeBlock->pCode[i].addr == addr) {
            data = pCodeBlock->pCode[i].data;
        }
    }

    return(data);
}

void IsaTg::appendCodeBlockData(isa_code_block_t *pCodeBlock, uint16 addr, uint16 data)
{

    isa_code_entry_t *tmpEntry;

	tmpEntry = (isa_code_entry_t *) malloc((pCodeBlock->iLength + 1)*sizeof(isa_code_entry_t));
    memcpy(tmpEntry, pCodeBlock->pCode, pCodeBlock->iLength*sizeof(isa_code_entry_t));

    free(pCodeBlock->pCode);
    pCodeBlock->pCode = tmpEntry;

    pCodeBlock->pCode[pCodeBlock->iLength].addr = addr;
    pCodeBlock->pCode[pCodeBlock->iLength].data = data;

    pCodeBlock->iLength++;

}

void IsaTg::appendCodeBlock(isa_code_block_t *pCodeBlock, isa_code_block_t *pCodeBlockA)
{

    isa_code_entry_t *tmpEntry;
    int iLength = pCodeBlock->iLength + pCodeBlockA->iLength;

	tmpEntry = (isa_code_entry_t *) malloc(iLength*sizeof(isa_code_entry_t));
    memcpy(tmpEntry, pCodeBlock->pCode, pCodeBlock->iLength*sizeof(isa_code_entry_t));
    memcpy(tmpEntry + pCodeBlock->iLength, pCodeBlockA->pCode, pCodeBlockA->iLength*sizeof(isa_code_entry_t));

    if (pCodeBlock->pCode) {
        free(pCodeBlock->pCode);
    }
    pCodeBlock->pCode = tmpEntry;
    pCodeBlock->iLength = iLength;
}

uint16 IsaTg::findCodeBlockData(isa_code_block_t *pCodeBlock, uint16 addr)
{
    for (int i = 0; i < pCodeBlock->iLength; i++) {
        if (pCodeBlock->pCode[i].addr == addr) {
            return(pCodeBlock->pCode[i].data);
        }
    }
    return(0);
}

uint16 IsaTg::getStartHDCnt(uint16 unPulseCnt)
{
    // Calculate HDCnt for Imm RO mode
    int iHDCnt;
    if (unPulseCnt <= 120) {
        iHDCnt = 3*12 + 56;
    }
    else {
        iHDCnt = ((unPulseCnt - 120) * 7 + 927) / 928;
        iHDCnt = ((iHDCnt + 2) * 36) + 2;
    }

    return(iHDCnt);
}

void IsaTg::wrToFIPToFile(char *filename)
{
    FILE *fp = fopen(filename, "w");
    if (!fp) {
        return;
    }

    isa_code_entry_t *pEntry = (isa_code_entry_t *) icToFIPCode.pCode;

    for (int i=0; i< icToFIPCode.iLength; i++) {
        fprintf(fp, "%4.4x %4.4x\n", pEntry->addr, pEntry->data);
        pEntry++;
    }

    fclose(fp);
}

isa_code_block_t *IsaTg::getDepthIRModeCode(bool bDepthIRMode)
{
    this->bDepthIRMode = bDepthIRMode;

    tof_bypass_t bypass = ToFIPRegs.bypass.data;

    if (bDepthIRMode) {
        bypass.bypass_depth = 0;
        bypass.bypass_ir = 0;
    }
    else {
        bypass.bypass_depth = 1;
        bypass.bypass_ir = 2;
    }
    ToFIPRegs.bypass.setData(bypass);

    return(&icToFIPCode);
}

isa_code_block_t *IsaTg::getToFIPCode(Param *pParams)
{
    this->updateToFIPCode(pParams);
    
	return(&icToFIPCode);
}

void IsaTg::updateToFIPCode(Param *pParams)
{
    tof_control_t control;
    control.tof_enable = 0;                             // Enable the ToF Processor
    ToFIPRegs.control_disable.setData(control);

    if (pParams->ucRawMode) {
        tof_align_rgb_raw_map_t align_rgb_raw;
        align_rgb_raw.rgb_raw_map_e = 0;
        align_rgb_raw.rgb_raw_map_o = 1;
        align_rgb_raw.reserved0 = 0;
        align_rgb_raw.reserved1 = 0;
        ToFIPRegs.align_rgb_raw.setData(align_rgb_raw);
    }

    if (!pParams->ucRawMode) {
        tof_bypass_t bypass;                                            // TODO:  Not used for now
        if (bDepthIRMode) {
            bypass.bypass_depth = 0;
            bypass.bypass_ir = 0;
        }
        else {
            bypass.bypass_depth = 1;
            bypass.bypass_ir = 2;
        }
        bypass.bypass_align = 0;
        bypass.bypass_defect = 0;
        bypass.bypass_rate_adjust = 0;
        bypass.bypass_grid = 0;
        bypass.bypass_grid_sel = 0;
        bypass.bypass_cdc = 0;
        bypass.bypass_filter = 0;
        bypass.bypass_gauss = 0;
        bypass.bypass_prodsum = pParams->RawNREna ? 0 : 1;
        bypass.bypass_depth_ir = 0;
        bypass.lnr_bypass = 0;
        bypass.bypass_output = 0;
        bypass.reserved = 0;
        ToFIPRegs.bypass.setData(bypass);
    }

    // Defect pixel correction
    ToFIPRegs.dfct_pix_sat_th.setData(pParams->DfctPixSatTh);
    tof_dfct1_t dfct1;
    dfct1.dfct_pix_enbl_sel = pParams->DfctPixEna;
    dfct1.dfct_med_ref_sel = pParams->DfctMedRefSel;
    dfct1.dfct_det_bsln_sel = pParams->DfctDetBslnSel;
    dfct1.reserved = 0;
    ToFIPRegs.dfct_pix_sel.setData(dfct1);
    for (int i=0; i<TOF_DFCT_PIX_TH_TBL_SIZE; i++) {
        ToFIPRegs.dfct_pix_th_tbl[i].setData(pParams->DfctThrTbl[i]);
    }

    // Rate adjust
    ToFIPRegs.rate_adj_hd_period.setData(pParams->RateAdjHdPeriod);  

    //uint16 img_height = ((pParams->uiInHeight - pParams->ToFStartHDCnt) * 2 / 3) - 1;
    uint16 img_height = ((pParams->uiInHeight - pParams->ToFStartHDCnt) * 2 / 3) - 3;
    if (img_height & 1 == 0) {  // Must be odd
        img_height -= 1;
    }
    ToFIPRegs.rate_adj_img_height.setData(img_height);
    //ToFIPRegs.rate_adj_img_height.setData(491);

    uint16 img_width = (pParams->uiInWidth - pParams->ToFStartPixCnt) - 2;
    uint16 img_max_width = (pParams->RateAdjHdPeriod * 3 / 4) - 8 - 1;
    img_width = img_width > img_max_width ? img_max_width : img_width;
    if (img_width & 1) {  // Must be even
        img_width -= 1;
    }
    ToFIPRegs.rate_adj_img_width.setData(img_width);
    //ToFIPRegs.rate_adj_img_width.setData(640);

    // Grid conversion
    tof_grid0_t grid0;
    grid0.vgashrt_xofst = pParams->VGAShrtXOfst;
    grid0.vgashrt_xpwr = pParams->VGAShrtXPwr;
    ToFIPRegs.grid0.setData(grid0);
    tof_grid1_t grid1;
    grid1.vgalng_sat_th = pParams->VGALngSatTh;
    grid1.wdr_bitsft = pParams->WDRBitSft;
    grid1.reserved = 0;
    ToFIPRegs.grid1.setData(grid1);
    ToFIPRegs.grid_ks_vga_sht2lng.setData(pParams->KsVGAShrt2Lng);
    ToFIPRegs.grid_obclmplev.setData(pParams->OBClmpLev);

    // Noise reduction filter
    for (int i=0; i<TOF_RAWNR_BL_TBL_SIZE; i++) {
        ToFIPRegs.rawnr_bk_tbl[i].setData(pParams->RawNRBkTbl[i]);
        ToFIPRegs.rawnr_bl_tbl[i].setData(pParams->RawNRBlTbl[i]);
    }
    tof_rawnr_med_t med;
    med.rawnr_med_en = pParams->RawNRMed4Bl1Sel & RAWNR_MED_EN;
    med.rawnr_med_sel = pParams->RawNRMed4Bl1Sel & RAWNR_MED_SEL;
    med.rawnr_medsel_gain = pParams->RawNRMed4Bl1Gain;
    med.reserved = 0;
    ToFIPRegs.rawnr_med.setData(med);
    for (int i=0; i<TOF_RAWNR_XPWR_SIZE; i++) {
        tof_pwr_t xpwr;
        xpwr.pwr1 = pParams->RawNRXPwr[4*i + 0];
        xpwr.pwr2 = pParams->RawNRXPwr[4*i + 1];
        xpwr.pwr3 = pParams->RawNRXPwr[4*i + 2];
        xpwr.pwr4 = pParams->RawNRXPwr[4*i + 3];
        ToFIPRegs.rawnr_xpwr[i].setData(xpwr);
    }

    // Coring threshold
    tof_cor0_t cor0;
    cor0.s0s1_corth = pParams->S0S1CorTh;
    cor0.sm_sig_rmv_en = pParams->ucSmSigRmvEna;
    cor0.reserved = 0;
    ToFIPRegs.cor0.setData(cor0);
    ToFIPRegs.corth_sft_dec_ofst.setData(pParams->CorThSftDecOfst);
    ToFIPRegs.corth_sft_inc_ofst.setData(pParams->CorThSftIncOfst);
    ToFIPRegs.corth_det_gainb.setData(pParams->CorThDetGainB);
    ToFIPRegs.corth_sft_gainb.setData(pParams->CorThSftGainB);
    ToFIPRegs.corth_det_cntb.setData(pParams->CorThDetCntB);
    ToFIPRegs.corth_det_gainf.setData(pParams->CorThDetGainF);
    ToFIPRegs.corth_sft_gainf.setData(pParams->CorThSftGainF);
    ToFIPRegs.corth_det_cntf.setData(pParams->CorThDetCntF);

    // IR 
    tof_ir1_t ir1;
    ir1.ir_dgain = pParams->IRDGain;
    ir1.ir_img_sel = pParams->IRImgSel;
    ir1.reserved = 0;
    ToFIPRegs.ir1.setData(ir1);
    tof_pwr_t ir_gmm;
    for (int i=0; i<TOF_GMM_TBL_SIZE; i++) {
        ir_gmm.pwr1 = pParams->IRGmmPwr[4*i + 0];
        ir_gmm.pwr2 = pParams->IRGmmPwr[4*i + 1];
        ir_gmm.pwr3 = pParams->IRGmmPwr[4*i + 2];
        ir_gmm.pwr4 = pParams->IRGmmPwr[4*i + 3];
        ToFIPRegs.ir_gmm[i].setData(ir_gmm);
    }
    ToFIPRegs.ir_gmm_y[0].setData(pParams->IRGmmY[0]);
    for (int i=1; i<TOF_GMM_Y_SIZE; i++) {
        uint16 gmm_y = pParams->IRGmmY[i] - pParams->IRGmmY[i-1];
        ToFIPRegs.ir_gmm_y[i].setData(gmm_y);
    }

    // Depth calc
    ToFIPRegs.depth_zerocorre.setData(pParams->DepthZeroCorre);
    ToFIPRegs.depth_addvlu.setData(pParams->DepthCalcAddVLU);
    // Not enough bits to perform slope ajust on HW, done in SW
    //ToFIPRegs.depth_ofstvlu.setData(pParams->DepthOfstVLU);
    //ToFIPRegs.depth_slope_gain.setData(pParams->DepthSlopeGain);
    ToFIPRegs.depth_ofstvlu.setData(0);
    ToFIPRegs.depth_slope_gain.setData(0x400);

    // Non-linear correction
    for (int i=0; i<TOF_LNR_OFST_SIZE; i++) {
        ToFIPRegs.lnr_ofst[i].setData(pParams->LnrOfst[i]);
    }
    ToFIPRegs.lnr_x0.setData(pParams->LnrX0);

    for (int i=0; i<TOF_LNR_XPWR_SIZE; i++) {
        tof_pwr_t xpwr;
        xpwr.pwr1 = pParams->LnrXPwr[4*i + 0];
        xpwr.pwr2 = pParams->LnrXPwr[4*i + 1];
        xpwr.pwr3 = pParams->LnrXPwr[4*i + 2];
        xpwr.pwr4 = pParams->LnrXPwr[4*i + 3];
        ToFIPRegs.lnr_xpwr[i].setData(xpwr);
    }

    ToFIPRegs.shd.setData(pParams->ucShdOfstEna);
    ToFIPRegs.shd_x0.setData(pParams->Shd_X0);
    for (int i=0; i<TOF_SHD_XPWR_SIZE; i++) {
        tof_pwr_t xpwr;
        xpwr.pwr1 = pParams->ShdXPwr[4*i + 0];
        xpwr.pwr2 = pParams->ShdXPwr[4*i + 1];
        xpwr.pwr3 = pParams->ShdXPwr[4*i + 2];
        xpwr.pwr4 = pParams->ShdXPwr[4*i + 3];
        ToFIPRegs.shd_xpwr[i].setData(xpwr);
    }
    ToFIPRegs.shd_y0.setData(pParams->Shd_Y0);
    for (int i=0; i<TOF_SHD_YPWR_SIZE; i++) {
        tof_pwr_t ypwr;
        ypwr.pwr1 = pParams->ShdYPwr[4*i + 0];
        ypwr.pwr2 = pParams->ShdYPwr[4*i + 1];
        ypwr.pwr3 = pParams->ShdYPwr[4*i + 2];
        ypwr.pwr4 = pParams->ShdYPwr[4*i + 3];
        ToFIPRegs.shd_ypwr[i].setData(ypwr);
    }

    // Settings for raw mode
    ToFIPRegs.tof_raw_height_hdcnt.setData(0x02f1);  // 753
    uint16 iHDCnt = getStartHDCnt(unPulseCnt);
    ToFIPRegs.tof_raw_start_hdcnt.setData(iHDCnt); 
    ToFIPRegs.tof_raw_width_pixcnt.setData(0x39e);   // 926
    if (pParams->ucRawMode) {
        ToFIPRegs.tof_raw_start_pixcnt.setData(0x108);   // One less for raw mode
    }
    else {
        ToFIPRegs.tof_raw_start_pixcnt.setData(0x109);   // 265
    }

    // Region of interest
    if (pParams->ucRawMode) {
        // Settings for raw mode
        ToFIPRegs.tof_raw_roi_height.setData(0x02ee);  // 750   
        ToFIPRegs.tof_raw_roi_hstart.setData(0);
        ToFIPRegs.tof_raw_roi_vstart.setData(0);
        ToFIPRegs.tof_raw_roi_width.setData(0x029c);   // 668
    }
    else {
        ToFIPRegs.tof_raw_roi_height.setData(pParams->uiOutHeight);     
        ToFIPRegs.tof_raw_roi_hstart.setData(pParams->uiOutHStart);   
        ToFIPRegs.tof_raw_roi_vstart.setData(pParams->uiOutVStart);
        ToFIPRegs.tof_raw_roi_width.setData(pParams->uiOutWidth);
    }

    // Output / test
    tof_output_t output;
    output.mipi_enable = 1;                                         // TODO:  Not enabled for GUI?
    output.output_depth = 1;                                        // TODO:  Add parameter
    output.output_ir = 1;
    output.output_ir_interleave = 0;
    output.gray_code_output = 0;  // Always zero
    output.reserved = 0;
    ToFIPRegs.output.setData(output);

    tof_output_sel_t output_sel;
    output_sel.output_bg_sel = pParams->OutputBGSel;
    if (pParams->ucRawMode) {
        output_sel.output_intrlv_sel = 0;
    }
    else {
        output_sel.output_intrlv_sel = pParams->OutputIntrlvSel;
    }
    output_sel.reserved = 0;
    ToFIPRegs.output_sel.setData(output_sel);

    if (pParams->ucRawMode) {
        ToFIPRegs.field_index.set(TOF_FIELD_INDEX, 0x00C0);
    }
    else {
        ToFIPRegs.field_index.set(TOF_FIELD_INDEX, 0x0040);
    }

    // Enable the ToF Processor
    control.tof_enable = 1;                             
    control.m3w_sel = pParams->ucM3WSel;
    control.gridvga_sel = pParams->ucGridVGASel;
    control.sensor_type = TOF_SENSOR_MN34906BL;
    control.chan_swap = 0;
    control.vdhd_delay_adj = TOF_VDHD_DELAY_ADJ;
    control.reserved0 = 0;
    control.reserved1 = 0;
    ToFIPRegs.control_enable.setData(control);
}

void IsaTg::ToFIPInitAddrs(void)
{
//    ToFIPRegs.abort.set(TOF_ABORT, 1);
//    for (int i=0; i < TOF_ABORT_DELAY; i++) {
//        ToFIPRegs.dummy[i].set(TOF_DUMMY, 0);
//    }
    tof_control_t control = {0, 0, 0, 0, 0, 0, 8, 0};
    ToFIPRegs.control_disable.set(TOF_CONTROL, control);

    tof_align_map_t align;
    align.map_a0 = 1;                                  
    align.map_a1 = 4;
    align.map_a2 = 4;
    align.reserved = 0;
    ToFIPRegs.align_a_even.set(TOF_ALIGN0, align);
    align.map_a0 = 0;
    align.map_a1 = 4;
    align.map_a2 = 4;
    ToFIPRegs.align_a_odd.set(TOF_ALIGN1, align);
    align.map_a0 = 4;
    align.map_a1 = 1;
    align.map_a2 = 4;
    ToFIPRegs.align_b_even.set(TOF_ALIGN2, align);
    align.map_a0 = 4;
    align.map_a1 = 0;
    align.map_a2 = 4;
    ToFIPRegs.align_b_odd.set(TOF_ALIGN3, align);
    align.map_a0 = 4;
    align.map_a1 = 4;
    align.map_a2 = 1;
    ToFIPRegs.align_c_even.set(TOF_ALIGN4, align);
    align.map_a0 = 4;
    align.map_a1 = 4;
    align.map_a2 = 0;
    ToFIPRegs.align_c_odd.set(TOF_ALIGN5, align);

    tof_align_rgb_raw_map_t align_rgb_raw;
    align_rgb_raw.rgb_raw_map_e = 4;
    align_rgb_raw.rgb_raw_map_o = 4;
    align_rgb_raw.reserved0 = 0;
    align_rgb_raw.reserved1 = 0;
    ToFIPRegs.align_rgb_raw.set(TOF_ALIGN6, align_rgb_raw);

    tof_align_afe_t align_afe;
    align_afe.tof_afe_el_offset = 0;
    align_afe.tof_afe_ol_offset = 0;
    align_afe.tof_pixel_offset = 0;
    align_afe.reserved = 0;
    ToFIPRegs.align_afe1_offset.set(TOF_ALIGN7, align_afe);
    align_afe.tof_afe_el_offset = 0;
    align_afe.tof_afe_ol_offset = 0;
    align_afe.tof_pixel_offset = 1;
    ToFIPRegs.align_afe2_offset.set(TOF_ALIGN8, align_afe);
    align_afe.tof_afe_el_offset = 0;
    align_afe.tof_afe_ol_offset = 0;
    align_afe.tof_pixel_offset = 0;
    ToFIPRegs.align_rgb_afe1_offset.set(TOF_ALIGN9, align_afe);
    align_afe.tof_afe_el_offset = 0;
    align_afe.tof_afe_ol_offset = 0;
    align_afe.tof_pixel_offset = 0;
    ToFIPRegs.align_rgb_afe2_offset.set(TOF_ALIGN10, align_afe);

    ToFIPRegs.chkr_upprth.set(TOF_CHKR_UPPRTH, 0xfff);
    ToFIPRegs.chkr_lwrth.set(TOF_CHKR_LWRTH, 0);
    ToFIPRegs.chkr_start_h.set(TOF_CHKR_START_V, 0);
    ToFIPRegs.chkr_start_v.set(TOF_CHKR_START_H, 0);
    tof_chkr_size_t size;
    size.chkr_size_h = 0x20;
    size.chkr_startofst_h = 0xfc;
    size.reserved = 0;
    ToFIPRegs.chkr_size.set(TOF_CHKR_SIZE_H, size);
    ToFIPRegs.chkr_upprerr_h.set(TOF_CHKR_UPPRERR_H, 0);
    ToFIPRegs.chkr_upprerr_v.set(TOF_CHKR_UPPRERR_V, 0);
    ToFIPRegs.chkr_lwerr_h.set(TOF_CHKR_LWRERR_H, 0);
    ToFIPRegs.chkr_lwerr_v.set(TOF_CHKR_LWRERR_V, 0);
    ToFIPRegs.chkr_det_ena.set(TOF_CHKR_DET_ENA, 0);

    ToFIPRegs.dfct_pix_sat_th.set(TOF_DFCT0, 0x0f80);
    tof_dfct1_t dfct1;
    dfct1.dfct_pix_enbl_sel = 0;
    dfct1.dfct_med_ref_sel = 1;
    dfct1.dfct_det_bsln_sel = 0;
    dfct1.reserved = 0;
    ToFIPRegs.dfct_pix_sel.set(TOF_DFCT1, dfct1);
    for(int i=0; i<TOF_DFCT_PIX_TH_TBL_SIZE; i++) {
        ToFIPRegs.dfct_pix_th_tbl[i].set(TOF_DFCT_PIX_TH_TBL + i, 0x0fff);
    }

    ToFIPRegs.rate_adj_hd_period.set(TOF_RATE_ADJUST0, 928);
    ToFIPRegs.rate_adj_img_height.set(TOF_RATE_ADJUST1, 489);
    ToFIPRegs.rate_adj_img_width.set(TOF_RATE_ADJUST2, 664);

    tof_grid0_t grid0;
    grid0.vgashrt_xofst = 0;
    grid0.vgashrt_xpwr = 0;
    ToFIPRegs.grid0.set(TOF_GRID0, grid0);
    tof_grid1_t grid1;
    grid1.vgalng_sat_th = 0xf80;
    grid1.wdr_bitsft = 0;
    grid1.reserved = 0;
    ToFIPRegs.grid1.set(TOF_GRID1, grid1);
    ToFIPRegs.grid_ks_vga_sht2lng.set(TOF_GRID2, 0x400);
    ToFIPRegs.grid_obclmplev.set(TOF_GRID3, 0x80);

    for(int i=0; i<TOF_RAWNR_BL_TBL_SIZE; i++) {
        ToFIPRegs.rawnr_bk_tbl[i].set(TOF_RAWNR_BK_TBL_START + i, 0);
        ToFIPRegs.rawnr_bl_tbl[i].set(TOF_RAWNR_BL_TBL_START + i, 0);
    }
    tof_rawnr_med_t med;
    med.rawnr_med_en = 1;
    med.rawnr_med_sel = 1;
    med.rawnr_medsel_gain = 0x80;
    med.reserved = 0;
    ToFIPRegs.rawnr_med.set(TOF_RAWNR_MED, med);
    ToFIPRegs.rawnr_sat_th.set(TOF_RAWNR_SAT_TH, 0x3e00);
    tof_pwr_t xpwr = {0, 0, 0, 0};
    ToFIPRegs.rawnr_xpwr[0].set(TOF_RAWNR_XPWR_1, xpwr);
    ToFIPRegs.rawnr_xpwr[1].set(TOF_RAWNR_XPWR_5, xpwr);
    ToFIPRegs.rawnr_xpwr[2].set(TOF_RAWNR_XPWR_9, xpwr);

    tof_cor0_t cor0;
    cor0.s0s1_corth = 0x280;
    cor0.sm_sig_rmv_en = 1;
    cor0.reserved = 0;
    ToFIPRegs.cor0.set(TOF_COR0, cor0);
    ToFIPRegs.corth_sft_dec_ofst.set(TOF_COR1, 0);
    ToFIPRegs.corth_sft_inc_ofst.set(TOF_COR2, 0);
    ToFIPRegs.corth_det_gainb.set(TOF_CORB0, 0x100);
    ToFIPRegs.corth_sft_gainb.set(TOF_CORB1, 0x100);
    ToFIPRegs.corth_det_cntb.set(TOF_CORB2, 8);
    ToFIPRegs.corth_det_gainf.set(TOF_CORF0, 0x100);
    ToFIPRegs.corth_sft_gainf.set(TOF_CORF1, 0x100);
    ToFIPRegs.corth_det_cntf.set(TOF_CORF2, 8);

    tof_ir1_t ir1;
    ir1.ir_dgain = 0x100;
    ir1.ir_img_sel = 0;
    ir1.reserved = 0;
    ToFIPRegs.ir1.set(TOF_IR1, ir1);
    tof_pwr_t ir_gmm = {9, 9, 9, 9};
    for(int i=0; i<TOF_GMM_TBL_SIZE; i++) {
        ToFIPRegs.ir_gmm[i].set(TOF_GMM_TBL + i, ir_gmm);
    }
    for(int i=0; i<TOF_GMM_Y_SIZE; i++) {
        ToFIPRegs.ir_gmm_y[i].set(TOF_GMM_Y_START + i, 0x80);
    }

    ToFIPRegs.depth_zerocorre.set(TOF_DEPTH0, 0);
    ToFIPRegs.depth_addvlu.set(TOF_DEPTH1, 0x2000);
    ToFIPRegs.depth_ofstvlu.set(TOF_DEPTH2, 0);
    ToFIPRegs.depth_slope_gain.set(TOF_DEPTH3, 0x400);

    for(int i=0; i<TOF_LNR_OFST_SIZE; i++) {
        ToFIPRegs.lnr_ofst[i].set(TOF_LNR_OFST_START + i, 0);
    }
    ToFIPRegs.lnr_x0.set(TOF_LNR_X0, 0x3fff);
    for(int i=0; i<TOF_LNR_XPWR_SIZE; i++) {
        ToFIPRegs.lnr_xpwr[i].set(TOF_LNR_XPWR_START + i, xpwr);
    }

    ToFIPRegs.shd.set(TOF_SHD, 0);
    ToFIPRegs.shd_x0.set(TOF_SHD_X0, 0);
    for(int i=0; i<TOF_SHD_XPWR_SIZE; i++) {
        ToFIPRegs.shd_xpwr[i].set(TOF_SHD_XPWR_START + i, xpwr);
    }
    ToFIPRegs.shd_y0.set(TOF_SHD_Y0, 0);
    for(int i=0; i<TOF_SHD_YPWR_SIZE; i++) {
        ToFIPRegs.shd_ypwr[i].set(TOF_SHD_YPWR_START + i, xpwr);
    }

    ToFIPRegs.tof_raw_height_hdcnt.set(TOF_READ_SIZE0, 746);
    ToFIPRegs.rgb_height_hdcnt.set(TOF_READ_SIZE1, 0);
    ToFIPRegs.tof_raw_start_hdcnt.set(TOF_READ_SIZE2, 10);
    ToFIPRegs.rgb_start_hdcnt.set(TOF_READ_SIZE3, 0);
    ToFIPRegs.tof_raw_width_pixcnt.set(TOF_READ_SIZE4, 666);
    ToFIPRegs.tof_raw_start_pixcnt.set(TOF_READ_SIZE5, 207);
    ToFIPRegs.rgb_width_pixcnt.set(TOF_READ_SIZE6, 666);
    ToFIPRegs.rgb_start_pixcnt.set(TOF_READ_SIZE7, 1);

    ToFIPRegs.tof_raw_roi_height.set(TOF_ROI0, 480);
    ToFIPRegs.tof_raw_roi_hstart.set(TOF_ROI1, 12);
    ToFIPRegs.tof_raw_roi_vstart.set(TOF_ROI2, 5);
    ToFIPRegs.tof_raw_roi_width.set(TOF_ROI3, 640);
    ToFIPRegs.rgb_roi_height.set(TOF_ROI4, 0);
    ToFIPRegs.rgb_roi_hstart.set(TOF_ROI5, 0);
    ToFIPRegs.rgb_roi_vstart.set(TOF_ROI6, 0);
    ToFIPRegs.rgb_roi_width.set(TOF_ROI7, 0);


    tof_output_t output;
    output.mipi_enable = 0;
    output.output_depth = 1;
    output.output_ir = 1;
    output.output_ir_interleave = 0;
    output.gray_code_output = 0;  // Always zero
    output.reserved = 0;
    ToFIPRegs.output.set(TOF_OUTPUT, output);
    tof_output_sel_t output_sel = {0, 0, 0};
    ToFIPRegs.output_sel.set(TOF_OUTPUT_SEL, output_sel);

    tof_vc_t vc;
    vc.vc_bg = 2;
    vc.vc_depth = 0;
    vc.vc_ir = 1;
    vc.vc_irbg = 3;
    vc.vc_raw = 0;
    vc.vc_rgb = 0;
    vc.reserved = 0;
    ToFIPRegs.vc.set(TOF_VC, vc);

    tof_bypass_t bypass = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};                                            // TODO:  Not used for now
    ToFIPRegs.bypass.set(TOF_BYPASS, bypass);

    tof_testramp_t testramp = {0, 0, 0, 0, 0, 0, 0, 0};
    ToFIPRegs.testramp.set(TOF_TESTRAMP, testramp);

    ToFIPRegs.field_index.set(TOF_FIELD_INDEX, 0x0040);
    ToFIPRegs.field_index_mux.set(TOF_FIELD_INDEX_MUX, 0x0027);

    control.tof_enable = 1;                             
    control.m3w_sel = 0;
    control.gridvga_sel = 0;
    control.sensor_type = TOF_SENSOR_MN34906BL;
    control.chan_swap = 0;
    control.vdhd_delay_adj = TOF_VDHD_DELAY_ADJ;
    control.reserved0 = 0;
    control.reserved1 = 0;
    ToFIPRegs.control_enable.set(TOF_CONTROL, control);
}

