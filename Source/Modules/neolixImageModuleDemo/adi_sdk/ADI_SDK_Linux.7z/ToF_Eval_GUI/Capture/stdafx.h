/********************************************************************************/
/*																				*/
/* @file	stdafx.h															*/
/*																				*/
/* @brief	Macro settings for the ADDI9033										*/
/*																				*/
/* Copyright(c) Analog Devices, Inc.											*/
/*																				*/
/********************************************************************************/
#pragma once

#ifndef Linux
#include "targetver.h"
#endif

#define WIN32_LEAN_AND_MEAN             // Exclude rarely-used stuff from Windows headers
// Windows Header Files:
#define CRTDBG_MAP_ALLOC



#ifndef Linux
#include <windows.h>
#include <strmif.h>
#include <crtdbg.h>
#include <conio.h>
#include <uuids.h>
#include <Windows.h>
#include <dshow.h>
#include <chrono>
#include<vcclr.h>
#include<strsafe.h>
#ifndef ADI_SDK
#include <opencv2/video/tracking.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/contrib/contrib.hpp>
#include <opencv2/contrib/contrib.hpp>
#include "opencv2/legacy/legacy.hpp"
#endif
#endif

#include <stdlib.h>
#include <sstream>
#include <omp.h>
#include <math.h>
#include <time.h>
#include <bitset>
#include <string.h>

#include <fstream>

#include <types.h>
#include<cerrno>


//***************** Defines Specific to the ADDI9030, Full version ************************
#ifdef ADDI9030_MACROS_FULL
#define VERSION "V1.1.19"

// Enables timing values for the Elsa system
//#define ELSA_TIMING

// Enables timing for at least 5 meters
//#define TIMING_5_METER

// Disables Mid and Far ranges
//#define MIDDISABLE

// Disables Rail and Rail Calibration Method 2
//#define RAILDISABLE

// Disables AE
//#define AEDISABLE

// Disable MR
//#define MRDISABLE

#endif

//***************** Defines Specific to the ADDI9030, Customer version ************************
#ifdef ADDI9030_MACROS_CUST
#define VERSION "V2.0.0.3"

// Disables Mid and Far ranges
//#define MIDDISABLE

// Disables Rail and Rail Calibration Method 2
//#define RAILDISABLE

// Disables AE
//#define AEDISABLE

// Enables timing for at least 5 meters
//#define TIMING_5_METER


#endif

//***************** Defines Specific to the ADDI9033 ************************
#if !(defined ADDI9030_MACROS_CUST) && !(defined ADDI9030_MACROS_FULL)
#define VERSION "V3.0.0.7"

#define ADDI9033_MACROS

/// Enables Panasonic specific sweep
//#define PANA_SWEEP

// Tests Immediate mode switch
//#define MODESWITCH

// Disables Mid and Far ranges
//#define MIDDISABLE

// Disables Rail and Rail Calibration Method 2
//#define RAILDISABLE

// Disables AE
//#define AEDISABLE

#endif


//***************** Debug Defines ************************
// If defined, uses modifoed OpenCV driver, else uses DirectShow(Windows)/V4L2(Linux)
//#define OPENCV

// Disables any modification to the loadfiles in the IsaTg class methods
//#define DISABLE_REG_WRITES  //PLG

// Enables error handling when an empty frames arrives
#define ERR_HANDLING_EMPTYFRAME

// Perform statistics over time for the "Measure" pixel
#define ANALYSIS_STATS

// Enable stats write to file
#define ANALYSIS_STATS_DUMP

// Selects the post gridded S0 and S1 for stats collection instead of the
// post NR fitler versions.  Post gridded does not have BG subtracted
// whereas post NR filter does.
#define STATS_ANALYSIS_S0S1_GRD


//***************** Image Processing Defines ************************
// Enables the defect pixel correction code as implemented for the ADDI9033
//#define DEFECT_PIX_ENA

// Disables method 3W feature as implemented for the ADDI9033
#define NOT_M3W_MODE

// Enables the Noise Reduction Filter as implemented for the ADDI9033
#define NRFILTER_FULL

// Enables an optimized verison of the ADDI9033 noise reduction filter
#define NRFILTER_FOR_TOF_EVAL

// Enables a post depth motion compensated temporal filter/spatial filter
#define NRFILTER3D

// When defined, code is enabled to test if the floating point version of the 
// depth slope gain is present in the current calibration file.  If not,
// the depth slope gain is initialized based on depth range.
#define DEPTH_CNV_FACTOR_MISSING

// When defined, the post depth guided filter is enabled
//#define GUIDED_FILTER

// When defined, the guided filter is available to be called instead of NRFilter
//#define GUIDED_FILTER_S0S1

#ifdef ADI_SDK
#define STRING string
#else
#define STRING System::String^
#endif
