#pragma once
#include <stdafx.h>

#ifndef Linux
#include <CyAPI.h>
#endif

#include "device.h"

#include "IsaTg.h"

#define SPIXFER_MAX_ERR_CNT 10

enum xferT
{
	USB,
	UVC
};

#ifndef OPENCV
class SpiXfer
{
	bool bXferInProgress;
	xferT xferType;
    Device *dev;
public:
	SpiXfer();

	int getDeviceId(img_sensor_e eSensorType);
	bool SpiWrSlow(isa_code_block_t *pCodeBlk);
    bool SpiWrFast(isa_code_block_t *pCodeBlk);
	void spiInit(Device *dev,xferT xferType=UVC);
};
#else
class SpiXfer
{
	bool bXferInProgress;
	xferT xferType;
#ifndef Linux
	cv::VideoCapture *cvCap;
#else
    Device *dev;
#endif
public:
	SpiXfer();

	int getDeviceId(img_sensor_e eSensorType);
	bool SpiWrSlow(isa_code_block_t *pCodeBlk);
        bool SpiWrFast(isa_code_block_t *pCodeBlk);
#ifndef Linux
    void spiInit(cv::VideoCapture *cvCap,xferT xferType=UVC);
#else
    void spiInit(Device *dev,xferT xferType=UVC);
#endif
};
#endif

