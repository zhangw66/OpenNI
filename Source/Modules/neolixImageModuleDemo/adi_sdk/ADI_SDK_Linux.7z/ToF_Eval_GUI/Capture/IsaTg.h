#pragma once
#include "stdafx.h"
#include "Param.h"
#include "ADDI9033Regs.h"

#define ISATG_MAX_CODE_SIZE 4096*2

// **** NOTE: Once the ADDI9033 has more than 1 mode, we need to programmatically determine what it is ****
#define ISATG_MODE 0
#define ISATG_MODE_INIT_TBL_SIZE 6

#define ISATG_FIELDIDX_MODE_TBL_OFFSET 5
#define ISATG_FIELDIDX_MODE_TBL_MASK 0x1000

#define ISATG_MULTIRANGE_PATTERN_SIZE 4

// These addresses can change if the ISATG code changes
#define ISATG_CODE_BASE_ADDR 0x4000
#define ISATG_MODEDATA_START_ADDR 0x409e
#define ISATG_HPT_SEQ01_ADDR 0x43f8
#define ISATG_HPT_SEQ03_ADDR 0x441c
#define ISATG_HPT_SEQ05_ADDR 0x442e
#define ISATG_HPT_SEQ07_ADDR 0x4452

#define ISATG_HPT_LD_POS_BLK_ADDR 0xC08C
#define ISATG_HPT_LD_NEG_BLK_ADDR 0xC08D
#define ISATG_HPT_LD_STBY_ADDR 0xC0A9

#define ISATG_HPT_LD1_POS_ADDR 0xC090
#define ISATG_HPT_LD1_NEG_ADDR 0xC091
#define ISATG_HPT_LD2_POS_ADDR 0xC092
#define ISATG_HPT_LD2_NEG_ADDR 0xC093
#define ISATG_HPT_LD3_POS_ADDR 0xC094
#define ISATG_HPT_LD3_NEG_ADDR 0xC095

#define ISATG_HPT_LD4_POS_ADDR 0xC098
#define ISATG_HPT_LD4_NEG_ADDR 0xC099
#define ISATG_HPT_SUB_POS_ADDR 0xC09A
#define ISATG_HPT_SUB_NEG_ADDR 0xC09B

#define ISATG_ADDI9033_HPT_LD4_POS_ADDR 0xC096
#define ISATG_ADDI9033_HPT_LD4_NEG_ADDR 0xC097
#define ISATG_ADDI9033_HPT_SUB_POS_ADDR 0xC098
#define ISATG_ADDI9033_HPT_SUB_NEG_ADDR 0xC099

#define ISATG_ADDI9033_TAL_PH_CMP_EN_ADDR 0x400D
#define ISATG_ADDI9033_TAL_PH_CMP_REG     0xC75E
#define ISATG_ADDI9033_TAL_PH_CMP_EN_DATA 0x0013
//#define ISATG_ADDI9033_TAL_PH_CMP_EN_DATA 0x0010
#define ISATG_ADDI9033_TAL_EDGE_EN_ADDR   0x400E
#define ISATG_ADDI9033_TAL_EDGE_REG       0xC730
#define ISATG_ADDI9033_TAL_EDGE_EN_DATA   0x1313
//#define ISATG_ADDI9033_TAL_EDGE_EN_DATA   0x1010

//#define ISATG_MULTIRANGE_TBL_ADDR 0x4084
#define ISATG_MULTIRANGE_TBL_ADDR 0x408D

#define ISATG_HPT_ENA_ADDR 0xC0A9
#define ISATG_HPT_ENA_SET 2
#define ISATG_HPT_ENA_CLEAR 0

#define ISATG_HPT_POS_BLK_ADDR 0xC084
#define ISATG_HPT_NEG_BLK_ADDR 0xC085
#define ISATG_LD_LEFT_BIT    1
#define ISATG_LD_RIGHT_BIT   2
#define ISATG_LD_TOP_BIT     4
#define ISATG_LD_BOTTOM_BIT  8
#define ISATG_LD_ALL (ISATG_LD_LEFT_BIT | ISATG_LD_RIGHT_BIT | ISATG_LD_TOP_BIT | ISATG_LD_BOTTOM_BIT)
#define ISATG_ADDI9030_SUB_BIT  0x20
#define ISATG_ADDI9033_SUB_BIT  0x10

#define ISATG_MODE_ADDR 0x4000
#define ISATG_MODE_NEAR  0
#define ISATG_MODE_XNEAR 3
#define ISATG_MODE_MID   1
#define ISATG_MODE_FAR   2
#define ISATG_MODE_XFAR  2

//PLG
#ifdef ADDI9033_MACROS
#define ISATG_PULSE_CNT_MAX 2900
#define ISATG_PULSE_CNT_NEAR_MAX 2900
#define ISATG_PULSE_CNT_XNEAR_MAX 2900
#define ISATG_PULSE_CNT_MID_MAX 2900
#define ISATG_PULSE_CNT_FAR_MAX 2900
#define ISATG_PULSE_CNT_XFAR_MAX 2900
#else
#define ISATG_PULSE_CNT_MAX 4000
#define ISATG_PULSE_CNT_NEAR_MAX 4000
#define ISATG_PULSE_CNT_XNEAR_MAX 4000
#define ISATG_PULSE_CNT_MID_MAX 4000
#define ISATG_PULSE_CNT_FAR_MAX 4000
#define ISATG_PULSE_CNT_XFAR_MAX 4000
#endif

#define PULSE_TIMING_OFFSET 6

#define ISATG_MAX_PATTERN 4

enum cancellationPatternNum{
	CANCELLATION_DISABLE = -1,
	CANCEL_INTERFERNCE_CAM0 = 0,
    CANCEL_INTERFERNCE_CAM1 = 1,
};


typedef struct {
	uint16 addr;
	uint16 data;
} isa_code_entry_t;

typedef struct {
	int iLength;
	isa_code_entry_t *pCode;
} isa_code_block_t;

typedef struct {
    uint16 PulseCnt;
    uint16 Iter;
    uint16 Stdby;
    uint16 Mode;
} isa_mr_pattern_t;

typedef struct {
    isa_code_entry_t PulseCnt;
    isa_code_entry_t NumFrames;
    isa_code_entry_t Stdby;
    isa_code_entry_t Mode;
} isa_mr_tbl_entry_t;

typedef struct {
    isa_code_entry_t NumLvls;
    isa_mr_tbl_entry_t Entry[ISATG_MAX_PATTERN]; 
} isa_mr_tbl_t;

class IsaTg
{
	img_sensor_e eSensorType;
	depth_range_e eDepthRange;
   	afe_part_e eAfePart;

    void ToFIPInitAddrs(void);
	uint16 unPulseCnt;
	int8 cPulseTiming;
	uint16 unLaserEnaReg;
    bool bWDREnable;
    bool bM3WEnabled;
    bool bDepthIRMode;
    bool bRawMode;
    bool bToFLoadFile12;
    bool bTalEnable;
    bool bMultiRange;
	int8 cCancellation;

	isa_code_block_t icCodeBlock;

    isa_code_block_t icSweepCode;
    
	isa_code_block_t icPulseCntCode;

    isa_code_block_t icHPTStdbyCode;
	isa_code_block_t icHPTIsaCode;

    isa_code_block_t icHPTBlkEna;
    isa_code_entry_t pHPTBlkEna[2];

    isa_code_block_t icTALEnable;
    isa_code_entry_t pTALCode[2];

    isa_code_block_t icMultiRangeCode;
    isa_mr_tbl_t imMultRangeTbl;

	isa_code_block_t icToFIPCode;
    tof_ip_regs_t ToFIPRegs;

    isa_code_block_t icTmpCode;

public:
	IsaTg();
	~IsaTg();
	void parseCode(char *filename, isa_code_block_t *pCodeBlk);
	void parseDir(char *path, isa_code_block_t *pCodeBlk, bool bCal);
	void getModePath(char *path);
    void findLoadFile(char *filename, int number, char *path);


	isa_code_block_t *getBaseCode(depth_range_e eDepthRange);
    isa_code_block_t *getBaseCode(Param *pParams);
	isa_code_block_t *getBaseCode(void);
	isa_code_block_t *getPulseCntCode(uint16 unPulseCnt);
	isa_code_block_t *getPulseCntCode(void);
	uint16 setPulseCnt(uint16 unPulseCnt);
	uint16 getPulseCnt() { return(this->unPulseCnt); }

    void setLaserLeft(void) { this->unLaserEnaReg |= ISATG_LD_LEFT_BIT; }
    void clrLaserLeft(void) { this->unLaserEnaReg &= ~ISATG_LD_LEFT_BIT; }
    void setLaserRight(void) { this->unLaserEnaReg |= ISATG_LD_RIGHT_BIT; }
    void clrLaserRight(void) { this->unLaserEnaReg &= ~ISATG_LD_RIGHT_BIT; }
    void setLaserEnaReg(uint16 unLaserEnaReg);
    uint16 getLaserEnaReg(void) { return this->unLaserEnaReg & 0x0F; }
	isa_code_block_t *getLaserEnaCode(void);

    void setTALEnable(bool bTalEnable);
    bool getTALEnable(void) { return this->bTalEnable; }
    isa_code_block_t *getTALEnableCode(void) { return(&icTALEnable); }
    isa_code_block_t *getTALEnableCode(bool bTALEnable);

	void setPulseTiming(int8 cPulseTiming) { this->cPulseTiming = cPulseTiming; }
	int8 getPulseTiming() { return(this->cPulseTiming); }
	void setSensorType(img_sensor_e eSensorType) { this->eSensorType = eSensorType; }
	void setDepthRange(depth_range_e eDepthRange) { this->eDepthRange = eDepthRange; }
	depth_range_e getDepthRange(void) { return(this->eDepthRange); }
    void setToFLoadFile12(bool bToFLoadFile12) { this->bToFLoadFile12 = bToFLoadFile12; }

    isa_code_block_t *getSweepCode(depth_range_e eDepthRange, int iSwpState, Param *pParams);
	isa_code_block_t *getSweepCode(void) { return(&icSweepCode); }

    isa_code_block_t *getHPTStdbyCode(depth_range_e eDepthRange);
    isa_code_block_t *getHPTStdbyCode(void);
    void getHPTStdbyValues(uint8 *ucLDPos, uint8 *ucLDNeg, uint8 *ucSubPos, uint8 *ucSubNeg);
    void setHPTStdbyOffsets(uint8 ucLDPos, uint8 ucLDNeg, uint8 ucSubPos, uint8 ucSubNeg);
    void clrHPTStdbyOffsets(void);

    isa_code_block_t *getHPTIsaCode(depth_range_e eDepthRange);
    isa_code_block_t *getHPTIsaCode(void);
    void getHPTIsaValues(uint8 *ucLD0Pos, uint8 *ucLD0Neg,
                                uint8 *ucLD1Pos, uint8 *ucLD1Neg, 
                                uint8 *ucS0Pos, uint8 *ucS0Neg,  
                                uint8 *ucS1Pos, uint8 *ucS1Neg);
    void setHPTIsaOffsets(uint8 ucLD0Pos, uint8 ucLD0Neg,
                               uint8 ucLD1Pos, uint8 ucLD1Neg, 
                               uint8 ucS0Pos, uint8 ucS0Neg,  
                               uint8 ucS1Pos, uint8 ucS1Neg);
    void clrHPTIsaOffsets(void);


    isa_code_block_t *leftLaserOn(bool bLaserOn);
    isa_code_block_t *rightLaserOn(bool bLaserOn);

    void setWDREnable(bool bWDREnable) { this->bWDREnable = bWDREnable; }
    void setMethod3WEnable(bool bM3WEnabled) { this->bM3WEnabled = bM3WEnabled; }

    uint16 getCodeBlockData(isa_code_block_t *pCodeBlock, uint16 addr);
    void replaceCodeBlockData(isa_code_block_t *pCodeBlock, uint16 addr, uint16 data);
    uint16 readCodeBlockData(isa_code_block_t *pCodeBlock, uint16 addr);
    void appendCodeBlockData(isa_code_block_t *pCodeBlock, uint16 addr, uint16 data);
    void appendCodeBlock(isa_code_block_t *pCodeBlock, isa_code_block_t *pCodeBlockA);
    uint16 getStartHDCnt(uint16 unPulseCnt);
    uint16 findCodeBlockData(isa_code_block_t *pCodeBlock, uint16 addr);

    void setAfePart(afe_part_e eAfePart);
    isa_code_block_t *getToFIPCode(Param *pParams);
    void updateToFIPCode(Param *pParams);
    void wrToFIPToFile(char *filename);
    void setDepthIRMOde(bool bDepthIRMode) { this->bDepthIRMode = bDepthIRMode; }
    isa_code_block_t *getDepthIRModeCode(bool bDepthIRMode);
    void setRawMode(bool bRawMode) { this->bRawMode = bRawMode; }

    // Multi-range
    void setMultRangePattern(isa_mr_pattern_t *PatternMap, int iSize);
    isa_code_block_t *getMultiRangeCode(void); 

	//Interference Cancellation
	void setCancellation(cancellationPatternNum cCancellation){this->cCancellation = cCancellation;}
	int8 getCancellation(void){return cCancellation;}

};

