/********************************************************************************/
/*                                                                              */
/* @file        Param.h                                                         */
/*                                                                              */
/* @brief       Imports and stores parameters from a .ini file.                 */
/*                                                                              */
/* @author      Rick Haltmaier                                                  */
/*                                                                              */
/* @date        September 1, 2015                                               */
/*                                                                              */
/* Copyright(c) Analog Devices, Inc.                                            */
/*                                                                              */
/********************************************************************************/
#ifndef _PARAM_H_
#define _PARAM_H_

#include "StdAfx.h"
#include "types.h"
#include "ADDI9033Regs.h"

#define MAX_LINE_SIZE 1024
#define MAX_PATH_SIZE 1024
#define MAX_1D_ARRAY_LENGTH 1024
#define LD_REG_INIT_VAL 0x03
#ifdef ADDI9033_MACROS
#define PULSE_CNT_INIT 2900
#else
#define PULSE_CNT_INIT 4000
#endif
#define RAWNR_MED_EN 1
#define RAWNR_MED_SEL 2
#define RAWNR_XPWR_TBL_SIZE 12
#define RAWNR_YVAL_TBL_SIZE (RAWNR_XPWR_TBL_SIZE+1)
#define DFCT_TH_TBL_SIZE 12
#define SHADING_XPWR_TBL_SIZE 15
#define SHADING_YPWR_TBL_SIZE 11
#define SHADING_OFFSET_TBL_SIZE 192
#define IR_GAMMA_PWR_TBL_SIZE 10
#define NR_FLT_COEF_TBL_SIZE 70
#define LNR_OFFSET_XPWR_TBL_SIZE 48
#define LNR_OFFSET_VAL_TBL_SIZE (LNR_OFFSET_XPWR_TBL_SIZE+1)
#define INTRINSIC_TBL_SIZE 9
#define DISTORTION_TBL_SIZE 5

#define SCANF_PAD 4
#define UVM_COMMENT_POS     "70"
#define UVM_CFG_VAL_POS     "47"
#define UVM_CFG_COMMENT_POS "96"

enum img_sensor_e {
	NO_SENSOR = 0,
	VGA_V1 = 1,
	VGA_V2 = 2,    // MN34902BL
	VGA_V3 = 3,    // MN34906BL
	SXGA_V1 = 4,   // MN34920BL
	SXGA_V2 = 5,
	SXGA_V3 = 6,   // MN34926BL
};

enum afe_part_e {
    AFE_UNKNOWN = 0,
    AFE_ADDI9030 = 1,
    AFE_ADDI9033 = 2,
    AFE_ADDI9035 = 3,
};

enum depth_range_e {
	DEPTH_RANGE_NEAR = 0,
	DEPTH_RANGE_MID = 1,
	DEPTH_RANGE_FAR = 2,
	DEPTH_RANGE_XFAR = 3,
	DEPTH_RANGE_XNEAR = 4,
	DEPTH_RANGE_MAX = 5,
};


typedef char array_str_t[MAX_LINE_SIZE];

class Param {
public:
	img_sensor_e eImgSensorType;  // Selects type and version of sensor (IR, RGB, VGA, etc.)
    afe_part_e eAfePart;     // Selects AFE part type
    uint8 ucRawMode;         // Selects frame size for ADDI9033 (1 => 668x750 for raw, 0 => 640x480 for Depth/IR)
    uint8 ucDummy1[3];
	uint8 ucDepthMode;       // Depth calculation method(0 = S1/S0 or 1 = S1/(S0+S1))
    uint8 ucDummy2[3];
	depth_range_e eDepthRange;  // Depth range
	uint16 unLDPulseCnt;     // AFE timing - laser pulse count
	uint32 uiInWidth;        // Raw input image width containing all three image phases
	uint32 uiInHeight;       // Raw input image height containing all three image phases
	uint32 uiProcWidth;      // Image internal processing width if not determined by sensor type
	uint32 uiProcHeight;     // Image internal processing height if not determined by sensor type
	uint32 uiOutWidth;       // Output image width
    uint32 uiOutHStart;      // Output image Horizontal start (ROI)
	uint32 uiOutHeight;      // Output image height
    uint32 uiOutVStart;      // Output image Vertical start (ROI)

    uint16 unLaserEnaReg;

    // Debug output enable switches
	char cOutputPath[MAX_PATH_SIZE];
	uint8 OutputSeparateDataSw;
	uint8 OutputMedianDataSw;
	uint8 OutputTransDataSw;
	uint8 OutputMixTransDataSw;
	uint8 OutputRawNrDataSw;
	uint8 OutputCoringDataSw;
	uint8 OutputDepthDataSw;
	uint8 OutputDepthRelateDataSw;
	uint8 OutputDepthOutDataSw;
	uint8 OutputIrOutDataSw;

	// Test image inject
	uint8 InjPostReorderSw;
	char InjPostReorderA0[MAX_PATH_SIZE];
	char InjPostReorderA1[MAX_PATH_SIZE];
	char InjPostReorderA2[MAX_PATH_SIZE];
	uint8 InjPostGridSw;
	char InjPostGridA0[MAX_PATH_SIZE];
	char InjPostGridA1[MAX_PATH_SIZE];
	char InjPostGridA2[MAX_PATH_SIZE];

	// Reorder registers
	uint8 ucM3WSel;          // Wide dynamic range mode selection (1 = WDR)
	uint16 ToFStartHDCnt;    // Start line (from image top)
	uint16 ToFStartPixCnt;   // Start pixel (from image left edge)
        uint8 DebugReorderBuffers; // Dumps out ReOrder::reorder() buffers when set to 1
  
	// Defect Pixel Correction registers
	uint8 DfctPixEna;        // Enables defect pixel correction 
	uint8 DfctMedRefSel;     // Median filter select: 0 = all 9 pixels, 1 = exclude corner pixels
	uint8 DfctDetBslnSel;    // Selects baseline for pixel defect: 0 = Median value, 1 = Vicinity value
	uint16 DfctPixSatTh;     // Defect pixel saturation threshold
	uint16 DfctThrTbl[DFCT_TH_TBL_SIZE];  // Defect pixel threshold table

	// Grid conversion registers
	uint8 ucGridVGASel;      // Grid converter selection (0 = Full, 1 = WDR, 2 = Interference Cancellation)
	uint16 OBClmpLev;        // Optical Black (OB) clamp level
	uint16 VGAShrtXOfst;     // VGA Short x offset of non-zero mix value
	uint8 VGAShrtXPwr;       // VGA Short x range from non-zero to max of 1/2
	uint16 VGALngSatTh;      // VGA Long exposure saturation threshold
	uint16 KsVGAShrt2Lng;    // VGA Long to short exposure time ratio
	uint8 WDRBitSft;         // Bit shift to divide the long/short multiply/sum

	// NR Filter resisters
	uint8 RawNREna;
	uint8 RawNRMed4Bl1Sel;   // Coefficient generator median filter select
	uint16 RawNRMed4Bl1Gain;
	uint16 RawNRSatTh;
	uint8 RawNRXPwr[RAWNR_XPWR_TBL_SIZE + 4];     // Bit shift for Nlev table generation (need buffer for VS read bug)
	uint16 RawNRXVal[RAWNR_YVAL_TBL_SIZE];
	uint16 RawNRBlTbl[RAWNR_YVAL_TBL_SIZE];   // Values for Nlev table generation
	uint16 RawNRBkTbl[RAWNR_YVAL_TBL_SIZE];   // Values for backward Nlev table generation
	uint16 unCoefTbl[49][7];

	// Samll signal removal / Coring registers
	uint8 ucSmSigRmvEna;     // Enable for small signal removal
	uint16 S0S1CorTh;
	uint16 CorThDetGainF;
	uint8 CorThDetCntF;
	uint16 CorThSftGainF;
	int16 CorThSftIncOfst;
	int16 CorThSftDecOfst;
	uint16 CorThDetGainB;
	uint8 CorThDetCntB;
	uint16 CorThSftGainB;

	// Depth calc registers
	uint16 DepthCalcAddVLU;

	// Linear correction registers
    int16 LnrOfst[LNR_OFFSET_VAL_TBL_SIZE];
	int16 LnrX0;
	uint8 LnrXPwr[LNR_OFFSET_XPWR_TBL_SIZE];

	// Zero point offset correction registers
	int16 DepthZeroCorre;

	// Shading offset correction registers
	uint8 ucShdOfstEna;
	int16 Shd_X0;
	int16 Shd_Y0;
	uint8 ShdXPwr[SHADING_XPWR_TBL_SIZE];
	uint8 ShdYPwr[SHADING_YPWR_TBL_SIZE];
	int16 ShdOfst[SHADING_OFFSET_TBL_SIZE];

	// Slope adjust registers
	uint16 DepthSlopeGain;
	int16 DepthOfstVLU;
	uint16 DepthMax;

    double DepthCnvGain;

	// IR processing registers
	uint16 IRDGain;
	uint8 IRImgSel;
	uint8 IRGmmPwr[IR_GAMMA_PWR_TBL_SIZE - 1 + SCANF_PAD];
	uint16 IRGmmX[IR_GAMMA_PWR_TBL_SIZE];
	uint16 IRGmmY[IR_GAMMA_PWR_TBL_SIZE];

    uint8 OutputBGSel;
    uint8 OutputIntrlvSel;

	// Checker board registers??
	uint8 ChkrDetEna;
	uint8 ChkrDetTypeSel;
	uint16 ChkrStartH;
	uint16 ChkrStartV;
	uint8 ChkrSizeH;
	uint16 ChkrUpprTh;
	uint16 ChkrLwrTh;
	uint8 ChkrUpprErrH;
	uint8 ChkrLwrErrH;
	uint8 ChkrUpprErrV;
	uint8 ChkrLwrErrV;
	uint8 ChkrStrtOfstH;

	//Camera Intrinsic and ditortion coefficient
	float fIntrinsic[INTRINSIC_TBL_SIZE];
	double dDistortionCoeff[DISTORTION_TBL_SIZE];

	//SPI Xfer
	uint8 xferType;

    // Control
    uint8 ToFEnable;
    uint8 ChannelSwap;
    uint8 VdhdDelayAdj;

    // Align
    uint8 AMapA0Even;
    uint8 AMapA1Even;
    uint8 AMapA2Even;
    uint8 AMapA0Odd;
    uint8 AMapA1Odd;
    uint8 AMapA2Odd;
    uint8 BMapA0Even;
    uint8 BMapA1Even;
    uint8 BMapA2Even;
    uint8 BMapA0Odd;
    uint8 BMapA1Odd;
    uint8 BMapA2Odd;
    uint8 CMapA0Even;
    uint8 CMapA1Even;
    uint8 CMapA2Even;
    uint8 CMapA0Odd;
    uint8 CMapA1Odd;
    uint8 CMapA2Odd;

    uint8 ToFAfe1ElOffset;
    uint8 ToFAfe1OlOffset;
    uint8 ToFAfe2ElOffset;
    uint8 ToFAfe2OlOffset;
    uint8 ToFPixelOffset;
    uint8 RGBAfe1ElOffset;
    uint8 RGBAfe1OlOffset;
    uint8 RGBAfe2ElOffset;
    uint8 RGBAfe2OlOffset;

    uint16 RateAdjHdPeriod;
    uint16 RateAdjImgHeight;
    uint16 RateAdjImgWidth;

    uint8 OutputEnable;
    uint16 VC;
    uint16 Bypass;
    uint8 TestRamp;

    Param(char *filename = NULL);
    ~Param();
    errcode_t ParamInit(char *filename);
    void SetProcWidth(void);
    void SetProcHeight(void);
    errcode_t AmodelParamWrite(char *filename);
    errcode_t PmodelParamWrite(char *filename);
    errcode_t CreateUVMTest(char *psUvmTestName, char *psUvmTestFilename, char *psImageListFilename);
    void getCalFilePath(char *Path, int detphLevel);
    void CalParamWr(uint16 depthLevel=0);
    void CalParamOffsetWr(void);
    void CalParamReset(void);
    void CalTempParamWr(void);

private:
    uint16 unCoefIn[70];
    array_str_t arrayStr1D[MAX_1D_ARRAY_LENGTH];
    uint16 __iniFileIRGmmY[IR_GAMMA_PWR_TBL_SIZE];

    int FindEntry(char *pcEntry, char *pcKeyword, FILE *fp);
    int AddSingleValueEntry(char *pcEntry, char *pcKeyword, FILE *fp);
    int AddOneDimensionalArrayAmodelEntry(array_str_t *arrayStr1D, unsigned int arrayLength, char *pcKeyword, FILE *fp);
    int AddOneDimensionalArrayPmodelEntry(array_str_t *arrayStr1D, unsigned int arrayLength, char *pcKeyword, FILE *fp);
    int AddDepthShadingTablePmodelEntry(array_str_t *arrayStr1D, unsigned int arrayLength, FILE *fp);
    int AddWriteFieldByName(char *pcEntry, char *pcRegisterField, char *pcAmodelKeyword, FILE *fp);
    int AddWriteFieldByNameError(char *pcEntry, char *pcRegisterField, char *pcAmodelKeyword, FILE *fp);
    int AddWriteOneDimensionalArrayFieldByName(array_str_t *arrayStr1D, unsigned int arrayLength, char *pcRegisterField, char *pcAmodelKeyword, FILE *fp);
    int AddWriteOneDimensionalArrayFieldByName(array_str_t *arrayStr1D, unsigned int startingFieldNum, unsigned int arrayLength, char *pcRegisterField, char *pcAmodelKeyword, FILE *fp); // includes startingFieldNum argument
    int AddWriteOneDimensionalArrayRegByName(array_str_t *arrayStr1D, unsigned int arrayLength, char *pcRegisterName, char *pcAmodelKeyword, FILE *fp);
    int WriteUvmTestHeader(FILE *fp, char *pcTestName, char *pcTestFilename);
    int WriteUvmTestSetupRegSeqClass(FILE *fp, char *pcTestName);
    errcode_t WriteUVMParamRegWrites(FILE *fp);
    int WriteUvmTestTestClass(FILE *fp, char *pcTestName, char *pcImageFilename);
    errcode_t WriteUVMConfigEnvWrites(FILE *fp);
    int AddConfigEnvDpiParamSet(char *pcEntry, char *pcDpiParamVarName, char *pcAmodelKeyword, FILE *fp);
    int AddConfigEnvDpiParamSetError(char *pcEntry, char *pcDpiParamVarName, char *pcAmodelKeyword, FILE *fp);
    int AddConfigEnvCfgAssignment(char *pcEntry, char *pcConfigVarName, char *pcAmodelKeyword, FILE *fp);
    int AddConfigEnvCfgAssignmentError(char *pcEntry, char *pcConfigVarName, char *pcAmodelKeyword, FILE *fp);
    int AddConfigEnvDpiParamCfgAssignment(char *pcEntry, char *pcConfigVarName, char *pcAmodelKeyword, FILE *fp);
    int AddConfigEnvDpiParamCfgAssignmentError(char *pcEntry, char *pcConfigVarName, char *pcAmodelKeyword, FILE *fp);
    errcode_t WriteUvmTestSimDotSetupFile(FILE *fp, char *pcImageFilename);
};


#endif // _PARAM_H_
