// stdafx.cpp : source file that includes just the standard includes
// DepthTestBed.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information

//#include "stdafx.h"
#include <string.h>

// TODO: reference any additional headers you need in STDAFX.H
// and not in this file

// If defined, disables WDR mode
//#define NOT_WDR_MODE

// Enables the old rounding method for shading correction.
// Keeping it around until the Panasonic C model is updated.
//#define SHADING_OLD_RND

// Enables a workaround for IRCalc where the output value of the 
// gamma correction table is always max output for a max input.
// The tests need to adjust the table settings to insure this.
#define IRCALC_TEST_WORKAROUND