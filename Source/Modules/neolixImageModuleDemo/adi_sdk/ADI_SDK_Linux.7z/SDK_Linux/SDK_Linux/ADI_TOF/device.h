/********************************************************************************/
/*                                                                  			*/
/* @file	device.h                                                            */
/*                                                                              */
/* @brief	Performs UVC device operation using V4L2                            */
/*                                                                              */
/* @author	Dhruvesh Gajaria                                                    */
/*                                                                              */
/* @date	October 15, 2015                                                    */
/*                                                                              */
/* Copyright(c) Analog Devices, Inc.                                            */
/*                                                                              */
/********************************************************************************/
#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <linux/videodev2.h>



struct buffer {
        void   *start;
        size_t  length;
};

class Device
{
    char dev_name[100];
	int              fd;
	struct buffer    *buffers;
	unsigned int     n_buffers;
	int              out_buf;
	struct v4l2_format fmt;
	
	public:
	
        
    Device()
	{
		fd=-1;
	}
    ~Device();
    int openDevice();
    unsigned short* getImage(unsigned short* dstBuffer = NULL);
    //void stop_capturing();
    bool program ();
};

