#ifndef ADI_TOF_GLOBAL_H
#define ADI_TOF_GLOBAL_H

#include <QtCore/qglobal.h>

#if defined(ADI_TOF_LIBRARY)
#  define ADI_TOFSHARED_EXPORT Q_DECL_EXPORT
#else
#  define ADI_TOFSHARED_EXPORT Q_DECL_IMPORT
#endif

#endif // ADI_TOF_GLOBAL_H
