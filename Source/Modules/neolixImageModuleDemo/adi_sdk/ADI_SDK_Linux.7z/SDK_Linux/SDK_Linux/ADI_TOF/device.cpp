/********************************************************************************/
/*                                                                              */
/* @file	device.cpp                                                          */
/*                                                                              */
/* @brief	Performs UVC device operation using V4L2                        	*/
/*                                                                              */
/* @author	Dhruvesh Gajaria                                                	*/
/*                                                                              */
/* @date	October 15, 2015                                                    */
/*                                                                              */
/* Copyright(c) Analog Devices, Inc.                                            */
/*                                                                              */
/********************************************************************************/

#include"device.h"
#include <string.h>
#include <assert.h>
#include<iostream>

#include <getopt.h>             /* getopt_long() */

#include <fcntl.h>              /* low-level i/o */
#include <unistd.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <linux/videodev2.h>
#include<linux/uvcvideo.h>	//For uvc_xu_control_query defination
#include<linux/usb/video.h>  // For UVC_SET_CUR defination

#include<dirent.h>

#define CLEAR(x) memset(&(x), 0, sizeof(x))

using namespace std;


static void errno_exit(const char *s)
{
        fprintf(stderr, "%s error %d, %s\n", s, errno, strerror(errno));
        exit(EXIT_FAILURE);
}

static int xioctl(int fh, int request, void *arg)
{
        int r;

        do {
                r = ioctl(fh, request, arg);
                //printf("Error=%d\n",errno);
        } while (-1 == r && EINTR == errno && errno!=0);

       // do r= ioctl(fh, request, arg);
        //while(-1==r&&EINTR == errno);
        return r;
}
/*
static void process_image(const void *p, int size)
{
        //if (out_buf)
                //fwrite(p, size, 1, stdout);

        img=Mat(fmt.fmt.pix.height,fmt.fmt.pix.width,CV_16UC1,(ushort *)p);
	img.convertTo(img,CV_8U,255.0/4095);
	imshow("Output",img);
	waitKey(30);

        //cout<<fmt.fmt.pix.height<<"\t"<<fmt.fmt.pix.width<<"\t"<<fmt.fmt.pix.bytesperline<<"\t"<<fmt.fmt.pix.pixelformat<<"\n";
        fflush(stderr);
        fprintf(stderr, ".");
        fflush(stdout);
}

static int read_frame(void)
{
        struct v4l2_buffer buf;
        unsigned int i;

        
        CLEAR(buf);

        buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        buf.memory = V4L2_MEMORY_MMAP;

        if (-1 == xioctl(fd, VIDIOC_DQBUF, &buf)) {
                switch (errno) {
                case EAGAIN:
                        return 0;

                case EIO:
                        // Could ignore EIO, see spec. 
                        // fall through 

                default:
                        errno_exit("VIDIOC_DQBUF");
                }
        }

        assert(buf.index < n_buffers);

        process_image(buffers[buf.index].start, buf.bytesused);

        if (-1 == xioctl(fd, VIDIOC_QBUF, &buf))
                errno_exit("VIDIOC_QBUF");
                break;

        return 1;
}
*/
unsigned short* Device::getImage(unsigned short *dstBuffer)
{

            //Mat Img;
            fd_set fds;
            struct timeval tv;
            int r;

            FD_ZERO(&fds);
            FD_SET(fd, &fds);

            // Timeout.
            tv.tv_sec = 2;
            tv.tv_usec = 0;

            r = select(fd + 1, &fds, NULL, NULL, &tv);

            if (-1 == r) {
                    if (EINTR == errno)
                            return NULL;
                    errno_exit("select");
            }

            if (0 == r) {
                    //fprintf(stderr, "select timeout\n");
                    //exit(EXIT_FAILURE);
                    return NULL;
            }

			struct v4l2_buffer buf;

	
			CLEAR(buf);

			buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
			buf.memory = V4L2_MEMORY_MMAP;

			if (-1 == xioctl(fd, VIDIOC_DQBUF, &buf)) {
                cout<<"Stream Error\n";
				switch (errno) {
				case EAGAIN:
					break;


				case EIO:
					// Could ignore EIO, see spec. 
					// fall through 

				default:
					errno_exit("VIDIOC_DQBUF");
				}
			}

			assert(buf.index < n_buffers);

			//process_image(buffers[buf.index].start, buf.bytesused);
			//cout<<"Size="<<fmt.fmt.pix.sizeimage<<endl;

            //Mat temp;
            //temp=Mat(fmt.fmt.pix.height,fmt.fmt.pix.width, CV_16UC1,(ushort*)buffers[buf.index].start);
            //Img=temp.clone();
            //temp.release();

            if(dstBuffer==NULL)
            {
                dstBuffer=(unsigned short *)calloc(fmt.fmt.pix.height*fmt.fmt.pix.width,sizeof(unsigned short));
            }

            memcpy(dstBuffer,(unsigned short*)buffers[buf.index].start,fmt.fmt.pix.height*fmt.fmt.pix.width * 2);

			if (-1 == xioctl(fd, VIDIOC_QBUF, &buf))
				errno_exit("VIDIOC_QBUF");

            return dstBuffer;
}

//void Device::stop_capturing(void)
Device::~Device()
{
    enum v4l2_buf_type type;

	type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	if (-1 == xioctl(fd, VIDIOC_STREAMOFF, &type))
		errno_exit("VIDIOC_STREAMOFF");

	unsigned int i;

        for (i = 0; i < n_buffers; ++i)
                if (-1 == munmap(buffers[i].start, buffers[i].length))
                        errno_exit("munmap");
        free(buffers);

	if (-1 == close(fd))
        errno_exit("close");

    fd = -1;
}

int property_id=40;
bool Device::program ()
{

	double value=0x2;
           struct uvc_xu_control_query cq;
           unsigned char dd[2],rem[2];
        unsigned char buf[4096];
        long lValue,flen,filesize=4096;
        int temp=0,temp1=0;
        //cout<<"Configuring AFE\n";
        int sleepDuration=100;
 
        if(property_id == 40)
        {
           FILE *fp = fopen( "afe_firmware.bin", "rb"); //file location  to Open
               if (fp!= NULL)
                  {
                           fseek(fp, 0L, SEEK_END);
                           flen = ftell(fp);  //flen->length of file
                           fseek(fp, 0L, SEEK_SET);
                           if (flen <= filesize) //filesize less than 4kb
                              {
                                               CLEAR(cq);
                                               memset(buf, 0, filesize);
                                               fread(buf, 1, filesize, fp);
                                               lValue = flen;
                                               rem[0] = (unsigned char)((unsigned int)lValue & 0xff);
                                               rem[1] = (unsigned char)(((unsigned int)lValue >> 8)& 0xff);
                                               cq.query= UVC_SET_CUR;//bRequest
                                               cq.data = rem;  //value to set or get
                                               cq.size = 4;//size in bytes
                                               cq.unit = 0x03;//wIndex
                                               cq.selector= 2;//WValue AFE Remaining bytes
                                               if (-1 == xioctl(fd, UVCIOC_CTRL_QUERY, &cq)) {
                                                   if (EINVAL == errno) {
                                                            fprintf(stderr, "Error in updating file size\n");
                                                            return false;
                                                                     //exit(EXIT_FAILURE);
                                                               }
                                                   else {
                                                       printf("ErrorN%d\n", errno);
                                                                   //errno_exit("VIDIOC_QUERYCAP");
                                                          }
                                                 }
 
                                          /////////////////
                                               CLEAR(cq);
                                               cq.query= UVC_SET_CUR;//bRequest
                                               cq.data = buf;  //value to set or get
                                               cq.size = 4096;//size in bytes
                                               cq.unit = 0x03;//wIndex
                                               cq.selector= 1;//WValue AFE Programming
                                               if (-1 == xioctl(fd, UVCIOC_CTRL_QUERY, &cq)) {
                                                     if (EINVAL == errno) {
                                                            fprintf(stderr, "Error in Programming FPGA\n");
                                                            return false;
                                                            //exit(EXIT_FAILURE);
                                                                               }
                                                     else {
                                                                   //errno_exit("VIDIOC_QUERYCAP");
                                                            }
                                                   }
                                               fclose(fp);
                              }
                           else //filesize greater than 4kb
                              {
                                               while (temp1 <= flen)
                                               {
                                                   CLEAR(cq);
                                                   fseek(fp, temp1, 0);
                                                     if ((flen - temp1) >= filesize) //filesize greater than or equal to 4096
                                                       {
							    //cout<<"Enter Value\n";
							    //cin>>lValue;	
                                                            fread(buf, 1, filesize, fp);
                                                            cq.query= UVC_SET_CUR;//bRequest
                                                    cq.data = buf;  //value to set or get
                                                            cq.size = 4096;//size in bytes
                                                            cq.unit = 0x03;//wIndex
                                                            cq.selector= 1;//WValue AFE Programming
                                                            if (-1 == xioctl(fd, UVCIOC_CTRL_QUERY, &cq)) {                                                                   
								if (EINVAL == errno) {
                                                                         fprintf(stderr, "Error in Programming FPGA\n");
                                                                                      //exit(EXIT_FAILURE);
                                                                                     }
                                                                   else {
                                                                         //errno_exit("VIDIOC_QUERYCAP");
                                                                         }
                                                               }
                                                            temp1 += filesize;
                                //cout<<"temp1="<<temp1<<endl;
                                sleep(1);
                                                       }
                                                     else  //filesize less than 4kb
                                                       {
							    //cout<<"Enter Value\n";
							    //cin>>lValue;	
                                                            temp = flen - temp1;
                                                            memset(buf, 0, filesize);
                                                                   fread(buf, 1, temp, fp);
                                                            lValue = temp;
                                //cout<<lValue;
                                                            rem[0] = (unsigned char)((unsigned int)lValue & 0xff);
                                                            rem[1] = (unsigned char)(((unsigned int)lValue >> 8)& 0xff);
                                                            //cout<<"Remaining Bytes="<<(int)rem[1]<<(int)rem[0]<<endl;
                       					    cq.query= UVC_SET_CUR;//bRequest
                                                            cq.data = rem;  //value to set or get
                                                            cq.size = 4;//size in bytes
                                                            cq.unit = 0x03;//wIndex
                                                            cq.selector= 2;//WValue AFE Remaining bytes
                                                            if (-1 == xioctl(fd, UVCIOC_CTRL_QUERY, &cq)) {
								   //cout<<"Error writing remaining  bytes\n";
                                                                   if (EINVAL == errno) {
                                                                          fprintf(stderr, "Error in updating file size\n");
                                                                                //exit(EXIT_FAILURE);
                                                                                    }
                                                                   else {
                                                                             //errno_exit("VIDIOC_QUERYCAP");
                                                                            }
                                                         }
                                                            /////////////////
                                                            cq.query= UVC_SET_CUR;//bRequest
                                                            cq.data = buf;  //value to set or get
                                                            cq.size = 4096;//size in bytes
                                                            cq.unit = 0x03;//wIndex
                                                            cq.selector= 1;//WValue AFE Programming
                                                            if (-1 == xioctl(fd, UVCIOC_CTRL_QUERY, &cq)) {
                                                                   if (EINVAL == errno) {
                                                                          fprintf(stderr, "Error in Programming FPGA\n");
                                                                                      //exit(EXIT_FAILURE);
                                                                                      }
                                                                   else {
                                                                         //errno_exit("VIDIOC_QUERYCAP");
                                                                         }
                                                              }
                                                            temp1 += temp + 1;
                                                            fclose(fp);
                                                            //usleep(100000);

                                                     }
                                                  }
                                }
 
                      }
                       else
                           cout<<" File cannot be Found or Opened ";
               //property_id=0;
 
        }
        else
        {
                       CLEAR(cq);
//////////////////////////////////SET Extension Propert///////////////////////////////////////
                       dd[0] = (unsigned char)((unsigned int)value & 0xff);
                       dd[1] = (unsigned char)(((unsigned int)value << 8)& 0xff);
                      //Set Extension  Paramteter Value
                       cq.query= UVC_SET_CUR;//bRequest
                       cq.data = dd;//value to set or get
                       cq.size = 2;//size in bytes
                       cq.unit = 0x03;//wIndex
                       cq.selector= 3;//WValue //Analog Gain Get
 
                       if (-1 == xioctl(fd, UVCIOC_CTRL_QUERY, &cq)) {
                                     if (EINVAL == errno) {
                                           fprintf(stderr, "%s is no V4L2 device\n",dev_name);
                                                      exit(EXIT_FAILURE);
                                            } else {
                                                      //errno_exit("VIDIOC_QUERYCAP");
                                                   }
                                        }
         }
//////////////////////////////////SET Extension Propert///////////////////////////////////////
        usleep(sleepDuration);
        return true;
}




int Device::openDevice()
{
    struct stat st;
	struct v4l2_capability cap;
    unsigned int i;
	struct v4l2_requestbuffers req;
    int deviceFound=-1;





    DIR *d;
    struct dirent *dir;

    char path[80]={"/dev/"};
    d = opendir(path);
    if(d)
    {
        char sset[]="video";
        while((dir=readdir(d))!=NULL)
        {
            if(strspn(sset,(dir->d_name))==5)
            {
                //cout<<"Name:"<<dir->d_name<<endl;
                sprintf(dev_name, "%s%s", path, dir->d_name);
            }
            else
                continue;


            if (-1 == stat(dev_name, &st)) {
                    fprintf(stderr, "Cannot identify '%s': %d, %s\n",
                             dev_name, errno, strerror(errno));
                    exit(EXIT_FAILURE);
            }

            if (!S_ISCHR(st.st_mode)) {
                    fprintf(stderr, "%s is no device\n", dev_name);
                    exit(EXIT_FAILURE);
            }

            fd = open(this->dev_name, O_RDWR| O_NONBLOCK, 0);

            if (-1 == fd) {
                    fprintf(stderr, "Cannot open '%s': %d, %s\n",
                             dev_name, errno, strerror(errno));
                    exit(EXIT_FAILURE);
            }

            unsigned int min;

            if (-1 == xioctl(fd, VIDIOC_QUERYCAP, &cap)) {
                    if (EINVAL == errno) {
                            fprintf(stderr, "%s is no V4L2 device\n",
                                     dev_name);
                            exit(EXIT_FAILURE);
                    } else {
                            errno_exit("VIDIOC_QUERYCAP");
                    }
            }

            //cout<<"Device Name"<<(char*)cap.card<<endl;
            if(strcmp((char*)cap.card,"ADI TOF DEPTH SENSOR")!=0)
                continue;
            else
                deviceFound=(int)dir->d_name[5]-48;


            if (!(cap.capabilities & V4L2_CAP_VIDEO_CAPTURE)) {
                    fprintf(stderr, "%s is no video capture device\n",
                             dev_name);
                    exit(EXIT_FAILURE);
            }



            if (!(cap.capabilities & V4L2_CAP_STREAMING)) {
                    fprintf(stderr, "%s does not support streaming i/o\n",
                             dev_name);
                    exit(EXIT_FAILURE);
            }


            CLEAR(fmt);

            fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
            // Preserve original settings as set by v4l2-ctl for example
            if (-1 == xioctl(fd, VIDIOC_G_FMT, &fmt))
                errno_exit("VIDIOC_G_FMT");

            // Buggy driver paranoia.
            min = fmt.fmt.pix.width * 2;
            if (fmt.fmt.pix.bytesperline < min)
                    fmt.fmt.pix.bytesperline = min;
            min = fmt.fmt.pix.bytesperline * fmt.fmt.pix.height;
            if (fmt.fmt.pix.sizeimage < min)
                    fmt.fmt.pix.sizeimage = min;


            //setControl(40,0x2);
            //program();


            CLEAR(req);

            req.count = 4;
            req.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
            req.memory = V4L2_MEMORY_MMAP;

            if (-1 == xioctl(fd, VIDIOC_REQBUFS, &req)) {
                    if (EINVAL == errno) {
                            fprintf(stderr, "%s does not support "
                                     "memory mapping\n", dev_name);
                            exit(EXIT_FAILURE);
                    } else {
                            errno_exit("VIDIOC_REQBUFS");
                    }
            }

            if (req.count < 2) {
                    fprintf(stderr, "Insufficient buffer memory on %s\n",
                             dev_name);
                    exit(EXIT_FAILURE);
            }

            buffers = (buffer*)calloc(req.count, sizeof(*buffers));

            if (!buffers) {
                    fprintf(stderr, "Out of memory\n");
                    exit(EXIT_FAILURE);
            }

            for (n_buffers = 0; n_buffers < req.count; ++n_buffers) {
                    struct v4l2_buffer buf;

                    CLEAR(buf);

                    buf.type        = V4L2_BUF_TYPE_VIDEO_CAPTURE;
                    buf.memory      = V4L2_MEMORY_MMAP;
                    buf.index       = n_buffers;

                    if (-1 == xioctl(fd, VIDIOC_QUERYBUF, &buf))
                            errno_exit("VIDIOC_QUERYBUF");

                    buffers[n_buffers].length = buf.length;
                    buffers[n_buffers].start =
                            mmap(NULL, // start anywhere ,
                                  buf.length,
                                  PROT_READ | PROT_WRITE, // required,
                                  MAP_SHARED, // recommended ,
                                  fd, buf.m.offset);

                    if (MAP_FAILED == buffers[n_buffers].start)
                            errno_exit("mmap");
            }
            enum v4l2_buf_type type;



            for (i = 0; i < n_buffers; ++i) {
                    struct v4l2_buffer buf;

                    CLEAR(buf);
                    buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
                    buf.memory = V4L2_MEMORY_MMAP;
                    buf.index = i;

                    if (-1 == xioctl(fd, VIDIOC_QBUF, &buf))
                            errno_exit("VIDIOC_QBUF");
            }
            type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
            if (-1 == xioctl(fd, VIDIOC_STREAMON, &type))
                    errno_exit("VIDIOC_STREAMON");
            break;
        }
        closedir(d);
    }
        return deviceFound;
}


/*
int device::main1()
{
	dev_name = (char*)"/dev/video1";
        open_device(char* devName);
        //init_device();
        //start_capturing();
	
for(;;)
{
	Mat dispImg;
        dispImg=mainloop();
	if(dispImg.empty())
	{
		cout<<"Empty\n";
		setControl(40,0x2);
	}
	else
	{	//cout<<"Rows="<<dispImg.rows<<endl;
		dispImg.convertTo(dispImg,CV_8U,255.0/4095);
		imshow("Output Img",dispImg);
		waitKey(30);
		dispImg.release();
	}
}
        stop_capturing();
        //uninit_device();
        //close_device();
	cout<<"Test\n";
        fprintf(stderr, "\n");
        return 1;
}

*/
