#ifndef NEOLIX_DEBUG_H
#define NEOLIX_DEBUG_H

//#define NEOLIX_DEBUG
//#define TEST_CAL_PAD_DIS
//#define RUNMAIN
//#define TEST_RECOFINITION_OBJECT
//#define TEST_XML
//#define TEST_LEAST
//#define TEST_POINT
//#define  CAP_RI
//#define RANSAC_TEST
//#define TOF_TEST
//#define MEASURE_TEST
#define DEBUG_RANSAC
//#define TESTE_SUNYN_SDK
#endif
