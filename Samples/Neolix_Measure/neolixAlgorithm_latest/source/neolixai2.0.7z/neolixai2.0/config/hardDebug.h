#ifndef __HARD_DEBUG_H_
#define __HARD_DEBUG_H_

namespace neolix
{
void hardebug();
void softdebug(int method);
void debug_rancas();
}

#endif // __HARD_DEBUG_H_
